/// <mls fileReference="_102051_/l4/cafeFlow/ontology/AiPromotionSuggestion.defs.ts" enhancement="_blank"/>

export const cafeFlowEntityAiPromotionSuggestion = {
  "entityId": "AiPromotionSuggestion",
  "title": "Sugestão de Itens a Promover (IA)",
  "description": "Recomendações geradas pelo assistente de IA com base nos últimos 7 dias para apoiar a decisão do gerente sobre quais itens promover.",
  "kind": "metric",
  "ownership": "moduleOwned",
  "fields": [
    {
      "fieldId": "aiPromotionSuggestionId",
      "type": "uuid",
      "required": true,
      "description": "Identificador único da sugestão de promoção gerada pela IA."
    },
    {
      "fieldId": "operationalDashboardId",
      "type": "uuid",
      "required": true,
      "description": "Identificador do dashboard operacional a partir do qual a sugestão foi derivada."
    },
    {
      "fieldId": "menuItemId",
      "type": "uuid",
      "required": true,
      "description": "Identificador do item de menu sugerido para promoção."
    },
    {
      "fieldId": "menuItemName",
      "type": "string",
      "required": true,
      "description": "Nome do item de menu sugerido, capturado no momento da geração para exibição no dashboard."
    },
    {
      "fieldId": "menuCategoryId",
      "type": "uuid",
      "required": false,
      "description": "Identificador da categoria do item sugerido, quando aplicável."
    },
    {
      "fieldId": "reason",
      "type": "text",
      "required": true,
      "description": "Justificativa em linguagem natural explicando por que o item foi sugerido para promoção (ex.: baixo volume de vendas, excesso de estoque)."
    },
    {
      "fieldId": "salesLast7Days",
      "type": "number",
      "required": true,
      "description": "Quantidade de unidades vendidas do item nos últimos 7 dias, base da análise da IA."
    },
    {
      "fieldId": "salesToday",
      "type": "number",
      "required": false,
      "description": "Quantidade de unidades vendidas do item no dia corrente, quando disponível."
    },
    {
      "fieldId": "currentStockLevel",
      "type": "number",
      "required": false,
      "description": "Nível atual de estoque do item no momento da sugestão, em unidades."
    },
    {
      "fieldId": "confidenceScore",
      "type": "number",
      "required": true,
      "description": "Pontuação de confiança da sugestão gerada pela IA, entre 0 e 100."
    },
    {
      "fieldId": "suggestedDiscountPercent",
      "type": "number",
      "required": false,
      "description": "Percentual de desconto sugerido pela IA para a promoção, em valor percentual."
    },
    {
      "fieldId": "status",
      "type": "string",
      "required": true,
      "description": "Estado da sugestão de promoção no fluxo de decisão do gerente.",
      "enum": [
        "pending",
        "accepted",
        "rejected",
        "expired"
      ]
    },
    {
      "fieldId": "reviewedAt",
      "type": "datetime",
      "required": false,
      "description": "Data e hora em que o gerente avaliou a sugestão (aceitação ou rejeição)."
    },
    {
      "fieldId": "reviewedByUserId",
      "type": "uuid",
      "required": false,
      "description": "Identificador do usuário gerente que avaliou a sugestão."
    },
    {
      "fieldId": "reviewNotes",
      "type": "text",
      "required": false,
      "description": "Observações registradas pelo gerente ao aceitar ou rejeitar a sugestão."
    },
    {
      "fieldId": "generatedAt",
      "type": "datetime",
      "required": true,
      "description": "Data e hora em que a sugestão foi gerada pelo assistente de IA."
    },
    {
      "fieldId": "expiresAt",
      "type": "datetime",
      "required": false,
      "description": "Data e hora limite de validade da sugestão antes de expirar automaticamente."
    },
    {
      "fieldId": "createdAt",
      "type": "datetime",
      "required": true,
      "description": "Data e hora de criação do registro da sugestão."
    },
    {
      "fieldId": "updatedAt",
      "type": "datetime",
      "required": true,
      "description": "Data e hora da última atualização do registro da sugestão."
    }
  ],
  "statusEnum": [
    "pending",
    "accepted",
    "rejected",
    "expired"
  ],
  "lifecycleStates": [
    "pending",
    "accepted",
    "rejected",
    "expired"
  ]
} as const;

export default cafeFlowEntityAiPromotionSuggestion;
