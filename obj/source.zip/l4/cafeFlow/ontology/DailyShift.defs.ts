/// <mls fileReference="_102051_/l4/cafeFlow/ontology/DailyShift.defs.ts" enhancement="_blank"/>

export const cafeFlowEntityDailyShift = {
  "entityId": "DailyShift",
  "title": "Turno Diário",
  "description": "Turno operacional de um dia que concentra pedidos, vendas e movimentos de estoque, viabilizando o relatório de fechamento e o dashboard operacional.",
  "kind": "core",
  "ownership": "moduleOwned",
  "fields": [
    {
      "fieldId": "dailyShiftId",
      "type": "uuid",
      "required": true,
      "description": "Identificador único do turno diário (chave primária)."
    },
    {
      "fieldId": "shiftDate",
      "type": "date",
      "required": true,
      "description": "Data operacional do turno (dia de calendário ao qual o turno pertence)."
    },
    {
      "fieldId": "status",
      "type": "string",
      "required": true,
      "description": "Estado atual do turno: aberto (recebendo pedidos) ou fechado (pronto para relatório de fechamento).",
      "enum": [
        "open",
        "closed"
      ]
    },
    {
      "fieldId": "openedByUserId",
      "type": "uuid",
      "required": true,
      "description": "Identificador do operador (usuário) que abriu o turno."
    },
    {
      "fieldId": "closedByUserId",
      "type": "uuid",
      "required": false,
      "description": "Identificador do operador (usuário) que fechou o turno, quando aplicável."
    },
    {
      "fieldId": "openedAt",
      "type": "datetime",
      "required": true,
      "description": "Data e hora de abertura do turno."
    },
    {
      "fieldId": "closedAt",
      "type": "datetime",
      "required": false,
      "description": "Data e hora de fechamento do turno; preenchido quando o turno é encerrado."
    },
    {
      "fieldId": "totalOrders",
      "type": "number",
      "required": false,
      "description": "Total de pedidos registrados durante o turno."
    },
    {
      "fieldId": "totalSalesAmount",
      "type": "money",
      "required": false,
      "description": "Valor total vendido no turno, somando os pedidos confirmados."
    },
    {
      "fieldId": "totalItemsSold",
      "type": "number",
      "required": false,
      "description": "Quantidade total de itens vendidos no turno."
    },
    {
      "fieldId": "cashTotal",
      "type": "money",
      "required": false,
      "description": "Total recebido em dinheiro no turno, conforme fechamento básico."
    },
    {
      "fieldId": "otherPaymentsTotal",
      "type": "money",
      "required": false,
      "description": "Total recebido via outras formas de pagamento (cartão, Pix, etc.) no turno, conforme fechamento básico."
    },
    {
      "fieldId": "notes",
      "type": "text",
      "required": false,
      "description": "Observações livres registradas na abertura ou no fechamento do turno."
    },
    {
      "fieldId": "createdAt",
      "type": "datetime",
      "required": true,
      "description": "Data e hora de criação do registro do turno."
    },
    {
      "fieldId": "updatedAt",
      "type": "datetime",
      "required": true,
      "description": "Data e hora da última atualização do registro do turno."
    }
  ],
  "statusEnum": [
    "open",
    "closed"
  ],
  "lifecycleStates": [
    "open",
    "closed"
  ]
} as const;

export default cafeFlowEntityDailyShift;
