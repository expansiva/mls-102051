/// <mls fileReference="_102051_/l4/cafeFlow/ontology/AiSalesSummary.defs.ts" enhancement="_blank"/>

export const cafeFlowEntityAiSalesSummary = {
  "entityId": "AiSalesSummary",
  "title": "Resumo de Vendas do Dia (IA)",
  "description": "Resumo narrativo das vendas do dia gerado pelo assistente de IA via proxy LLM da plataforma, para comunicação rápida à equipe.",
  "kind": "metric",
  "ownership": "moduleOwned",
  "fields": [
    {
      "fieldId": "aiSalesSummaryId",
      "type": "uuid",
      "required": true,
      "description": "Identificador único do resumo de vendas gerado pela IA."
    },
    {
      "fieldId": "operationalDashboardId",
      "type": "uuid",
      "required": true,
      "description": "Identificador do dashboard operacional do qual o resumo foi derivado."
    },
    {
      "fieldId": "summaryDate",
      "type": "date",
      "required": true,
      "description": "Data de referência do dia ao qual o resumo se refere."
    },
    {
      "fieldId": "periodStart",
      "type": "date",
      "required": true,
      "description": "Data inicial do período considerado para a geração do resumo (normalmente 7 dias antes de summaryDate)."
    },
    {
      "fieldId": "periodEnd",
      "type": "date",
      "required": true,
      "description": "Data final do período considerado para a geração do resumo (normalmente o próprio summaryDate)."
    },
    {
      "fieldId": "summaryText",
      "type": "text",
      "required": true,
      "description": "Texto narrativo do resumo de vendas produzido pelo assistente de IA."
    },
    {
      "fieldId": "modelId",
      "type": "string",
      "required": false,
      "description": "Identificador do modelo LLM utilizado pelo proxy da plataforma para gerar o resumo."
    },
    {
      "fieldId": "promptTokens",
      "type": "number",
      "required": false,
      "description": "Quantidade de tokens consumidos no prompt enviado ao LLM."
    },
    {
      "fieldId": "completionTokens",
      "type": "number",
      "required": false,
      "description": "Quantidade de tokens consumidos na resposta gerada pelo LLM."
    },
    {
      "fieldId": "generatedAt",
      "type": "datetime",
      "required": false,
      "description": "Data e hora em que o resumo foi efetivamente gerado pelo assistente de IA."
    },
    {
      "fieldId": "createdAt",
      "type": "datetime",
      "required": true,
      "description": "Data e hora de criação do registro do resumo."
    },
    {
      "fieldId": "updatedAt",
      "type": "datetime",
      "required": true,
      "description": "Data e hora da última atualização do registro do resumo."
    }
  ],
  "lifecycleStates": [
    "generated",
    "delivered",
    "failed"
  ]
} as const;

export default cafeFlowEntityAiSalesSummary;
