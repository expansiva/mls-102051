/// <mls fileReference="_102051_/l4/cafeFlow/operations/browseStockItems.defs.ts" enhancement="_blank"/>

export const operationBrowseStockItems = {
  "operationId": "browseStockItems",
  "title": "Listar itens de estoque",
  "actors": [
    "gerente"
  ],
  "entity": "StockItem",
  "kind": "query",
  "reads": [
    "StockItem"
  ],
  "writes": [],
  "rulesApplied": [
    "lowStockMustBeVisible"
  ],
  "story": {
    "actor": "gerente",
    "goal": "Visualizar os itens de estoque com saldos atuais e destaque de estoque baixo",
    "steps": [
      "O gerente acessa o controle de estoque",
      "O sistema lista os insumos com saldo atual, unidade e nível mínimo",
      "Itens com saldo no ou abaixo do mínimo são destacados como estoque baixo",
      "O gerente pode filtrar por nome ou somente itens em estoque baixo"
    ],
    "outcome": "Lista de itens de estoque e rupturas/riscos conhecida para priorizar reposição ou ajustes"
  },
  "accessPattern": {
    "kind": "list",
    "description": "Lista paginada dos itens de estoque com indicação de nível baixo para o controle de insumos",
    "entity": "StockItem",
    "keyField": "StockItem.stockItemId",
    "filters": [
      "StockItem.name"
    ],
    "sort": [
      "StockItem.name"
    ],
    "pagination": "optional",
    "selection": "single",
    "output": [
      "StockItem.stockItemId",
      "StockItem.name",
      "StockItem.unit",
      "StockItem.currentBalance",
      "StockItem.minimumLevel",
      "StockItem.description",
      "StockItem.updatedAt"
    ]
  },
  "outputShape": {
    "kind": "paginated",
    "fields": [
      {
        "name": "stockItems",
        "type": "array",
        "required": true,
        "item": {
          "fields": [
            {
              "name": "stockItemId",
              "type": "string",
              "required": true,
              "fieldRef": "StockItem.stockItemId"
            },
            {
              "name": "name",
              "type": "string",
              "required": true,
              "fieldRef": "StockItem.name"
            },
            {
              "name": "unit",
              "type": "string",
              "required": true,
              "fieldRef": "StockItem.unit"
            },
            {
              "name": "currentBalance",
              "type": "number",
              "required": true,
              "fieldRef": "StockItem.currentBalance"
            },
            {
              "name": "minimumLevel",
              "type": "number",
              "required": true,
              "fieldRef": "StockItem.minimumLevel"
            },
            {
              "name": "description",
              "type": "string",
              "required": false,
              "fieldRef": "StockItem.description"
            },
            {
              "name": "updatedAt",
              "type": "string",
              "required": true,
              "fieldRef": "StockItem.updatedAt"
            },
            {
              "name": "isLowStock",
              "type": "boolean",
              "required": true
            }
          ]
        }
      },
      {
        "name": "total",
        "type": "number",
        "required": true
      }
    ]
  },
  "inputs": [
    {
      "inputId": "nameFilter",
      "fieldRef": "StockItem.name",
      "required": false,
      "source": "userInput",
      "description": "Filtro opcional pelo nome do item de estoque"
    },
    {
      "inputId": "lowStockOnly",
      "type": "boolean",
      "required": false,
      "source": "userInput",
      "description": "Quando verdadeiro, retorna apenas itens com saldo atual menor ou igual ao nível mínimo"
    },
    {
      "inputId": "page",
      "type": "number",
      "required": false,
      "source": "userInput",
      "description": "Número da página para paginação da lista"
    },
    {
      "inputId": "pageSize",
      "type": "number",
      "required": false,
      "source": "userInput",
      "description": "Quantidade de itens retornados por página"
    }
  ],
  "contextResolution": [],
  "acceptanceAssertions": [
    "A operação retorna a lista de itens de estoque com stockItemId, name, unit, currentBalance e minimumLevel",
    "Itens com currentBalance menor ou igual a minimumLevel são retornados com isLowStock verdadeiro",
    "Quando lowStockOnly é verdadeiro, somente itens em estoque baixo constam no resultado",
    "O total de itens correspondente aos filtros é retornado junto com a página de resultados",
    "O gerente obtém a lista de rupturas e riscos de estoque conhecida para priorizar reposição"
  ],
  "pageId": "browseStockItems",
  "commandName": "browseStockItems",
  "bffName": "cafeFlow.browseStockItems.browseStockItems",
  "capability": {
    "capabilityId": "browseStockItems",
    "title": "Listar itens de estoque",
    "actor": "gerente",
    "priority": "now"
  },
  "statusFrontend": "toCreate",
  "statusBackend": "toCreate"
} as const;

export default operationBrowseStockItems;
