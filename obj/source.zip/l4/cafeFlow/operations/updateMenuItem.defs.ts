/// <mls fileReference="_102051_/l4/cafeFlow/operations/updateMenuItem.defs.ts" enhancement="_blank"/>

export const operationUpdateMenuItem = {
  "operationId": "updateMenuItem",
  "title": "Atualizar item do cardápio",
  "actors": [
    "gerente"
  ],
  "entity": "MenuItem",
  "kind": "update",
  "reads": [
    "MenuItem",
    "MenuCategory"
  ],
  "writes": [
    "MenuItem"
  ],
  "rulesApplied": [
    "onlyActiveMenuItemsCanBeOrdered",
    "menuItemNeedsCategoryAndPrice"
  ],
  "story": {
    "actor": "gerente",
    "goal": "Atualizar nome, categoria, preço e disponibilidade de um item do cardápio para refletir o que a cafeteria realmente vende",
    "steps": [
      "O gerente abre o item do cardápio já cadastrado",
      "Altera nome, categoria, preço, descrição, imagem, ordem de exibição, vínculo de estoque ou status (ativo/pausado)",
      "Confirma a gravação das alterações"
    ],
    "outcome": "Item do cardápio salvo com os novos dados e disponibilidade atualizada no atendimento/PDV"
  },
  "accessPattern": {
    "kind": "commandInput",
    "description": "Formulário de edição do item do cardápio identificado na rota",
    "entity": "MenuItem",
    "keyField": "MenuItem.menuItemId",
    "pagination": "none",
    "selection": "single",
    "output": [
      "MenuItem.menuItemId",
      "MenuItem.menuCategoryId",
      "MenuItem.name",
      "MenuItem.description",
      "MenuItem.price",
      "MenuItem.status",
      "MenuItem.pausedAt",
      "MenuItem.pauseReason",
      "MenuItem.imageUrl",
      "MenuItem.displayOrder",
      "MenuItem.requiresStockLink",
      "MenuItem.updatedAt"
    ]
  },
  "outputShape": {
    "kind": "object",
    "fields": [
      {
        "name": "menuItemId",
        "type": "string",
        "required": true,
        "fieldRef": "MenuItem.menuItemId"
      },
      {
        "name": "menuCategoryId",
        "type": "string",
        "required": true,
        "fieldRef": "MenuItem.menuCategoryId"
      },
      {
        "name": "name",
        "type": "string",
        "required": true,
        "fieldRef": "MenuItem.name"
      },
      {
        "name": "description",
        "type": "string",
        "required": false,
        "fieldRef": "MenuItem.description"
      },
      {
        "name": "price",
        "type": "number",
        "required": true,
        "fieldRef": "MenuItem.price"
      },
      {
        "name": "status",
        "type": "string",
        "required": true,
        "fieldRef": "MenuItem.status"
      },
      {
        "name": "pausedAt",
        "type": "string",
        "required": false,
        "fieldRef": "MenuItem.pausedAt"
      },
      {
        "name": "pauseReason",
        "type": "string",
        "required": false,
        "fieldRef": "MenuItem.pauseReason"
      },
      {
        "name": "imageUrl",
        "type": "string",
        "required": false,
        "fieldRef": "MenuItem.imageUrl"
      },
      {
        "name": "displayOrder",
        "type": "number",
        "required": false,
        "fieldRef": "MenuItem.displayOrder"
      },
      {
        "name": "requiresStockLink",
        "type": "boolean",
        "required": true,
        "fieldRef": "MenuItem.requiresStockLink"
      },
      {
        "name": "updatedAt",
        "type": "string",
        "required": true,
        "fieldRef": "MenuItem.updatedAt"
      }
    ]
  },
  "inputs": [
    {
      "inputId": "menuItemId",
      "fieldRef": "MenuItem.menuItemId",
      "required": true,
      "source": "routeParam",
      "description": "Identificador do item do cardápio a ser atualizado"
    },
    {
      "inputId": "menuCategoryId",
      "fieldRef": "MenuItem.menuCategoryId",
      "required": true,
      "source": "userInput",
      "description": "Categoria à qual o item passa a pertencer"
    },
    {
      "inputId": "name",
      "fieldRef": "MenuItem.name",
      "required": true,
      "source": "userInput",
      "description": "Nome do item exibido no cardápio e no PDV"
    },
    {
      "inputId": "description",
      "fieldRef": "MenuItem.description",
      "required": false,
      "source": "userInput",
      "description": "Descrição curta do item para o cliente"
    },
    {
      "inputId": "price",
      "fieldRef": "MenuItem.price",
      "required": true,
      "source": "userInput",
      "description": "Preço de venda atual do item no PDV"
    },
    {
      "inputId": "status",
      "fieldRef": "MenuItem.status",
      "required": true,
      "source": "userInput",
      "description": "Disponibilidade do item: active ou paused"
    },
    {
      "inputId": "pauseReason",
      "fieldRef": "MenuItem.pauseReason",
      "required": false,
      "source": "userInput",
      "description": "Motivo registrado ao pausar o item"
    },
    {
      "inputId": "imageUrl",
      "fieldRef": "MenuItem.imageUrl",
      "required": false,
      "source": "userInput",
      "description": "URL da imagem do item no cardápio digital e no PDV"
    },
    {
      "inputId": "displayOrder",
      "fieldRef": "MenuItem.displayOrder",
      "required": false,
      "source": "userInput",
      "description": "Ordem de exibição do item dentro da categoria"
    },
    {
      "inputId": "requiresStockLink",
      "fieldRef": "MenuItem.requiresStockLink",
      "required": true,
      "source": "userInput",
      "description": "Indica se o item exige vínculo com ingredientes para baixa automática"
    },
    {
      "inputId": "pausedAt",
      "fieldRef": "MenuItem.pausedAt",
      "required": false,
      "source": "systemDefault",
      "description": "Data/hora em que o item foi pausado, quando o status muda para paused"
    },
    {
      "inputId": "updatedAt",
      "fieldRef": "MenuItem.updatedAt",
      "required": true,
      "source": "systemDefault",
      "description": "Data e hora da gravação da atualização"
    }
  ],
  "contextResolution": [
    {
      "inputId": "menuItemId",
      "targetRef": "MenuItem.menuItemId",
      "source": "routeParam",
      "originRef": "routeParam.menuItemId",
      "description": "Obtém o menuItemId do parâmetro de rota da tela de edição do item"
    },
    {
      "inputId": "updatedAt",
      "targetRef": "MenuItem.updatedAt",
      "source": "systemDefault",
      "originRef": "systemDefault.now",
      "description": "Define updatedAt com a data/hora atual do servidor no momento da gravação"
    },
    {
      "inputId": "pausedAt",
      "targetRef": "MenuItem.pausedAt",
      "source": "systemDefault",
      "originRef": "systemDefault.now",
      "description": "Quando o status informado é paused, preenche pausedAt com agora; quando reativado para active, limpa pausedAt"
    }
  ],
  "acceptanceAssertions": [
    "Após a confirmação o item do cardápio existe com nome, categoria e preço atualizados conforme informados",
    "O item atualizado mantém categoria e preço definidos, condição necessária para venda",
    "Quando o status é alterado para paused, o item fica indisponível para novos lançamentos no POS",
    "Quando o status é alterado para active, o item volta a ficar disponível para lançamento no POS",
    "O campo updatedAt reflete o momento da atualização após a gravação",
    "Se o status for paused, pausedAt é preenchido; se for active, pausedAt não permanece definido"
  ],
  "pageId": "updateMenuItem",
  "commandName": "updateMenuItem",
  "bffName": "cafeFlow.updateMenuItem.updateMenuItem",
  "capability": {
    "capabilityId": "updateMenuItem",
    "title": "Atualizar item do cardápio",
    "actor": "gerente",
    "priority": "now"
  },
  "statusFrontend": "toCreate",
  "statusBackend": "toCreate"
} as const;

export default operationUpdateMenuItem;
