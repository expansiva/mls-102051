/// <mls fileReference="_102051_/l2/cafeFlow/web/contracts/kitchenWorkspace.ts" enhancement="_blank"/>
export const fetchKitchenQueueRoute = 'cafeFlow.kitchenWorkspace.fetchKitchenQueue';
export const changeOrderStatusRoute = 'cafeFlow.kitchenWorkspace.changeOrderStatus';
