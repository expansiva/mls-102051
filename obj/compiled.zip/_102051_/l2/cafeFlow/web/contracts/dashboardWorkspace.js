/// <mls fileReference="_102051_/l2/cafeFlow/web/contracts/dashboardWorkspace.ts" enhancement="_blank"/>
export const getDashboardRoute = 'cafeFlow.dashboardWorkspace.getDashboard';
export const getAiSalesSummaryRoute = 'cafeFlow.dashboardWorkspace.getAiSalesSummary';
export const getAiPromotionSuggestionsRoute = 'cafeFlow.dashboardWorkspace.getAiPromotionSuggestions';
