/// <mls fileReference="_102051_/l2/cafeFlow/web/contracts/shiftWorkspace.ts" enhancement="_blank"/>
export const openDailyShiftCmdRoute = 'cafeFlow.shiftWorkspace.openDailyShiftCmd';
export const closeDailyShiftCmdRoute = 'cafeFlow.shiftWorkspace.closeDailyShiftCmd';
export const getShiftClosingReportRoute = 'cafeFlow.shiftWorkspace.getShiftClosingReport';
