/// <mls fileReference="_102051_/l2/cafeFlow/web/contracts/posWorkspace.ts" enhancement="_blank"/>
export const queryOpenOrdersRoute = 'cafeFlow.posWorkspace.queryOpenOrders';
export const queryMenuItemsRoute = 'cafeFlow.posWorkspace.queryMenuItems';
export const cmdCreateOrderRoute = 'cafeFlow.posWorkspace.cmdCreateOrder';
export const cmdUpdateOrderStatusRoute = 'cafeFlow.posWorkspace.cmdUpdateOrderStatus';
export const cmdRecordBasicPaymentRoute = 'cafeFlow.posWorkspace.cmdRecordBasicPayment';
