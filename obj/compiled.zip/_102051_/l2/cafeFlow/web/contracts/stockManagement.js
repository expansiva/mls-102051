/// <mls fileReference="_102051_/l2/cafeFlow/web/contracts/stockManagement.ts" enhancement="_blank"/>
export const listStockItemsRoute = 'cafeFlow.stockManagement.listStockItems';
export const addStockItemRoute = 'cafeFlow.stockManagement.addStockItem';
export const editStockItemRoute = 'cafeFlow.stockManagement.editStockItem';
export const removeStockItemRoute = 'cafeFlow.stockManagement.removeStockItem';
export const registerStockAdjustmentRoute = 'cafeFlow.stockManagement.registerStockAdjustment';
