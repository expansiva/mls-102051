/// <mls fileReference="_102051_/l2/cafeFlow/web/contracts/menuManagement.ts" enhancement="_blank"/>
export const listMenuItemsRoute = 'cafeFlow.menuManagement.listMenuItems';
export const createMenuItemCmdRoute = 'cafeFlow.menuManagement.createMenuItemCmd';
export const updateMenuItemCmdRoute = 'cafeFlow.menuManagement.updateMenuItemCmd';
