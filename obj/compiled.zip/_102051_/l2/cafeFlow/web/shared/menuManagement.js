/// <mls fileReference="_102051_/l2/cafeFlow/web/shared/menuManagement.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { listMenuItemsRoute, createMenuItemCmdRoute, updateMenuItemCmdRoute, } from '/_102051_/l2/cafeFlow/web/contracts/menuManagement.js';
/// **collab_i18n_start**
const message_pt = {
    'section.menuManagement.menuItemList.title': 'Menu Item List',
    'organism.menuManagement.listMenuItems.title': 'Listar itens do cardápio',
    'intent.menuManagement.listMenuItems.list.title': 'Listar itens do cardápio',
    'intent.menuManagement.listMenuItems.list.empty': 'Nenhum registro encontrado',
    'intent.menuManagement.listMenuItems.list.column.menuItems.label': 'Menu Items',
    'intent.menuManagement.listMenuItems.list.column.total.label': 'Total',
    'intent.menuManagement.listMenuItems.list.filter.status.label': 'Status',
    'intent.menuManagement.listMenuItems.list.filter.menuCategoryId.label': 'Menu Category Id',
    'intent.menuManagement.listMenuItems.list.filter.name.label': 'Name',
    'intent.menuManagement.listMenuItems.list.filter.page.label': 'Page',
    'intent.menuManagement.listMenuItems.list.filter.pageSize.label': 'Page Size',
    'organism.menuManagement.createMenuItemCmd.title': 'Criar item do cardápio',
    'intent.menuManagement.createMenuItemCmd.form.title': 'Criar item do cardápio',
    'intent.menuManagement.createMenuItemCmd.form.action.createMenuItemCmd': 'Criar item do cardápio',
    'intent.menuManagement.createMenuItemCmd.form.field.menuCategoryId.label': 'Menu Category Id',
    'intent.menuManagement.createMenuItemCmd.form.field.name.label': 'Name',
    'intent.menuManagement.createMenuItemCmd.form.field.description.label': 'Description',
    'intent.menuManagement.createMenuItemCmd.form.field.price.label': 'Price',
    'intent.menuManagement.createMenuItemCmd.form.field.status.label': 'Status',
    'intent.menuManagement.createMenuItemCmd.form.field.imageUrl.label': 'Image Url',
    'intent.menuManagement.createMenuItemCmd.form.field.displayOrder.label': 'Display Order',
    'intent.menuManagement.createMenuItemCmd.form.field.requiresStockLink.label': 'Requires Stock Link',
    'organism.menuManagement.updateMenuItemCmd.title': 'Atualizar item do cardápio',
    'intent.menuManagement.updateMenuItemCmd.form.title': 'Atualizar item do cardápio',
    'intent.menuManagement.updateMenuItemCmd.form.action.updateMenuItemCmd': 'Atualizar item do cardápio',
    'intent.menuManagement.updateMenuItemCmd.form.field.menuCategoryId.label': 'Menu Category Id',
    'intent.menuManagement.updateMenuItemCmd.form.field.name.label': 'Name',
    'intent.menuManagement.updateMenuItemCmd.form.field.description.label': 'Description',
    'intent.menuManagement.updateMenuItemCmd.form.field.price.label': 'Price',
    'intent.menuManagement.updateMenuItemCmd.form.field.status.label': 'Status',
    'intent.menuManagement.updateMenuItemCmd.form.field.pauseReason.label': 'Pause Reason',
    'intent.menuManagement.updateMenuItemCmd.form.field.imageUrl.label': 'Image Url',
    'intent.menuManagement.updateMenuItemCmd.form.field.displayOrder.label': 'Display Order',
    'intent.menuManagement.updateMenuItemCmd.form.field.requiresStockLink.label': 'Requires Stock Link',
    'section.menuManagement.sec-menu-item-workbench.title': 'Menu Item Workbench',
    'organism.menuManagement.summary-first10.title': 'Summary first',
    'intent.menuManagement.summary-first10.content.title': 'Summary first',
    'section.menuManagement.sec-create-menu-item.title': 'Criar Item do Cardápio',
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
const LIST_MENU_ITEMS_DATA_DEFAULT = { menuItems: [], total: 0 };
export class CafeFlowMenuManagementBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state ui.menuManagement.status — pageStatus */
        this.status = '';
        /** state ui.menuManagement.action.listMenuItems.status — actionStatus, values: idle|loading|success|error */
        this.listMenuItemsState = 'idle';
        /** state ui.menuManagement.input.listMenuItems.status — input */
        this.listMenuItemsStatus = '';
        /** state ui.menuManagement.input.listMenuItems.menuCategoryId — input */
        this.listMenuItemsMenuCategoryId = '';
        /** state ui.menuManagement.input.listMenuItems.name — input */
        this.listMenuItemsName = '';
        /** state ui.menuManagement.input.listMenuItems.page — input */
        this.listMenuItemsPage = '';
        /** state ui.menuManagement.input.listMenuItems.pageSize — input */
        this.listMenuItemsPageSize = '';
        /** state ui.menuManagement.data.listMenuItems — queryResult, outputShape: paginated */
        this.listMenuItemsData = { menuItems: [], total: 0 };
        /** state ui.menuManagement.action.createMenuItemCmd.status — actionStatus, values: idle|loading|success|error */
        this.createMenuItemCmdState = 'idle';
        /** state ui.menuManagement.input.createMenuItemCmd.menuCategoryId — input */
        this.createMenuItemCmdMenuCategoryId = '';
        /** state ui.menuManagement.input.createMenuItemCmd.name — input */
        this.createMenuItemCmdName = '';
        /** state ui.menuManagement.input.createMenuItemCmd.description — input */
        this.createMenuItemCmdDescription = '';
        /** state ui.menuManagement.input.createMenuItemCmd.price — input */
        this.createMenuItemCmdPrice = '';
        /** state ui.menuManagement.input.createMenuItemCmd.status — input */
        this.createMenuItemCmdStatus = '';
        /** state ui.menuManagement.input.createMenuItemCmd.imageUrl — input */
        this.createMenuItemCmdImageUrl = '';
        /** state ui.menuManagement.input.createMenuItemCmd.displayOrder — input */
        this.createMenuItemCmdDisplayOrder = '';
        /** state ui.menuManagement.input.createMenuItemCmd.requiresStockLink — input */
        this.createMenuItemCmdRequiresStockLink = '';
        /** state ui.menuManagement.output.createMenuItemCmd — commandOutput */
        this.createMenuItemCmdOutput = null;
        /** state ui.menuManagement.action.createMenuItemCmd.error — actionError */
        this.createMenuItemCmdError = '';
        /** state ui.menuManagement.action.updateMenuItemCmd.status — actionStatus, values: idle|loading|success|error */
        this.updateMenuItemCmdState = 'idle';
        /** state ui.menuManagement.input.updateMenuItemCmd.menuItemId — input */
        this.updateMenuItemCmdMenuItemId = '';
        /** state ui.menuManagement.input.updateMenuItemCmd.menuCategoryId — input */
        this.updateMenuItemCmdMenuCategoryId = '';
        /** state ui.menuManagement.input.updateMenuItemCmd.name — input */
        this.updateMenuItemCmdName = '';
        /** state ui.menuManagement.input.updateMenuItemCmd.description — input */
        this.updateMenuItemCmdDescription = '';
        /** state ui.menuManagement.input.updateMenuItemCmd.price — input */
        this.updateMenuItemCmdPrice = '';
        /** state ui.menuManagement.input.updateMenuItemCmd.status — input */
        this.updateMenuItemCmdStatus = '';
        /** state ui.menuManagement.input.updateMenuItemCmd.pauseReason — input */
        this.updateMenuItemCmdPauseReason = '';
        /** state ui.menuManagement.input.updateMenuItemCmd.imageUrl — input */
        this.updateMenuItemCmdImageUrl = '';
        /** state ui.menuManagement.input.updateMenuItemCmd.displayOrder — input */
        this.updateMenuItemCmdDisplayOrder = '';
        /** state ui.menuManagement.input.updateMenuItemCmd.requiresStockLink — input */
        this.updateMenuItemCmdRequiresStockLink = '';
        /** state ui.menuManagement.output.updateMenuItemCmd — commandOutput */
        this.updateMenuItemCmdOutput = null;
        /** state ui.menuManagement.action.updateMenuItemCmd.error — actionError */
        this.updateMenuItemCmdError = '';
        this.subscribedKeys = [
            'ui.menuManagement.status',
            'ui.menuManagement.action.listMenuItems.status',
            'ui.menuManagement.input.listMenuItems.status',
            'ui.menuManagement.input.listMenuItems.menuCategoryId',
            'ui.menuManagement.input.listMenuItems.name',
            'ui.menuManagement.input.listMenuItems.page',
            'ui.menuManagement.input.listMenuItems.pageSize',
            'ui.menuManagement.data.listMenuItems',
            'ui.menuManagement.action.createMenuItemCmd.status',
            'ui.menuManagement.input.createMenuItemCmd.menuCategoryId',
            'ui.menuManagement.input.createMenuItemCmd.name',
            'ui.menuManagement.input.createMenuItemCmd.description',
            'ui.menuManagement.input.createMenuItemCmd.price',
            'ui.menuManagement.input.createMenuItemCmd.status',
            'ui.menuManagement.input.createMenuItemCmd.imageUrl',
            'ui.menuManagement.input.createMenuItemCmd.displayOrder',
            'ui.menuManagement.input.createMenuItemCmd.requiresStockLink',
            'ui.menuManagement.output.createMenuItemCmd',
            'ui.menuManagement.action.createMenuItemCmd.error',
            'ui.menuManagement.action.updateMenuItemCmd.status',
            'ui.menuManagement.input.updateMenuItemCmd.menuItemId',
            'ui.menuManagement.input.updateMenuItemCmd.menuCategoryId',
            'ui.menuManagement.input.updateMenuItemCmd.name',
            'ui.menuManagement.input.updateMenuItemCmd.description',
            'ui.menuManagement.input.updateMenuItemCmd.price',
            'ui.menuManagement.input.updateMenuItemCmd.status',
            'ui.menuManagement.input.updateMenuItemCmd.pauseReason',
            'ui.menuManagement.input.updateMenuItemCmd.imageUrl',
            'ui.menuManagement.input.updateMenuItemCmd.displayOrder',
            'ui.menuManagement.input.updateMenuItemCmd.requiresStockLink',
            'ui.menuManagement.output.updateMenuItemCmd',
            'ui.menuManagement.action.updateMenuItemCmd.error',
        ];
    }
    /** i18n catalog — MessageType keys are the CLOSED msg vocabulary for page renders */
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.status = getState('ui.menuManagement.status') ?? '';
        this.listMenuItemsState = getState('ui.menuManagement.action.listMenuItems.status') ?? 'idle';
        this.listMenuItemsStatus = getState('ui.menuManagement.input.listMenuItems.status') ?? '';
        this.listMenuItemsMenuCategoryId = getState('ui.menuManagement.input.listMenuItems.menuCategoryId') ?? '';
        this.listMenuItemsName = getState('ui.menuManagement.input.listMenuItems.name') ?? '';
        this.listMenuItemsPage = getState('ui.menuManagement.input.listMenuItems.page') ?? '';
        this.listMenuItemsPageSize = getState('ui.menuManagement.input.listMenuItems.pageSize') ?? '';
        this.listMenuItemsData = getState('ui.menuManagement.data.listMenuItems') ?? { menuItems: [], total: 0 };
        this.createMenuItemCmdState = getState('ui.menuManagement.action.createMenuItemCmd.status') ?? 'idle';
        this.createMenuItemCmdMenuCategoryId = getState('ui.menuManagement.input.createMenuItemCmd.menuCategoryId') ?? '';
        this.createMenuItemCmdName = getState('ui.menuManagement.input.createMenuItemCmd.name') ?? '';
        this.createMenuItemCmdDescription = getState('ui.menuManagement.input.createMenuItemCmd.description') ?? '';
        this.createMenuItemCmdPrice = getState('ui.menuManagement.input.createMenuItemCmd.price') ?? '';
        this.createMenuItemCmdStatus = getState('ui.menuManagement.input.createMenuItemCmd.status') ?? '';
        this.createMenuItemCmdImageUrl = getState('ui.menuManagement.input.createMenuItemCmd.imageUrl') ?? '';
        this.createMenuItemCmdDisplayOrder = getState('ui.menuManagement.input.createMenuItemCmd.displayOrder') ?? '';
        this.createMenuItemCmdRequiresStockLink = getState('ui.menuManagement.input.createMenuItemCmd.requiresStockLink') ?? '';
        this.createMenuItemCmdOutput = getState('ui.menuManagement.output.createMenuItemCmd') ?? null;
        this.createMenuItemCmdError = getState('ui.menuManagement.action.createMenuItemCmd.error') ?? '';
        this.updateMenuItemCmdState = getState('ui.menuManagement.action.updateMenuItemCmd.status') ?? 'idle';
        this.updateMenuItemCmdMenuItemId = getState('ui.menuManagement.input.updateMenuItemCmd.menuItemId') ?? '';
        this.updateMenuItemCmdMenuCategoryId = getState('ui.menuManagement.input.updateMenuItemCmd.menuCategoryId') ?? '';
        this.updateMenuItemCmdName = getState('ui.menuManagement.input.updateMenuItemCmd.name') ?? '';
        this.updateMenuItemCmdDescription = getState('ui.menuManagement.input.updateMenuItemCmd.description') ?? '';
        this.updateMenuItemCmdPrice = getState('ui.menuManagement.input.updateMenuItemCmd.price') ?? '';
        this.updateMenuItemCmdStatus = getState('ui.menuManagement.input.updateMenuItemCmd.status') ?? '';
        this.updateMenuItemCmdPauseReason = getState('ui.menuManagement.input.updateMenuItemCmd.pauseReason') ?? '';
        this.updateMenuItemCmdImageUrl = getState('ui.menuManagement.input.updateMenuItemCmd.imageUrl') ?? '';
        this.updateMenuItemCmdDisplayOrder = getState('ui.menuManagement.input.updateMenuItemCmd.displayOrder') ?? '';
        this.updateMenuItemCmdRequiresStockLink = getState('ui.menuManagement.input.updateMenuItemCmd.requiresStockLink') ?? '';
        this.updateMenuItemCmdOutput = getState('ui.menuManagement.output.updateMenuItemCmd') ?? null;
        this.updateMenuItemCmdError = getState('ui.menuManagement.action.updateMenuItemCmd.error') ?? '';
        subscribe(this.subscribedKeys, this);
        void this.loadListMenuItems();
    }
    disconnectedCallback() {
        unsubscribe(this.subscribedKeys, this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.menuManagement.status':
                this.status = value ?? '';
                break;
            case 'ui.menuManagement.action.listMenuItems.status':
                this.listMenuItemsState = value ?? 'idle';
                break;
            case 'ui.menuManagement.input.listMenuItems.status':
                this.listMenuItemsStatus = value ?? '';
                break;
            case 'ui.menuManagement.input.listMenuItems.menuCategoryId':
                this.listMenuItemsMenuCategoryId = value ?? '';
                break;
            case 'ui.menuManagement.input.listMenuItems.name':
                this.listMenuItemsName = value ?? '';
                break;
            case 'ui.menuManagement.input.listMenuItems.page':
                this.listMenuItemsPage = value ?? '';
                break;
            case 'ui.menuManagement.input.listMenuItems.pageSize':
                this.listMenuItemsPageSize = value ?? '';
                break;
            case 'ui.menuManagement.data.listMenuItems':
                this.listMenuItemsData = value ?? { menuItems: [], total: 0 };
                break;
            case 'ui.menuManagement.action.createMenuItemCmd.status':
                this.createMenuItemCmdState = value ?? 'idle';
                break;
            case 'ui.menuManagement.input.createMenuItemCmd.menuCategoryId':
                this.createMenuItemCmdMenuCategoryId = value ?? '';
                break;
            case 'ui.menuManagement.input.createMenuItemCmd.name':
                this.createMenuItemCmdName = value ?? '';
                break;
            case 'ui.menuManagement.input.createMenuItemCmd.description':
                this.createMenuItemCmdDescription = value ?? '';
                break;
            case 'ui.menuManagement.input.createMenuItemCmd.price':
                this.createMenuItemCmdPrice = value ?? '';
                break;
            case 'ui.menuManagement.input.createMenuItemCmd.status':
                this.createMenuItemCmdStatus = value ?? '';
                break;
            case 'ui.menuManagement.input.createMenuItemCmd.imageUrl':
                this.createMenuItemCmdImageUrl = value ?? '';
                break;
            case 'ui.menuManagement.input.createMenuItemCmd.displayOrder':
                this.createMenuItemCmdDisplayOrder = value ?? '';
                break;
            case 'ui.menuManagement.input.createMenuItemCmd.requiresStockLink':
                this.createMenuItemCmdRequiresStockLink = value ?? '';
                break;
            case 'ui.menuManagement.output.createMenuItemCmd':
                this.createMenuItemCmdOutput = value ?? null;
                break;
            case 'ui.menuManagement.action.createMenuItemCmd.error':
                this.createMenuItemCmdError = value ?? '';
                break;
            case 'ui.menuManagement.action.updateMenuItemCmd.status':
                this.updateMenuItemCmdState = value ?? 'idle';
                break;
            case 'ui.menuManagement.input.updateMenuItemCmd.menuItemId':
                this.updateMenuItemCmdMenuItemId = value ?? '';
                break;
            case 'ui.menuManagement.input.updateMenuItemCmd.menuCategoryId':
                this.updateMenuItemCmdMenuCategoryId = value ?? '';
                break;
            case 'ui.menuManagement.input.updateMenuItemCmd.name':
                this.updateMenuItemCmdName = value ?? '';
                break;
            case 'ui.menuManagement.input.updateMenuItemCmd.description':
                this.updateMenuItemCmdDescription = value ?? '';
                break;
            case 'ui.menuManagement.input.updateMenuItemCmd.price':
                this.updateMenuItemCmdPrice = value ?? '';
                break;
            case 'ui.menuManagement.input.updateMenuItemCmd.status':
                this.updateMenuItemCmdStatus = value ?? '';
                break;
            case 'ui.menuManagement.input.updateMenuItemCmd.pauseReason':
                this.updateMenuItemCmdPauseReason = value ?? '';
                break;
            case 'ui.menuManagement.input.updateMenuItemCmd.imageUrl':
                this.updateMenuItemCmdImageUrl = value ?? '';
                break;
            case 'ui.menuManagement.input.updateMenuItemCmd.displayOrder':
                this.updateMenuItemCmdDisplayOrder = value ?? '';
                break;
            case 'ui.menuManagement.input.updateMenuItemCmd.requiresStockLink':
                this.updateMenuItemCmdRequiresStockLink = value ?? '';
                break;
            case 'ui.menuManagement.output.updateMenuItemCmd':
                this.updateMenuItemCmdOutput = value ?? null;
                break;
            case 'ui.menuManagement.action.updateMenuItemCmd.error':
                this.updateMenuItemCmdError = value ?? '';
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    applyRouteParams() {
        const patternParts = '/cafeFlow/menuManagement/:menuItemId?'.split('/').filter(Boolean);
        const pathParts = window.location.pathname.split('/').filter(Boolean);
        const params = {};
        for (let i = 0; i < patternParts.length; i++) {
            const part = patternParts[i];
            if (part.startsWith(':')) {
                const optional = part.endsWith('?');
                const name = optional ? part.slice(1, -1) : part.slice(1);
                const raw = pathParts[i];
                if (raw !== undefined && raw !== '') {
                    try {
                        params[name] = decodeURIComponent(raw);
                    }
                    catch {
                        params[name] = raw;
                    }
                }
            }
        }
        if (params['menuItemId'] !== undefined && params['menuItemId'] !== '') {
            this.updateMenuItemCmdMenuItemId = params['menuItemId'];
            setState('ui.menuManagement.input.updateMenuItemCmd.menuItemId', params['menuItemId']);
        }
    }
    parseOptionalNumber(value) {
        if (value === '' || value === undefined || value === null)
            return undefined;
        const n = Number(value);
        return Number.isFinite(n) ? n : undefined;
    }
    parseBoolean(value) {
        if (value === true)
            return true;
        const normalized = String(value).trim().toLowerCase();
        return normalized === 'true' || normalized === '1' || normalized === 'on' || normalized === 'yes';
    }
    /** action listMenuItems (query) — route cafeFlow.menuManagement.listMenuItems; inputs: status, menuCategoryId, name, page, pageSize; writes ui.menuManagement.data.listMenuItems; status ui.menuManagement.action.listMenuItems.status */
    async loadListMenuItems() {
        this.listMenuItemsState = 'loading';
        setState('ui.menuManagement.action.listMenuItems.status', 'loading');
        const params = {};
        if (this.listMenuItemsStatus !== '')
            params.status = this.listMenuItemsStatus;
        if (this.listMenuItemsMenuCategoryId !== '')
            params.menuCategoryId = this.listMenuItemsMenuCategoryId;
        if (this.listMenuItemsName !== '')
            params.name = this.listMenuItemsName;
        const page = this.parseOptionalNumber(this.listMenuItemsPage);
        if (page !== undefined)
            params.page = page;
        const pageSize = this.parseOptionalNumber(this.listMenuItemsPageSize);
        if (pageSize !== undefined)
            params.pageSize = pageSize;
        const options = { mode: 'silent' };
        const response = await execBff(listMenuItemsRoute, params, options);
        if (response.ok) {
            const data = response.data ?? LIST_MENU_ITEMS_DATA_DEFAULT;
            this.listMenuItemsData = data;
            setState('ui.menuManagement.data.listMenuItems', data);
            this.listMenuItemsState = 'success';
            setState('ui.menuManagement.action.listMenuItems.status', 'success');
        }
        else {
            console.error('listMenuItems failed', response.error);
            this.listMenuItemsState = 'error';
            setState('ui.menuManagement.action.listMenuItems.status', 'error');
        }
    }
    /** handler for action listMenuItems — bind UI events here */
    handleListMenuItemsClick(_event) {
        void this.loadListMenuItems();
    }
    /** action createMenuItemCmd (command) — route cafeFlow.menuManagement.createMenuItemCmd; inputs: menuCategoryId, name, description, price, status, imageUrl, displayOrder, requiresStockLink; writes ui.menuManagement.output.createMenuItemCmd; status ui.menuManagement.action.createMenuItemCmd.status; feedback keys action.createMenuItemCmd.success / action.createMenuItemCmd.error */
    async createMenuItemCmd() {
        this.createMenuItemCmdState = 'loading';
        setState('ui.menuManagement.action.createMenuItemCmd.status', 'loading');
        this.createMenuItemCmdError = '';
        setState('ui.menuManagement.action.createMenuItemCmd.error', '');
        const params = {
            menuCategoryId: this.createMenuItemCmdMenuCategoryId,
            name: this.createMenuItemCmdName,
            price: this.parseOptionalNumber(this.createMenuItemCmdPrice) ?? 0,
            requiresStockLink: this.parseBoolean(this.createMenuItemCmdRequiresStockLink),
        };
        if (this.createMenuItemCmdDescription !== '')
            params.description = this.createMenuItemCmdDescription;
        if (this.createMenuItemCmdStatus !== '')
            params.status = this.createMenuItemCmdStatus;
        if (this.createMenuItemCmdImageUrl !== '')
            params.imageUrl = this.createMenuItemCmdImageUrl;
        const displayOrder = this.parseOptionalNumber(this.createMenuItemCmdDisplayOrder);
        if (displayOrder !== undefined)
            params.displayOrder = displayOrder;
        const options = { mode: 'blocking' };
        const response = await execBff(createMenuItemCmdRoute, params, options);
        if (!response.ok) {
            const errMsg = response.error?.message ?? '';
            this.createMenuItemCmdError = errMsg;
            setState('ui.menuManagement.action.createMenuItemCmd.error', errMsg);
            this.createMenuItemCmdState = 'error';
            setState('ui.menuManagement.action.createMenuItemCmd.status', 'error');
            console.error('createMenuItemCmd failed', response.error);
            return;
        }
        const data = response.data ?? null;
        this.createMenuItemCmdOutput = data;
        setState('ui.menuManagement.output.createMenuItemCmd', data);
        try {
            await this.loadListMenuItems();
            if (this.listMenuItemsState === 'error') {
                this.createMenuItemCmdState = 'error';
                setState('ui.menuManagement.action.createMenuItemCmd.status', 'error');
                return;
            }
        }
        catch (err) {
            console.error('createMenuItemCmd refresh failed', err);
            this.createMenuItemCmdState = 'error';
            setState('ui.menuManagement.action.createMenuItemCmd.status', 'error');
            return;
        }
        this.createMenuItemCmdMenuCategoryId = '';
        setState('ui.menuManagement.input.createMenuItemCmd.menuCategoryId', '');
        this.createMenuItemCmdName = '';
        setState('ui.menuManagement.input.createMenuItemCmd.name', '');
        this.createMenuItemCmdDescription = '';
        setState('ui.menuManagement.input.createMenuItemCmd.description', '');
        this.createMenuItemCmdPrice = '';
        setState('ui.menuManagement.input.createMenuItemCmd.price', '');
        this.createMenuItemCmdStatus = '';
        setState('ui.menuManagement.input.createMenuItemCmd.status', '');
        this.createMenuItemCmdImageUrl = '';
        setState('ui.menuManagement.input.createMenuItemCmd.imageUrl', '');
        this.createMenuItemCmdDisplayOrder = '';
        setState('ui.menuManagement.input.createMenuItemCmd.displayOrder', '');
        this.createMenuItemCmdRequiresStockLink = '';
        setState('ui.menuManagement.input.createMenuItemCmd.requiresStockLink', '');
        this.createMenuItemCmdState = 'success';
        setState('ui.menuManagement.action.createMenuItemCmd.status', 'success');
    }
    /** handler for action createMenuItemCmd — bind UI events here */
    handleCreateMenuItemCmdClick(_event) {
        void runBlockingUiAction(async (_signal) => {
            await this.createMenuItemCmd();
        });
    }
    /** action updateMenuItemCmd (command) — route cafeFlow.menuManagement.updateMenuItemCmd; inputs: menuItemId, menuCategoryId, name, description, price, status, pauseReason, imageUrl, displayOrder, requiresStockLink; writes ui.menuManagement.output.updateMenuItemCmd; status ui.menuManagement.action.updateMenuItemCmd.status; feedback keys action.updateMenuItemCmd.success / action.updateMenuItemCmd.error */
    async updateMenuItemCmd() {
        this.applyRouteParams();
        if (!this.updateMenuItemCmdMenuItemId) {
            this.updateMenuItemCmdState = 'idle';
            setState('ui.menuManagement.action.updateMenuItemCmd.status', 'idle');
            return;
        }
        this.updateMenuItemCmdState = 'loading';
        setState('ui.menuManagement.action.updateMenuItemCmd.status', 'loading');
        this.updateMenuItemCmdError = '';
        setState('ui.menuManagement.action.updateMenuItemCmd.error', '');
        const params = {
            menuItemId: this.updateMenuItemCmdMenuItemId,
            menuCategoryId: this.updateMenuItemCmdMenuCategoryId,
            name: this.updateMenuItemCmdName,
            price: this.parseOptionalNumber(this.updateMenuItemCmdPrice) ?? 0,
            status: this.updateMenuItemCmdStatus,
            requiresStockLink: this.parseBoolean(this.updateMenuItemCmdRequiresStockLink),
        };
        if (this.updateMenuItemCmdDescription !== '')
            params.description = this.updateMenuItemCmdDescription;
        if (this.updateMenuItemCmdPauseReason !== '')
            params.pauseReason = this.updateMenuItemCmdPauseReason;
        if (this.updateMenuItemCmdImageUrl !== '')
            params.imageUrl = this.updateMenuItemCmdImageUrl;
        const displayOrder = this.parseOptionalNumber(this.updateMenuItemCmdDisplayOrder);
        if (displayOrder !== undefined)
            params.displayOrder = displayOrder;
        const options = { mode: 'blocking' };
        const response = await execBff(updateMenuItemCmdRoute, params, options);
        if (!response.ok) {
            const errMsg = response.error?.message ?? '';
            this.updateMenuItemCmdError = errMsg;
            setState('ui.menuManagement.action.updateMenuItemCmd.error', errMsg);
            this.updateMenuItemCmdState = 'error';
            setState('ui.menuManagement.action.updateMenuItemCmd.status', 'error');
            console.error('updateMenuItemCmd failed', response.error);
            return;
        }
        const data = response.data ?? null;
        this.updateMenuItemCmdOutput = data;
        setState('ui.menuManagement.output.updateMenuItemCmd', data);
        try {
            await this.loadListMenuItems();
            if (this.listMenuItemsState === 'error') {
                this.updateMenuItemCmdState = 'error';
                setState('ui.menuManagement.action.updateMenuItemCmd.status', 'error');
                return;
            }
        }
        catch (err) {
            console.error('updateMenuItemCmd refresh failed', err);
            this.updateMenuItemCmdState = 'error';
            setState('ui.menuManagement.action.updateMenuItemCmd.status', 'error');
            return;
        }
        this.updateMenuItemCmdMenuCategoryId = '';
        setState('ui.menuManagement.input.updateMenuItemCmd.menuCategoryId', '');
        this.updateMenuItemCmdName = '';
        setState('ui.menuManagement.input.updateMenuItemCmd.name', '');
        this.updateMenuItemCmdDescription = '';
        setState('ui.menuManagement.input.updateMenuItemCmd.description', '');
        this.updateMenuItemCmdPrice = '';
        setState('ui.menuManagement.input.updateMenuItemCmd.price', '');
        this.updateMenuItemCmdStatus = '';
        setState('ui.menuManagement.input.updateMenuItemCmd.status', '');
        this.updateMenuItemCmdPauseReason = '';
        setState('ui.menuManagement.input.updateMenuItemCmd.pauseReason', '');
        this.updateMenuItemCmdImageUrl = '';
        setState('ui.menuManagement.input.updateMenuItemCmd.imageUrl', '');
        this.updateMenuItemCmdDisplayOrder = '';
        setState('ui.menuManagement.input.updateMenuItemCmd.displayOrder', '');
        this.updateMenuItemCmdRequiresStockLink = '';
        setState('ui.menuManagement.input.updateMenuItemCmd.requiresStockLink', '');
        this.updateMenuItemCmdState = 'success';
        setState('ui.menuManagement.action.updateMenuItemCmd.status', 'success');
    }
    /** handler for action updateMenuItemCmd — bind UI events here */
    handleUpdateMenuItemCmdClick(_event) {
        void runBlockingUiAction(async (_signal) => {
            await this.updateMenuItemCmd();
        });
    }
    /** setter for state ui.menuManagement.input.listMenuItems.status */
    setListMenuItemsStatus(value) {
        this.listMenuItemsStatus = value;
        setState('ui.menuManagement.input.listMenuItems.status', value);
        this.requestUpdate();
    }
    /** handler for action set.listMenuItemsStatus — bind UI events here */
    handleListMenuItemsStatusChange(event) {
        const target = event.target;
        this.setListMenuItemsStatus(target?.value ?? '');
    }
    /** setter for state ui.menuManagement.input.listMenuItems.menuCategoryId */
    setListMenuItemsMenuCategoryId(value) {
        this.listMenuItemsMenuCategoryId = value;
        setState('ui.menuManagement.input.listMenuItems.menuCategoryId', value);
        this.requestUpdate();
    }
    /** handler for action set.listMenuItemsMenuCategoryId — bind UI events here */
    handleListMenuItemsMenuCategoryIdChange(event) {
        const target = event.target;
        this.setListMenuItemsMenuCategoryId(target?.value ?? '');
    }
    /** setter for state ui.menuManagement.input.listMenuItems.name */
    setListMenuItemsName(value) {
        this.listMenuItemsName = value;
        setState('ui.menuManagement.input.listMenuItems.name', value);
        this.requestUpdate();
    }
    /** handler for action set.listMenuItemsName — bind UI events here */
    handleListMenuItemsNameChange(event) {
        const target = event.target;
        this.setListMenuItemsName(target?.value ?? '');
    }
    /** setter for state ui.menuManagement.input.listMenuItems.page */
    setListMenuItemsPage(value) {
        this.listMenuItemsPage = value;
        setState('ui.menuManagement.input.listMenuItems.page', value);
        this.requestUpdate();
    }
    /** handler for action set.listMenuItemsPage — bind UI events here */
    handleListMenuItemsPageChange(event) {
        const target = event.target;
        this.setListMenuItemsPage(target?.value ?? '');
    }
    /** setter for state ui.menuManagement.input.listMenuItems.pageSize */
    setListMenuItemsPageSize(value) {
        this.listMenuItemsPageSize = value;
        setState('ui.menuManagement.input.listMenuItems.pageSize', value);
        this.requestUpdate();
    }
    /** handler for action set.listMenuItemsPageSize — bind UI events here */
    handleListMenuItemsPageSizeChange(event) {
        const target = event.target;
        this.setListMenuItemsPageSize(target?.value ?? '');
    }
    /** setter for state ui.menuManagement.input.createMenuItemCmd.menuCategoryId */
    setCreateMenuItemCmdMenuCategoryId(value) {
        this.createMenuItemCmdMenuCategoryId = value;
        setState('ui.menuManagement.input.createMenuItemCmd.menuCategoryId', value);
        this.requestUpdate();
    }
    /** handler for action set.createMenuItemCmdMenuCategoryId — bind UI events here */
    handleCreateMenuItemCmdMenuCategoryIdChange(event) {
        const target = event.target;
        this.setCreateMenuItemCmdMenuCategoryId(target?.value ?? '');
    }
    /** setter for state ui.menuManagement.input.createMenuItemCmd.name */
    setCreateMenuItemCmdName(value) {
        this.createMenuItemCmdName = value;
        setState('ui.menuManagement.input.createMenuItemCmd.name', value);
        this.requestUpdate();
    }
    /** handler for action set.createMenuItemCmdName — bind UI events here */
    handleCreateMenuItemCmdNameChange(event) {
        const target = event.target;
        this.setCreateMenuItemCmdName(target?.value ?? '');
    }
    /** setter for state ui.menuManagement.input.createMenuItemCmd.description */
    setCreateMenuItemCmdDescription(value) {
        this.createMenuItemCmdDescription = value;
        setState('ui.menuManagement.input.createMenuItemCmd.description', value);
        this.requestUpdate();
    }
    /** handler for action set.createMenuItemCmdDescription — bind UI events here */
    handleCreateMenuItemCmdDescriptionChange(event) {
        const target = event.target;
        this.setCreateMenuItemCmdDescription(target?.value ?? '');
    }
    /** setter for state ui.menuManagement.input.createMenuItemCmd.price */
    setCreateMenuItemCmdPrice(value) {
        this.createMenuItemCmdPrice = value;
        setState('ui.menuManagement.input.createMenuItemCmd.price', value);
        this.requestUpdate();
    }
    /** handler for action set.createMenuItemCmdPrice — bind UI events here */
    handleCreateMenuItemCmdPriceChange(event) {
        const target = event.target;
        this.setCreateMenuItemCmdPrice(target?.value ?? '');
    }
    /** setter for state ui.menuManagement.input.createMenuItemCmd.status */
    setCreateMenuItemCmdStatus(value) {
        this.createMenuItemCmdStatus = value;
        setState('ui.menuManagement.input.createMenuItemCmd.status', value);
        this.requestUpdate();
    }
    /** handler for action set.createMenuItemCmdStatus — bind UI events here */
    handleCreateMenuItemCmdStatusChange(event) {
        const target = event.target;
        this.setCreateMenuItemCmdStatus(target?.value ?? '');
    }
    /** setter for state ui.menuManagement.input.createMenuItemCmd.imageUrl */
    setCreateMenuItemCmdImageUrl(value) {
        this.createMenuItemCmdImageUrl = value;
        setState('ui.menuManagement.input.createMenuItemCmd.imageUrl', value);
        this.requestUpdate();
    }
    /** handler for action set.createMenuItemCmdImageUrl — bind UI events here */
    handleCreateMenuItemCmdImageUrlChange(event) {
        const target = event.target;
        this.setCreateMenuItemCmdImageUrl(target?.value ?? '');
    }
    /** setter for state ui.menuManagement.input.createMenuItemCmd.displayOrder */
    setCreateMenuItemCmdDisplayOrder(value) {
        this.createMenuItemCmdDisplayOrder = value;
        setState('ui.menuManagement.input.createMenuItemCmd.displayOrder', value);
        this.requestUpdate();
    }
    /** handler for action set.createMenuItemCmdDisplayOrder — bind UI events here */
    handleCreateMenuItemCmdDisplayOrderChange(event) {
        const target = event.target;
        this.setCreateMenuItemCmdDisplayOrder(target?.value ?? '');
    }
    /** setter for state ui.menuManagement.input.createMenuItemCmd.requiresStockLink */
    setCreateMenuItemCmdRequiresStockLink(value) {
        this.createMenuItemCmdRequiresStockLink = value;
        setState('ui.menuManagement.input.createMenuItemCmd.requiresStockLink', value);
        this.requestUpdate();
    }
    /** handler for action set.createMenuItemCmdRequiresStockLink — bind UI events here */
    handleCreateMenuItemCmdRequiresStockLinkChange(event) {
        const target = event.target;
        if (target && target instanceof HTMLInputElement && target.type === 'checkbox') {
            this.setCreateMenuItemCmdRequiresStockLink(target.checked ? 'true' : 'false');
            return;
        }
        this.setCreateMenuItemCmdRequiresStockLink(target?.value ?? '');
    }
    /** setter for state ui.menuManagement.input.updateMenuItemCmd.menuItemId */
    setUpdateMenuItemCmdMenuItemId(value) {
        this.updateMenuItemCmdMenuItemId = value;
        setState('ui.menuManagement.input.updateMenuItemCmd.menuItemId', value);
        this.requestUpdate();
    }
    /** handler for action set.updateMenuItemCmdMenuItemId — bind UI events here */
    handleUpdateMenuItemCmdMenuItemIdChange(event) {
        const target = event.target;
        this.setUpdateMenuItemCmdMenuItemId(target?.value ?? '');
    }
    /** setter for state ui.menuManagement.input.updateMenuItemCmd.menuCategoryId */
    setUpdateMenuItemCmdMenuCategoryId(value) {
        this.updateMenuItemCmdMenuCategoryId = value;
        setState('ui.menuManagement.input.updateMenuItemCmd.menuCategoryId', value);
        this.requestUpdate();
    }
    /** handler for action set.updateMenuItemCmdMenuCategoryId — bind UI events here */
    handleUpdateMenuItemCmdMenuCategoryIdChange(event) {
        const target = event.target;
        this.setUpdateMenuItemCmdMenuCategoryId(target?.value ?? '');
    }
    /** setter for state ui.menuManagement.input.updateMenuItemCmd.name */
    setUpdateMenuItemCmdName(value) {
        this.updateMenuItemCmdName = value;
        setState('ui.menuManagement.input.updateMenuItemCmd.name', value);
        this.requestUpdate();
    }
    /** handler for action set.updateMenuItemCmdName — bind UI events here */
    handleUpdateMenuItemCmdNameChange(event) {
        const target = event.target;
        this.setUpdateMenuItemCmdName(target?.value ?? '');
    }
    /** setter for state ui.menuManagement.input.updateMenuItemCmd.description */
    setUpdateMenuItemCmdDescription(value) {
        this.updateMenuItemCmdDescription = value;
        setState('ui.menuManagement.input.updateMenuItemCmd.description', value);
        this.requestUpdate();
    }
    /** handler for action set.updateMenuItemCmdDescription — bind UI events here */
    handleUpdateMenuItemCmdDescriptionChange(event) {
        const target = event.target;
        this.setUpdateMenuItemCmdDescription(target?.value ?? '');
    }
    /** setter for state ui.menuManagement.input.updateMenuItemCmd.price */
    setUpdateMenuItemCmdPrice(value) {
        this.updateMenuItemCmdPrice = value;
        setState('ui.menuManagement.input.updateMenuItemCmd.price', value);
        this.requestUpdate();
    }
    /** handler for action set.updateMenuItemCmdPrice — bind UI events here */
    handleUpdateMenuItemCmdPriceChange(event) {
        const target = event.target;
        this.setUpdateMenuItemCmdPrice(target?.value ?? '');
    }
    /** setter for state ui.menuManagement.input.updateMenuItemCmd.status */
    setUpdateMenuItemCmdStatus(value) {
        this.updateMenuItemCmdStatus = value;
        setState('ui.menuManagement.input.updateMenuItemCmd.status', value);
        this.requestUpdate();
    }
    /** handler for action set.updateMenuItemCmdStatus — bind UI events here */
    handleUpdateMenuItemCmdStatusChange(event) {
        const target = event.target;
        this.setUpdateMenuItemCmdStatus(target?.value ?? '');
    }
    /** setter for state ui.menuManagement.input.updateMenuItemCmd.pauseReason */
    setUpdateMenuItemCmdPauseReason(value) {
        this.updateMenuItemCmdPauseReason = value;
        setState('ui.menuManagement.input.updateMenuItemCmd.pauseReason', value);
        this.requestUpdate();
    }
    /** handler for action set.updateMenuItemCmdPauseReason — bind UI events here */
    handleUpdateMenuItemCmdPauseReasonChange(event) {
        const target = event.target;
        this.setUpdateMenuItemCmdPauseReason(target?.value ?? '');
    }
    /** setter for state ui.menuManagement.input.updateMenuItemCmd.imageUrl */
    setUpdateMenuItemCmdImageUrl(value) {
        this.updateMenuItemCmdImageUrl = value;
        setState('ui.menuManagement.input.updateMenuItemCmd.imageUrl', value);
        this.requestUpdate();
    }
    /** handler for action set.updateMenuItemCmdImageUrl — bind UI events here */
    handleUpdateMenuItemCmdImageUrlChange(event) {
        const target = event.target;
        this.setUpdateMenuItemCmdImageUrl(target?.value ?? '');
    }
    /** setter for state ui.menuManagement.input.updateMenuItemCmd.displayOrder */
    setUpdateMenuItemCmdDisplayOrder(value) {
        this.updateMenuItemCmdDisplayOrder = value;
        setState('ui.menuManagement.input.updateMenuItemCmd.displayOrder', value);
        this.requestUpdate();
    }
    /** handler for action set.updateMenuItemCmdDisplayOrder — bind UI events here */
    handleUpdateMenuItemCmdDisplayOrderChange(event) {
        const target = event.target;
        this.setUpdateMenuItemCmdDisplayOrder(target?.value ?? '');
    }
    /** setter for state ui.menuManagement.input.updateMenuItemCmd.requiresStockLink */
    setUpdateMenuItemCmdRequiresStockLink(value) {
        this.updateMenuItemCmdRequiresStockLink = value;
        setState('ui.menuManagement.input.updateMenuItemCmd.requiresStockLink', value);
        this.requestUpdate();
    }
    /** handler for action set.updateMenuItemCmdRequiresStockLink — bind UI events here */
    handleUpdateMenuItemCmdRequiresStockLinkChange(event) {
        const target = event.target;
        if (target && target instanceof HTMLInputElement && target.type === 'checkbox') {
            this.setUpdateMenuItemCmdRequiresStockLink(target.checked ? 'true' : 'false');
            return;
        }
        this.setUpdateMenuItemCmdRequiresStockLink(target?.value ?? '');
    }
}
__decorate([
    property()
], CafeFlowMenuManagementBase.prototype, "status", void 0);
__decorate([
    property()
], CafeFlowMenuManagementBase.prototype, "listMenuItemsState", void 0);
__decorate([
    property()
], CafeFlowMenuManagementBase.prototype, "listMenuItemsStatus", void 0);
__decorate([
    property()
], CafeFlowMenuManagementBase.prototype, "listMenuItemsMenuCategoryId", void 0);
__decorate([
    property()
], CafeFlowMenuManagementBase.prototype, "listMenuItemsName", void 0);
__decorate([
    property()
], CafeFlowMenuManagementBase.prototype, "listMenuItemsPage", void 0);
__decorate([
    property()
], CafeFlowMenuManagementBase.prototype, "listMenuItemsPageSize", void 0);
__decorate([
    property()
], CafeFlowMenuManagementBase.prototype, "listMenuItemsData", void 0);
__decorate([
    property()
], CafeFlowMenuManagementBase.prototype, "createMenuItemCmdState", void 0);
__decorate([
    property()
], CafeFlowMenuManagementBase.prototype, "createMenuItemCmdMenuCategoryId", void 0);
__decorate([
    property()
], CafeFlowMenuManagementBase.prototype, "createMenuItemCmdName", void 0);
__decorate([
    property()
], CafeFlowMenuManagementBase.prototype, "createMenuItemCmdDescription", void 0);
__decorate([
    property()
], CafeFlowMenuManagementBase.prototype, "createMenuItemCmdPrice", void 0);
__decorate([
    property()
], CafeFlowMenuManagementBase.prototype, "createMenuItemCmdStatus", void 0);
__decorate([
    property()
], CafeFlowMenuManagementBase.prototype, "createMenuItemCmdImageUrl", void 0);
__decorate([
    property()
], CafeFlowMenuManagementBase.prototype, "createMenuItemCmdDisplayOrder", void 0);
__decorate([
    property()
], CafeFlowMenuManagementBase.prototype, "createMenuItemCmdRequiresStockLink", void 0);
__decorate([
    property()
], CafeFlowMenuManagementBase.prototype, "createMenuItemCmdOutput", void 0);
__decorate([
    property()
], CafeFlowMenuManagementBase.prototype, "createMenuItemCmdError", void 0);
__decorate([
    property()
], CafeFlowMenuManagementBase.prototype, "updateMenuItemCmdState", void 0);
__decorate([
    property()
], CafeFlowMenuManagementBase.prototype, "updateMenuItemCmdMenuItemId", void 0);
__decorate([
    property()
], CafeFlowMenuManagementBase.prototype, "updateMenuItemCmdMenuCategoryId", void 0);
__decorate([
    property()
], CafeFlowMenuManagementBase.prototype, "updateMenuItemCmdName", void 0);
__decorate([
    property()
], CafeFlowMenuManagementBase.prototype, "updateMenuItemCmdDescription", void 0);
__decorate([
    property()
], CafeFlowMenuManagementBase.prototype, "updateMenuItemCmdPrice", void 0);
__decorate([
    property()
], CafeFlowMenuManagementBase.prototype, "updateMenuItemCmdStatus", void 0);
__decorate([
    property()
], CafeFlowMenuManagementBase.prototype, "updateMenuItemCmdPauseReason", void 0);
__decorate([
    property()
], CafeFlowMenuManagementBase.prototype, "updateMenuItemCmdImageUrl", void 0);
__decorate([
    property()
], CafeFlowMenuManagementBase.prototype, "updateMenuItemCmdDisplayOrder", void 0);
__decorate([
    property()
], CafeFlowMenuManagementBase.prototype, "updateMenuItemCmdRequiresStockLink", void 0);
__decorate([
    property()
], CafeFlowMenuManagementBase.prototype, "updateMenuItemCmdOutput", void 0);
__decorate([
    property()
], CafeFlowMenuManagementBase.prototype, "updateMenuItemCmdError", void 0);
