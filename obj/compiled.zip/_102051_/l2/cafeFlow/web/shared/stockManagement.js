/// <mls fileReference="_102051_/l2/cafeFlow/web/shared/stockManagement.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { listStockItemsRoute, addStockItemRoute, editStockItemRoute, removeStockItemRoute, registerStockAdjustmentRoute, } from '/_102051_/l2/cafeFlow/web/contracts/stockManagement.js';
/// **collab_i18n_start**
const message_pt = {
    'section.stockManagement.sec-stockItemList.title': 'Stock Item List',
    'organism.stockManagement.inline-row-command10.title': 'Inline row command',
    'intent.stockManagement.inline-row-command10.content.title': 'Inline row command',
    'organism.stockManagement.listStockItems.title': 'Listar itens de estoque',
    'intent.stockManagement.listStockItems.list.title': 'Listar itens de estoque',
    'intent.stockManagement.listStockItems.list.empty': 'Nenhum registro encontrado',
    'intent.stockManagement.listStockItems.list.column.stockItems.label': 'Stock Items',
    'intent.stockManagement.listStockItems.list.column.total.label': 'Total',
    'intent.stockManagement.listStockItems.list.filter.nameFilter.label': 'Name Filter',
    'intent.stockManagement.listStockItems.list.filter.lowStockOnly.label': 'Low Stock Only',
    'intent.stockManagement.listStockItems.list.filter.page.label': 'Page',
    'intent.stockManagement.listStockItems.list.filter.pageSize.label': 'Page Size',
    'organism.stockManagement.editStockItem.title': 'Atualizar item de estoque',
    'intent.stockManagement.editStockItem.form.title': 'Atualizar item de estoque',
    'intent.stockManagement.editStockItem.form.action.editStockItem': 'Atualizar item de estoque',
    'intent.stockManagement.editStockItem.form.field.name.label': 'Name',
    'intent.stockManagement.editStockItem.form.field.unit.label': 'Unit',
    'intent.stockManagement.editStockItem.form.field.minimumLevel.label': 'Minimum Level',
    'intent.stockManagement.editStockItem.form.field.description.label': 'Description',
    'organism.stockManagement.removeStockItem.title': 'Excluir item de estoque',
    'intent.stockManagement.removeStockItem.form.title': 'Excluir item de estoque',
    'intent.stockManagement.removeStockItem.form.action.removeStockItem': 'Excluir item de estoque',
    'organism.stockManagement.registerStockAdjustment.title': 'Registrar ajuste manual de estoque',
    'intent.stockManagement.registerStockAdjustment.form.title': 'Registrar ajuste manual de estoque',
    'intent.stockManagement.registerStockAdjustment.form.action.registerStockAdjustment': 'Registrar ajuste manual de estoque',
    'intent.stockManagement.registerStockAdjustment.form.field.stockItemId.label': 'Stock Item Id',
    'intent.stockManagement.registerStockAdjustment.form.field.quantity.label': 'Quantity',
    'intent.stockManagement.registerStockAdjustment.form.field.direction.label': 'Direction',
    'intent.stockManagement.registerStockAdjustment.form.field.reason.label': 'Reason',
    'intent.stockManagement.registerStockAdjustment.form.field.notes.label': 'Notes',
    'section.stockManagement.sec-createStockItem.title': 'Add New Stock Item',
    'organism.stockManagement.addStockItem.title': 'Criar item de estoque',
    'intent.stockManagement.addStockItem.form.title': 'Criar item de estoque',
    'intent.stockManagement.addStockItem.form.action.addStockItem': 'Criar item de estoque',
    'intent.stockManagement.addStockItem.form.field.name.label': 'Name',
    'intent.stockManagement.addStockItem.form.field.unit.label': 'Unit',
    'intent.stockManagement.addStockItem.form.field.currentBalance.label': 'Current Balance',
    'intent.stockManagement.addStockItem.form.field.minimumLevel.label': 'Minimum Level',
    'intent.stockManagement.addStockItem.form.field.description.label': 'Description',
    'section.stockManagement.sec-stock-overview.title': 'Visão geral do estoque',
    'section.stockManagement.sec-stock-master-detail.title': 'Controle de insumos',
    'section.stockManagement.sec-add-stock-item.title': 'Cadastrar novo insumo',
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
const LIST_STOCK_ITEMS_DEFAULT = { stockItems: [], total: 0 };
export class CafeFlowStockManagementBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state status — pageStatus */
        this.status = '';
        /** state listStockItemsState — actionStatus, values: idle|loading|success|error */
        this.listStockItemsState = 'idle';
        /** state listStockItemsNameFilter — input */
        this.listStockItemsNameFilter = '';
        /** state listStockItemsLowStockOnly — input */
        this.listStockItemsLowStockOnly = '';
        /** state listStockItemsPage — input */
        this.listStockItemsPage = '';
        /** state listStockItemsPageSize — input */
        this.listStockItemsPageSize = '';
        /** state listStockItemsData — queryResult, outputShape: paginated */
        this.listStockItemsData = { stockItems: [], total: 0 };
        /** state addStockItemState — actionStatus, values: idle|loading|success|error */
        this.addStockItemState = 'idle';
        /** state addStockItemName — input */
        this.addStockItemName = '';
        /** state addStockItemUnit — input */
        this.addStockItemUnit = '';
        /** state addStockItemCurrentBalance — input */
        this.addStockItemCurrentBalance = '';
        /** state addStockItemMinimumLevel — input */
        this.addStockItemMinimumLevel = '';
        /** state addStockItemDescription — input */
        this.addStockItemDescription = '';
        /** state addStockItemOutput — commandOutput */
        this.addStockItemOutput = null;
        /** state addStockItemError — actionError */
        this.addStockItemError = '';
        /** state editStockItemState — actionStatus, values: idle|loading|success|error */
        this.editStockItemState = 'idle';
        /** state editStockItemStockItemId — input */
        this.editStockItemStockItemId = '';
        /** state editStockItemName — input */
        this.editStockItemName = '';
        /** state editStockItemUnit — input */
        this.editStockItemUnit = '';
        /** state editStockItemMinimumLevel — input */
        this.editStockItemMinimumLevel = '';
        /** state editStockItemDescription — input */
        this.editStockItemDescription = '';
        /** state editStockItemOutput — commandOutput */
        this.editStockItemOutput = null;
        /** state editStockItemError — actionError */
        this.editStockItemError = '';
        /** state removeStockItemState — actionStatus, values: idle|loading|success|error */
        this.removeStockItemState = 'idle';
        /** state removeStockItemStockItemId — input */
        this.removeStockItemStockItemId = '';
        /** state removeStockItemOutput — commandOutput */
        this.removeStockItemOutput = null;
        /** state removeStockItemError — actionError */
        this.removeStockItemError = '';
        /** state registerStockAdjustmentState — actionStatus, values: idle|loading|success|error */
        this.registerStockAdjustmentState = 'idle';
        /** state registerStockAdjustmentStockItemId — input */
        this.registerStockAdjustmentStockItemId = '';
        /** state registerStockAdjustmentQuantity — input */
        this.registerStockAdjustmentQuantity = '';
        /** state registerStockAdjustmentDirection — input */
        this.registerStockAdjustmentDirection = '';
        /** state registerStockAdjustmentReason — input */
        this.registerStockAdjustmentReason = '';
        /** state registerStockAdjustmentNotes — input */
        this.registerStockAdjustmentNotes = '';
        /** state registerStockAdjustmentOutput — commandOutput */
        this.registerStockAdjustmentOutput = null;
        /** state registerStockAdjustmentError — actionError */
        this.registerStockAdjustmentError = '';
        this.subscribedKeys = [
            'ui.stockManagement.status',
            'ui.stockManagement.action.listStockItems.status',
            'ui.stockManagement.input.listStockItems.nameFilter',
            'ui.stockManagement.input.listStockItems.lowStockOnly',
            'ui.stockManagement.input.listStockItems.page',
            'ui.stockManagement.input.listStockItems.pageSize',
            'ui.stockManagement.data.listStockItems',
            'ui.stockManagement.action.addStockItem.status',
            'ui.stockManagement.input.addStockItem.name',
            'ui.stockManagement.input.addStockItem.unit',
            'ui.stockManagement.input.addStockItem.currentBalance',
            'ui.stockManagement.input.addStockItem.minimumLevel',
            'ui.stockManagement.input.addStockItem.description',
            'ui.stockManagement.output.addStockItem',
            'ui.stockManagement.action.addStockItem.error',
            'ui.stockManagement.action.editStockItem.status',
            'ui.stockManagement.input.editStockItem.stockItemId',
            'ui.stockManagement.input.editStockItem.name',
            'ui.stockManagement.input.editStockItem.unit',
            'ui.stockManagement.input.editStockItem.minimumLevel',
            'ui.stockManagement.input.editStockItem.description',
            'ui.stockManagement.output.editStockItem',
            'ui.stockManagement.action.editStockItem.error',
            'ui.stockManagement.action.removeStockItem.status',
            'ui.stockManagement.input.removeStockItem.stockItemId',
            'ui.stockManagement.output.removeStockItem',
            'ui.stockManagement.action.removeStockItem.error',
            'ui.stockManagement.action.registerStockAdjustment.status',
            'ui.stockManagement.input.registerStockAdjustment.stockItemId',
            'ui.stockManagement.input.registerStockAdjustment.quantity',
            'ui.stockManagement.input.registerStockAdjustment.direction',
            'ui.stockManagement.input.registerStockAdjustment.reason',
            'ui.stockManagement.input.registerStockAdjustment.notes',
            'ui.stockManagement.output.registerStockAdjustment',
            'ui.stockManagement.action.registerStockAdjustment.error',
        ];
    }
    /** i18n catalog — MessageType keys are the CLOSED msg vocabulary for page renders */
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.initStateValue('ui.stockManagement.status', 'status', '');
        this.initStateValue('ui.stockManagement.action.listStockItems.status', 'listStockItemsState', 'idle');
        this.initStateValue('ui.stockManagement.input.listStockItems.nameFilter', 'listStockItemsNameFilter', '');
        this.initStateValue('ui.stockManagement.input.listStockItems.lowStockOnly', 'listStockItemsLowStockOnly', '');
        this.initStateValue('ui.stockManagement.input.listStockItems.page', 'listStockItemsPage', '');
        this.initStateValue('ui.stockManagement.input.listStockItems.pageSize', 'listStockItemsPageSize', '');
        this.initStateValue('ui.stockManagement.data.listStockItems', 'listStockItemsData', LIST_STOCK_ITEMS_DEFAULT);
        this.initStateValue('ui.stockManagement.action.addStockItem.status', 'addStockItemState', 'idle');
        this.initStateValue('ui.stockManagement.input.addStockItem.name', 'addStockItemName', '');
        this.initStateValue('ui.stockManagement.input.addStockItem.unit', 'addStockItemUnit', '');
        this.initStateValue('ui.stockManagement.input.addStockItem.currentBalance', 'addStockItemCurrentBalance', '');
        this.initStateValue('ui.stockManagement.input.addStockItem.minimumLevel', 'addStockItemMinimumLevel', '');
        this.initStateValue('ui.stockManagement.input.addStockItem.description', 'addStockItemDescription', '');
        this.initStateValue('ui.stockManagement.output.addStockItem', 'addStockItemOutput', null);
        this.initStateValue('ui.stockManagement.action.addStockItem.error', 'addStockItemError', '');
        this.initStateValue('ui.stockManagement.action.editStockItem.status', 'editStockItemState', 'idle');
        this.initStateValue('ui.stockManagement.input.editStockItem.stockItemId', 'editStockItemStockItemId', '');
        this.initStateValue('ui.stockManagement.input.editStockItem.name', 'editStockItemName', '');
        this.initStateValue('ui.stockManagement.input.editStockItem.unit', 'editStockItemUnit', '');
        this.initStateValue('ui.stockManagement.input.editStockItem.minimumLevel', 'editStockItemMinimumLevel', '');
        this.initStateValue('ui.stockManagement.input.editStockItem.description', 'editStockItemDescription', '');
        this.initStateValue('ui.stockManagement.output.editStockItem', 'editStockItemOutput', null);
        this.initStateValue('ui.stockManagement.action.editStockItem.error', 'editStockItemError', '');
        this.initStateValue('ui.stockManagement.action.removeStockItem.status', 'removeStockItemState', 'idle');
        this.initStateValue('ui.stockManagement.input.removeStockItem.stockItemId', 'removeStockItemStockItemId', '');
        this.initStateValue('ui.stockManagement.output.removeStockItem', 'removeStockItemOutput', null);
        this.initStateValue('ui.stockManagement.action.removeStockItem.error', 'removeStockItemError', '');
        this.initStateValue('ui.stockManagement.action.registerStockAdjustment.status', 'registerStockAdjustmentState', 'idle');
        this.initStateValue('ui.stockManagement.input.registerStockAdjustment.stockItemId', 'registerStockAdjustmentStockItemId', '');
        this.initStateValue('ui.stockManagement.input.registerStockAdjustment.quantity', 'registerStockAdjustmentQuantity', '');
        this.initStateValue('ui.stockManagement.input.registerStockAdjustment.direction', 'registerStockAdjustmentDirection', '');
        this.initStateValue('ui.stockManagement.input.registerStockAdjustment.reason', 'registerStockAdjustmentReason', '');
        this.initStateValue('ui.stockManagement.input.registerStockAdjustment.notes', 'registerStockAdjustmentNotes', '');
        this.initStateValue('ui.stockManagement.output.registerStockAdjustment', 'registerStockAdjustmentOutput', null);
        this.initStateValue('ui.stockManagement.action.registerStockAdjustment.error', 'registerStockAdjustmentError', '');
        this.applyRouteParams();
        subscribe(this.subscribedKeys, this);
        void this.loadListStockItems();
    }
    disconnectedCallback() {
        unsubscribe(this.subscribedKeys, this);
        super.disconnectedCallback();
    }
    /** Deliver collabState notifications into local @property fields and re-render. */
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.stockManagement.status':
                this.status = value ?? '';
                break;
            case 'ui.stockManagement.action.listStockItems.status':
                this.listStockItemsState = value ?? 'idle';
                break;
            case 'ui.stockManagement.input.listStockItems.nameFilter':
                this.listStockItemsNameFilter = value ?? '';
                break;
            case 'ui.stockManagement.input.listStockItems.lowStockOnly':
                this.listStockItemsLowStockOnly = value ?? '';
                break;
            case 'ui.stockManagement.input.listStockItems.page':
                this.listStockItemsPage = value ?? '';
                break;
            case 'ui.stockManagement.input.listStockItems.pageSize':
                this.listStockItemsPageSize = value ?? '';
                break;
            case 'ui.stockManagement.data.listStockItems':
                this.listStockItemsData = value ?? LIST_STOCK_ITEMS_DEFAULT;
                break;
            case 'ui.stockManagement.action.addStockItem.status':
                this.addStockItemState = value ?? 'idle';
                break;
            case 'ui.stockManagement.input.addStockItem.name':
                this.addStockItemName = value ?? '';
                break;
            case 'ui.stockManagement.input.addStockItem.unit':
                this.addStockItemUnit = value ?? '';
                break;
            case 'ui.stockManagement.input.addStockItem.currentBalance':
                this.addStockItemCurrentBalance = value ?? '';
                break;
            case 'ui.stockManagement.input.addStockItem.minimumLevel':
                this.addStockItemMinimumLevel = value ?? '';
                break;
            case 'ui.stockManagement.input.addStockItem.description':
                this.addStockItemDescription = value ?? '';
                break;
            case 'ui.stockManagement.output.addStockItem':
                this.addStockItemOutput = value ?? null;
                break;
            case 'ui.stockManagement.action.addStockItem.error':
                this.addStockItemError = value ?? '';
                break;
            case 'ui.stockManagement.action.editStockItem.status':
                this.editStockItemState = value ?? 'idle';
                break;
            case 'ui.stockManagement.input.editStockItem.stockItemId':
                this.editStockItemStockItemId = value ?? '';
                break;
            case 'ui.stockManagement.input.editStockItem.name':
                this.editStockItemName = value ?? '';
                break;
            case 'ui.stockManagement.input.editStockItem.unit':
                this.editStockItemUnit = value ?? '';
                break;
            case 'ui.stockManagement.input.editStockItem.minimumLevel':
                this.editStockItemMinimumLevel = value ?? '';
                break;
            case 'ui.stockManagement.input.editStockItem.description':
                this.editStockItemDescription = value ?? '';
                break;
            case 'ui.stockManagement.output.editStockItem':
                this.editStockItemOutput = value ?? null;
                break;
            case 'ui.stockManagement.action.editStockItem.error':
                this.editStockItemError = value ?? '';
                break;
            case 'ui.stockManagement.action.removeStockItem.status':
                this.removeStockItemState = value ?? 'idle';
                break;
            case 'ui.stockManagement.input.removeStockItem.stockItemId':
                this.removeStockItemStockItemId = value ?? '';
                break;
            case 'ui.stockManagement.output.removeStockItem':
                this.removeStockItemOutput = value ?? null;
                break;
            case 'ui.stockManagement.action.removeStockItem.error':
                this.removeStockItemError = value ?? '';
                break;
            case 'ui.stockManagement.action.registerStockAdjustment.status':
                this.registerStockAdjustmentState = value ?? 'idle';
                break;
            case 'ui.stockManagement.input.registerStockAdjustment.stockItemId':
                this.registerStockAdjustmentStockItemId = value ?? '';
                break;
            case 'ui.stockManagement.input.registerStockAdjustment.quantity':
                this.registerStockAdjustmentQuantity = value ?? '';
                break;
            case 'ui.stockManagement.input.registerStockAdjustment.direction':
                this.registerStockAdjustmentDirection = value ?? '';
                break;
            case 'ui.stockManagement.input.registerStockAdjustment.reason':
                this.registerStockAdjustmentReason = value ?? '';
                break;
            case 'ui.stockManagement.input.registerStockAdjustment.notes':
                this.registerStockAdjustmentNotes = value ?? '';
                break;
            case 'ui.stockManagement.output.registerStockAdjustment':
                this.registerStockAdjustmentOutput = value ?? null;
                break;
            case 'ui.stockManagement.action.registerStockAdjustment.error':
                this.registerStockAdjustmentError = value ?? '';
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    initStateValue(stateKey, propName, defaultValue) {
        const existing = getState(stateKey);
        const value = existing !== undefined && existing !== null ? existing : defaultValue;
        this[propName] = value;
        if (existing === undefined || existing === null) {
            setState(stateKey, value);
        }
    }
    applyRouteParams() {
        const path = window.location.pathname;
        const match = path.match(/^\/cafeFlow\/stockManagement(?:\/([^/]+))?\/?$/);
        if (match && match[1]) {
            let segment = match[1];
            try {
                segment = decodeURIComponent(segment);
            }
            catch {
                // keep raw segment
            }
            if (segment && !this.editStockItemStockItemId) {
                this.editStockItemStockItemId = segment;
                setState('ui.stockManagement.input.editStockItem.stockItemId', segment);
            }
        }
    }
    parseOptionalNumber(raw) {
        if (raw === '' || raw === undefined || raw === null)
            return undefined;
        const n = Number(raw);
        return Number.isFinite(n) ? n : undefined;
    }
    parseOptionalBoolean(raw) {
        if (raw === '' || raw === undefined || raw === null)
            return undefined;
        if (raw === true)
            return true;
        if (raw === false)
            return false;
        const lowered = String(raw).toLowerCase();
        if (lowered === 'true' || lowered === '1' || lowered === 'yes')
            return true;
        if (lowered === 'false' || lowered === '0' || lowered === 'no')
            return false;
        return undefined;
    }
    readErrorMessage(error) {
        if (error && typeof error.message === 'string')
            return error.message;
        return '';
    }
    /** action listStockItems (query) — route cafeFlow.stockManagement.listStockItems; inputs: nameFilter, lowStockOnly, page, pageSize; writes ui.stockManagement.data.listStockItems; status ui.stockManagement.action.listStockItems.status */
    async loadListStockItems() {
        this.listStockItemsState = 'loading';
        setState('ui.stockManagement.action.listStockItems.status', 'loading');
        const params = {};
        if (this.listStockItemsNameFilter !== '')
            params.nameFilter = this.listStockItemsNameFilter;
        const lowStockOnly = this.parseOptionalBoolean(this.listStockItemsLowStockOnly);
        if (lowStockOnly !== undefined)
            params.lowStockOnly = lowStockOnly;
        const page = this.parseOptionalNumber(this.listStockItemsPage);
        if (page !== undefined)
            params.page = page;
        const pageSize = this.parseOptionalNumber(this.listStockItemsPageSize);
        if (pageSize !== undefined)
            params.pageSize = pageSize;
        const options = { mode: 'silent' };
        const response = await execBff(listStockItemsRoute, params, options);
        if (!response.ok) {
            this.listStockItemsState = 'error';
            setState('ui.stockManagement.action.listStockItems.status', 'error');
            return;
        }
        const data = response.data ?? LIST_STOCK_ITEMS_DEFAULT;
        this.listStockItemsData = data;
        setState('ui.stockManagement.data.listStockItems', data);
        this.listStockItemsState = 'success';
        setState('ui.stockManagement.action.listStockItems.status', 'success');
    }
    /** handler for action listStockItems — bind UI events here */
    handleListStockItemsClick(_event) {
        void this.loadListStockItems();
    }
    /** action addStockItem (command) — route cafeFlow.stockManagement.addStockItem; inputs: name, unit, currentBalance, minimumLevel, description; writes ui.stockManagement.output.addStockItem; status ui.stockManagement.action.addStockItem.status; feedback keys action.addStockItem.success / action.addStockItem.error */
    async addStockItem() {
        this.addStockItemState = 'loading';
        setState('ui.stockManagement.action.addStockItem.status', 'loading');
        this.addStockItemError = '';
        setState('ui.stockManagement.action.addStockItem.error', '');
        const params = {
            name: this.addStockItemName,
            unit: this.addStockItemUnit,
            currentBalance: Number(this.addStockItemCurrentBalance),
            minimumLevel: Number(this.addStockItemMinimumLevel),
        };
        if (this.addStockItemDescription !== '')
            params.description = this.addStockItemDescription;
        const options = { mode: 'blocking' };
        const response = await execBff(addStockItemRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error);
            this.addStockItemError = errMsg;
            setState('ui.stockManagement.action.addStockItem.error', errMsg);
            this.addStockItemState = 'error';
            setState('ui.stockManagement.action.addStockItem.status', 'error');
            return;
        }
        const data = response.data ?? null;
        this.addStockItemOutput = data;
        setState('ui.stockManagement.output.addStockItem', data);
        await this.loadListStockItems();
        if (this.listStockItemsState === 'error') {
            this.addStockItemState = 'error';
            setState('ui.stockManagement.action.addStockItem.status', 'error');
            return;
        }
        this.addStockItemName = '';
        setState('ui.stockManagement.input.addStockItem.name', '');
        this.addStockItemUnit = '';
        setState('ui.stockManagement.input.addStockItem.unit', '');
        this.addStockItemCurrentBalance = '';
        setState('ui.stockManagement.input.addStockItem.currentBalance', '');
        this.addStockItemMinimumLevel = '';
        setState('ui.stockManagement.input.addStockItem.minimumLevel', '');
        this.addStockItemDescription = '';
        setState('ui.stockManagement.input.addStockItem.description', '');
        this.addStockItemState = 'success';
        setState('ui.stockManagement.action.addStockItem.status', 'success');
    }
    /** handler for action addStockItem — bind UI events here */
    handleAddStockItemClick(_event) {
        void runBlockingUiAction(async (_signal) => {
            await this.addStockItem();
        });
    }
    /** action editStockItem (command) — route cafeFlow.stockManagement.editStockItem; inputs: stockItemId, name, unit, minimumLevel, description; writes ui.stockManagement.output.editStockItem; status ui.stockManagement.action.editStockItem.status; feedback keys action.editStockItem.success / action.editStockItem.error */
    async editStockItem() {
        this.applyRouteParams();
        if (!this.editStockItemStockItemId) {
            this.editStockItemState = 'idle';
            setState('ui.stockManagement.action.editStockItem.status', 'idle');
            return;
        }
        this.editStockItemState = 'loading';
        setState('ui.stockManagement.action.editStockItem.status', 'loading');
        this.editStockItemError = '';
        setState('ui.stockManagement.action.editStockItem.error', '');
        const params = {
            stockItemId: this.editStockItemStockItemId,
            name: this.editStockItemName,
            unit: this.editStockItemUnit,
            minimumLevel: Number(this.editStockItemMinimumLevel),
        };
        if (this.editStockItemDescription !== '')
            params.description = this.editStockItemDescription;
        const options = { mode: 'blocking' };
        const response = await execBff(editStockItemRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error);
            this.editStockItemError = errMsg;
            setState('ui.stockManagement.action.editStockItem.error', errMsg);
            this.editStockItemState = 'error';
            setState('ui.stockManagement.action.editStockItem.status', 'error');
            return;
        }
        const data = response.data ?? null;
        this.editStockItemOutput = data;
        setState('ui.stockManagement.output.editStockItem', data);
        await this.loadListStockItems();
        if (this.listStockItemsState === 'error') {
            this.editStockItemState = 'error';
            setState('ui.stockManagement.action.editStockItem.status', 'error');
            return;
        }
        this.editStockItemName = '';
        setState('ui.stockManagement.input.editStockItem.name', '');
        this.editStockItemUnit = '';
        setState('ui.stockManagement.input.editStockItem.unit', '');
        this.editStockItemMinimumLevel = '';
        setState('ui.stockManagement.input.editStockItem.minimumLevel', '');
        this.editStockItemDescription = '';
        setState('ui.stockManagement.input.editStockItem.description', '');
        this.editStockItemState = 'success';
        setState('ui.stockManagement.action.editStockItem.status', 'success');
    }
    /** handler for action editStockItem — bind UI events here */
    handleEditStockItemClick(_event) {
        void runBlockingUiAction(async (_signal) => {
            await this.editStockItem();
        });
    }
    /** action removeStockItem (command) — route cafeFlow.stockManagement.removeStockItem; inputs: stockItemId; writes ui.stockManagement.output.removeStockItem; status ui.stockManagement.action.removeStockItem.status; feedback keys action.removeStockItem.success / action.removeStockItem.error */
    async removeStockItem() {
        this.removeStockItemState = 'loading';
        setState('ui.stockManagement.action.removeStockItem.status', 'loading');
        this.removeStockItemError = '';
        setState('ui.stockManagement.action.removeStockItem.error', '');
        const params = {
            stockItemId: this.removeStockItemStockItemId,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(removeStockItemRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error);
            this.removeStockItemError = errMsg;
            setState('ui.stockManagement.action.removeStockItem.error', errMsg);
            this.removeStockItemState = 'error';
            setState('ui.stockManagement.action.removeStockItem.status', 'error');
            return;
        }
        const data = response.data ?? null;
        this.removeStockItemOutput = data;
        setState('ui.stockManagement.output.removeStockItem', data);
        await this.loadListStockItems();
        if (this.listStockItemsState === 'error') {
            this.removeStockItemState = 'error';
            setState('ui.stockManagement.action.removeStockItem.status', 'error');
            return;
        }
        this.removeStockItemStockItemId = '';
        setState('ui.stockManagement.input.removeStockItem.stockItemId', '');
        this.removeStockItemState = 'success';
        setState('ui.stockManagement.action.removeStockItem.status', 'success');
    }
    /** handler for action removeStockItem — bind UI events here */
    handleRemoveStockItemClick(_event) {
        void runBlockingUiAction(async (_signal) => {
            await this.removeStockItem();
        });
    }
    /** action registerStockAdjustment (command) — route cafeFlow.stockManagement.registerStockAdjustment; inputs: stockItemId, quantity, direction, reason, notes; writes ui.stockManagement.output.registerStockAdjustment; status ui.stockManagement.action.registerStockAdjustment.status; feedback keys action.registerStockAdjustment.success / action.registerStockAdjustment.error */
    async registerStockAdjustment() {
        this.registerStockAdjustmentState = 'loading';
        setState('ui.stockManagement.action.registerStockAdjustment.status', 'loading');
        this.registerStockAdjustmentError = '';
        setState('ui.stockManagement.action.registerStockAdjustment.error', '');
        const params = {
            stockItemId: this.registerStockAdjustmentStockItemId,
            quantity: Number(this.registerStockAdjustmentQuantity),
            direction: this.registerStockAdjustmentDirection,
            reason: this.registerStockAdjustmentReason,
        };
        if (this.registerStockAdjustmentNotes !== '')
            params.notes = this.registerStockAdjustmentNotes;
        const options = { mode: 'blocking' };
        const response = await execBff(registerStockAdjustmentRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error);
            this.registerStockAdjustmentError = errMsg;
            setState('ui.stockManagement.action.registerStockAdjustment.error', errMsg);
            this.registerStockAdjustmentState = 'error';
            setState('ui.stockManagement.action.registerStockAdjustment.status', 'error');
            return;
        }
        const data = response.data ?? null;
        this.registerStockAdjustmentOutput = data;
        setState('ui.stockManagement.output.registerStockAdjustment', data);
        await this.loadListStockItems();
        if (this.listStockItemsState === 'error') {
            this.registerStockAdjustmentState = 'error';
            setState('ui.stockManagement.action.registerStockAdjustment.status', 'error');
            return;
        }
        this.registerStockAdjustmentStockItemId = '';
        setState('ui.stockManagement.input.registerStockAdjustment.stockItemId', '');
        this.registerStockAdjustmentQuantity = '';
        setState('ui.stockManagement.input.registerStockAdjustment.quantity', '');
        this.registerStockAdjustmentDirection = '';
        setState('ui.stockManagement.input.registerStockAdjustment.direction', '');
        this.registerStockAdjustmentReason = '';
        setState('ui.stockManagement.input.registerStockAdjustment.reason', '');
        this.registerStockAdjustmentNotes = '';
        setState('ui.stockManagement.input.registerStockAdjustment.notes', '');
        this.registerStockAdjustmentState = 'success';
        setState('ui.stockManagement.action.registerStockAdjustment.status', 'success');
    }
    /** handler for action registerStockAdjustment — bind UI events here */
    handleRegisterStockAdjustmentClick(_event) {
        void runBlockingUiAction(async (_signal) => {
            await this.registerStockAdjustment();
        });
    }
    /** setter for state ui.stockManagement.input.listStockItems.nameFilter */
    setListStockItemsNameFilter(value) {
        this.listStockItemsNameFilter = value;
        setState('ui.stockManagement.input.listStockItems.nameFilter', value);
        this.requestUpdate();
    }
    /** handler for action set.listStockItemsNameFilter — bind UI events here */
    handleListStockItemsNameFilterChange(event) {
        const target = event.target;
        this.setListStockItemsNameFilter(target.value);
    }
    /** setter for state ui.stockManagement.input.listStockItems.lowStockOnly */
    setListStockItemsLowStockOnly(value) {
        this.listStockItemsLowStockOnly = value;
        setState('ui.stockManagement.input.listStockItems.lowStockOnly', value);
        this.requestUpdate();
    }
    /** handler for action set.listStockItemsLowStockOnly — bind UI events here */
    handleListStockItemsLowStockOnlyChange(event) {
        const target = event.target;
        const value = target.type === 'checkbox' ? String(target.checked) : target.value;
        this.setListStockItemsLowStockOnly(value);
    }
    /** setter for state ui.stockManagement.input.listStockItems.page */
    setListStockItemsPage(value) {
        this.listStockItemsPage = value;
        setState('ui.stockManagement.input.listStockItems.page', value);
        this.requestUpdate();
    }
    /** handler for action set.listStockItemsPage — bind UI events here */
    handleListStockItemsPageChange(event) {
        const target = event.target;
        this.setListStockItemsPage(target.value);
    }
    /** setter for state ui.stockManagement.input.listStockItems.pageSize */
    setListStockItemsPageSize(value) {
        this.listStockItemsPageSize = value;
        setState('ui.stockManagement.input.listStockItems.pageSize', value);
        this.requestUpdate();
    }
    /** handler for action set.listStockItemsPageSize — bind UI events here */
    handleListStockItemsPageSizeChange(event) {
        const target = event.target;
        this.setListStockItemsPageSize(target.value);
    }
    /** setter for state ui.stockManagement.input.addStockItem.name */
    setAddStockItemName(value) {
        this.addStockItemName = value;
        setState('ui.stockManagement.input.addStockItem.name', value);
        this.requestUpdate();
    }
    /** handler for action set.addStockItemName — bind UI events here */
    handleAddStockItemNameChange(event) {
        const target = event.target;
        this.setAddStockItemName(target.value);
    }
    /** setter for state ui.stockManagement.input.addStockItem.unit */
    setAddStockItemUnit(value) {
        this.addStockItemUnit = value;
        setState('ui.stockManagement.input.addStockItem.unit', value);
        this.requestUpdate();
    }
    /** handler for action set.addStockItemUnit — bind UI events here */
    handleAddStockItemUnitChange(event) {
        const target = event.target;
        this.setAddStockItemUnit(target.value);
    }
    /** setter for state ui.stockManagement.input.addStockItem.currentBalance */
    setAddStockItemCurrentBalance(value) {
        this.addStockItemCurrentBalance = value;
        setState('ui.stockManagement.input.addStockItem.currentBalance', value);
        this.requestUpdate();
    }
    /** handler for action set.addStockItemCurrentBalance — bind UI events here */
    handleAddStockItemCurrentBalanceChange(event) {
        const target = event.target;
        this.setAddStockItemCurrentBalance(target.value);
    }
    /** setter for state ui.stockManagement.input.addStockItem.minimumLevel */
    setAddStockItemMinimumLevel(value) {
        this.addStockItemMinimumLevel = value;
        setState('ui.stockManagement.input.addStockItem.minimumLevel', value);
        this.requestUpdate();
    }
    /** handler for action set.addStockItemMinimumLevel — bind UI events here */
    handleAddStockItemMinimumLevelChange(event) {
        const target = event.target;
        this.setAddStockItemMinimumLevel(target.value);
    }
    /** setter for state ui.stockManagement.input.addStockItem.description */
    setAddStockItemDescription(value) {
        this.addStockItemDescription = value;
        setState('ui.stockManagement.input.addStockItem.description', value);
        this.requestUpdate();
    }
    /** handler for action set.addStockItemDescription — bind UI events here */
    handleAddStockItemDescriptionChange(event) {
        const target = event.target;
        this.setAddStockItemDescription(target.value);
    }
    /** setter for state ui.stockManagement.input.editStockItem.stockItemId */
    setEditStockItemStockItemId(value) {
        this.editStockItemStockItemId = value;
        setState('ui.stockManagement.input.editStockItem.stockItemId', value);
        this.requestUpdate();
    }
    /** handler for action set.editStockItemStockItemId — bind UI events here */
    handleEditStockItemStockItemIdChange(event) {
        const target = event.target;
        this.setEditStockItemStockItemId(target.value);
    }
    /** setter for state ui.stockManagement.input.editStockItem.name */
    setEditStockItemName(value) {
        this.editStockItemName = value;
        setState('ui.stockManagement.input.editStockItem.name', value);
        this.requestUpdate();
    }
    /** handler for action set.editStockItemName — bind UI events here */
    handleEditStockItemNameChange(event) {
        const target = event.target;
        this.setEditStockItemName(target.value);
    }
    /** setter for state ui.stockManagement.input.editStockItem.unit */
    setEditStockItemUnit(value) {
        this.editStockItemUnit = value;
        setState('ui.stockManagement.input.editStockItem.unit', value);
        this.requestUpdate();
    }
    /** handler for action set.editStockItemUnit — bind UI events here */
    handleEditStockItemUnitChange(event) {
        const target = event.target;
        this.setEditStockItemUnit(target.value);
    }
    /** setter for state ui.stockManagement.input.editStockItem.minimumLevel */
    setEditStockItemMinimumLevel(value) {
        this.editStockItemMinimumLevel = value;
        setState('ui.stockManagement.input.editStockItem.minimumLevel', value);
        this.requestUpdate();
    }
    /** handler for action set.editStockItemMinimumLevel — bind UI events here */
    handleEditStockItemMinimumLevelChange(event) {
        const target = event.target;
        this.setEditStockItemMinimumLevel(target.value);
    }
    /** setter for state ui.stockManagement.input.editStockItem.description */
    setEditStockItemDescription(value) {
        this.editStockItemDescription = value;
        setState('ui.stockManagement.input.editStockItem.description', value);
        this.requestUpdate();
    }
    /** handler for action set.editStockItemDescription — bind UI events here */
    handleEditStockItemDescriptionChange(event) {
        const target = event.target;
        this.setEditStockItemDescription(target.value);
    }
    /** setter for state ui.stockManagement.input.removeStockItem.stockItemId */
    setRemoveStockItemStockItemId(value) {
        this.removeStockItemStockItemId = value;
        setState('ui.stockManagement.input.removeStockItem.stockItemId', value);
        this.requestUpdate();
    }
    /** handler for action set.removeStockItemStockItemId — bind UI events here */
    handleRemoveStockItemStockItemIdChange(event) {
        const target = event.target;
        this.setRemoveStockItemStockItemId(target.value);
    }
    /** setter for state ui.stockManagement.input.registerStockAdjustment.stockItemId */
    setRegisterStockAdjustmentStockItemId(value) {
        this.registerStockAdjustmentStockItemId = value;
        setState('ui.stockManagement.input.registerStockAdjustment.stockItemId', value);
        this.requestUpdate();
    }
    /** handler for action set.registerStockAdjustmentStockItemId — bind UI events here */
    handleRegisterStockAdjustmentStockItemIdChange(event) {
        const target = event.target;
        this.setRegisterStockAdjustmentStockItemId(target.value);
    }
    /** setter for state ui.stockManagement.input.registerStockAdjustment.quantity */
    setRegisterStockAdjustmentQuantity(value) {
        this.registerStockAdjustmentQuantity = value;
        setState('ui.stockManagement.input.registerStockAdjustment.quantity', value);
        this.requestUpdate();
    }
    /** handler for action set.registerStockAdjustmentQuantity — bind UI events here */
    handleRegisterStockAdjustmentQuantityChange(event) {
        const target = event.target;
        this.setRegisterStockAdjustmentQuantity(target.value);
    }
    /** setter for state ui.stockManagement.input.registerStockAdjustment.direction */
    setRegisterStockAdjustmentDirection(value) {
        this.registerStockAdjustmentDirection = value;
        setState('ui.stockManagement.input.registerStockAdjustment.direction', value);
        this.requestUpdate();
    }
    /** handler for action set.registerStockAdjustmentDirection — bind UI events here */
    handleRegisterStockAdjustmentDirectionChange(event) {
        const target = event.target;
        this.setRegisterStockAdjustmentDirection(target.value);
    }
    /** setter for state ui.stockManagement.input.registerStockAdjustment.reason */
    setRegisterStockAdjustmentReason(value) {
        this.registerStockAdjustmentReason = value;
        setState('ui.stockManagement.input.registerStockAdjustment.reason', value);
        this.requestUpdate();
    }
    /** handler for action set.registerStockAdjustmentReason — bind UI events here */
    handleRegisterStockAdjustmentReasonChange(event) {
        const target = event.target;
        this.setRegisterStockAdjustmentReason(target.value);
    }
    /** setter for state ui.stockManagement.input.registerStockAdjustment.notes */
    setRegisterStockAdjustmentNotes(value) {
        this.registerStockAdjustmentNotes = value;
        setState('ui.stockManagement.input.registerStockAdjustment.notes', value);
        this.requestUpdate();
    }
    /** handler for action set.registerStockAdjustmentNotes — bind UI events here */
    handleRegisterStockAdjustmentNotesChange(event) {
        const target = event.target;
        this.setRegisterStockAdjustmentNotes(target.value);
    }
}
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "status", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "listStockItemsState", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "listStockItemsNameFilter", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "listStockItemsLowStockOnly", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "listStockItemsPage", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "listStockItemsPageSize", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "listStockItemsData", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "addStockItemState", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "addStockItemName", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "addStockItemUnit", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "addStockItemCurrentBalance", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "addStockItemMinimumLevel", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "addStockItemDescription", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "addStockItemOutput", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "addStockItemError", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "editStockItemState", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "editStockItemStockItemId", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "editStockItemName", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "editStockItemUnit", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "editStockItemMinimumLevel", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "editStockItemDescription", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "editStockItemOutput", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "editStockItemError", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "removeStockItemState", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "removeStockItemStockItemId", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "removeStockItemOutput", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "removeStockItemError", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "registerStockAdjustmentState", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "registerStockAdjustmentStockItemId", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "registerStockAdjustmentQuantity", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "registerStockAdjustmentDirection", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "registerStockAdjustmentReason", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "registerStockAdjustmentNotes", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "registerStockAdjustmentOutput", void 0);
__decorate([
    property()
], CafeFlowStockManagementBase.prototype, "registerStockAdjustmentError", void 0);
