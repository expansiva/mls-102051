/// <mls fileReference="_102051_/l2/cafeFlow/web/shared/kitchenWorkspace.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { fetchKitchenQueueRoute, changeOrderStatusRoute, } from '/_102051_/l2/cafeFlow/web/contracts/kitchenWorkspace.js';
/// **collab_i18n_start**
const message_pt = {
    "section.kitchenWorkspace.kitchenQueueSection.title": "Fila da Cozinha",
    "organism.kitchenWorkspace.fetchKitchenQueue.title": "Ver fila da cozinha",
    "intent.kitchenWorkspace.fetchKitchenQueue.list.title": "Ver fila da cozinha",
    "intent.kitchenWorkspace.fetchKitchenQueue.list.empty": "Nenhum registro encontrado",
    "intent.kitchenWorkspace.fetchKitchenQueue.list.column.orderId.label": "Order Id",
    "intent.kitchenWorkspace.fetchKitchenQueue.list.column.orderType.label": "Order Type",
    "intent.kitchenWorkspace.fetchKitchenQueue.list.column.tableNumber.label": "Table Number",
    "intent.kitchenWorkspace.fetchKitchenQueue.list.column.customerName.label": "Customer Name",
    "intent.kitchenWorkspace.fetchKitchenQueue.list.column.notes.label": "Notes",
    "intent.kitchenWorkspace.fetchKitchenQueue.list.column.status.label": "Status",
    "intent.kitchenWorkspace.fetchKitchenQueue.list.column.confirmedAt.label": "Confirmed At",
    "intent.kitchenWorkspace.fetchKitchenQueue.list.column.inPreparationAt.label": "In Preparation At",
    "intent.kitchenWorkspace.fetchKitchenQueue.list.column.items.label": "Items",
    "intent.kitchenWorkspace.fetchKitchenQueue.list.filter.dailyShiftId.label": "Daily Shift Id",
    "organism.kitchenWorkspace.changeOrderStatus.title": "Atualizar status do pedido",
    "intent.kitchenWorkspace.changeOrderStatus.form.title": "Atualizar status do pedido",
    "intent.kitchenWorkspace.changeOrderStatus.form.action.changeOrderStatus": "Atualizar status do pedido",
    "intent.kitchenWorkspace.changeOrderStatus.form.field.status.label": "Status",
    "intent.kitchenWorkspace.changeOrderStatus.form.field.cancellationReason.label": "Cancellation Reason",
    "intent.kitchenWorkspace.changeOrderStatus.form.field.updatedAt.label": "Updated At",
    "section.kitchenWorkspace.sec-kitchen-queue.title": "Fila da Cozinha",
    "action.changeOrderStatus.success": "Status do pedido atualizado",
    "action.changeOrderStatus.error": "Nao foi possivel atualizar o status do pedido",
};
const messages = { pt: message_pt };
export class CafeFlowKitchenWorkspaceBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state ui.kitchenWorkspace.status — pageStatus */
        this.status = "";
        /** state ui.kitchenWorkspace.action.fetchKitchenQueue.status — actionStatus, values: idle|loading|success|error */
        this.fetchKitchenQueueState = "idle";
        /** state ui.kitchenWorkspace.input.fetchKitchenQueue.dailyShiftId — input */
        this.fetchKitchenQueueDailyShiftId = "";
        /** state ui.kitchenWorkspace.data.fetchKitchenQueue — queryResult, outputShape: array */
        this.fetchKitchenQueueData = [];
        /** state ui.kitchenWorkspace.action.changeOrderStatus.status — actionStatus, values: idle|loading|success|error */
        this.changeOrderStatusState = "idle";
        /** state ui.kitchenWorkspace.input.changeOrderStatus.orderId — input */
        this.changeOrderStatusOrderId = "";
        /** state ui.kitchenWorkspace.input.changeOrderStatus.status — input */
        this.changeOrderStatusStatus = "";
        /** state ui.kitchenWorkspace.input.changeOrderStatus.cancellationReason — input */
        this.changeOrderStatusCancellationReason = "";
        /** state ui.kitchenWorkspace.input.changeOrderStatus.updatedAt — input */
        this.changeOrderStatusUpdatedAt = "";
        /** state ui.kitchenWorkspace.output.changeOrderStatus — commandOutput */
        this.changeOrderStatusOutput = null;
        /** state ui.kitchenWorkspace.action.changeOrderStatus.error — actionError */
        this.changeOrderStatusError = "";
        this._subscribedKeys = [
            "ui.kitchenWorkspace.status",
            "ui.kitchenWorkspace.action.fetchKitchenQueue.status",
            "ui.kitchenWorkspace.input.fetchKitchenQueue.dailyShiftId",
            "ui.kitchenWorkspace.data.fetchKitchenQueue",
            "ui.kitchenWorkspace.action.changeOrderStatus.status",
            "ui.kitchenWorkspace.input.changeOrderStatus.orderId",
            "ui.kitchenWorkspace.input.changeOrderStatus.status",
            "ui.kitchenWorkspace.input.changeOrderStatus.cancellationReason",
            "ui.kitchenWorkspace.input.changeOrderStatus.updatedAt",
            "ui.kitchenWorkspace.output.changeOrderStatus",
            "ui.kitchenWorkspace.action.changeOrderStatus.error",
        ];
    }
    /** i18n catalog — MessageType keys are the CLOSED msg vocabulary for page renders */
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    initStateValue(stateKey, fallback) {
        const existing = getState(stateKey);
        return existing !== undefined && existing !== null ? existing : fallback;
    }
    triggerUpdate() {
        const host = this;
        if (typeof host.requestUpdate === "function") {
            host.requestUpdate();
        }
    }
    callSuperConnected() {
        const proto = CollabLitElement.prototype;
        if (typeof proto.connectedCallback === "function") {
            proto.connectedCallback.call(this);
        }
    }
    callSuperDisconnected() {
        const proto = CollabLitElement.prototype;
        if (typeof proto.disconnectedCallback === "function") {
            proto.disconnectedCallback.call(this);
        }
    }
    connectedCallback() {
        this.callSuperConnected();
        this.status = this.initStateValue("ui.kitchenWorkspace.status", "");
        this.fetchKitchenQueueState = this.initStateValue("ui.kitchenWorkspace.action.fetchKitchenQueue.status", "idle");
        this.fetchKitchenQueueDailyShiftId = this.initStateValue("ui.kitchenWorkspace.input.fetchKitchenQueue.dailyShiftId", "");
        this.fetchKitchenQueueData = this.initStateValue("ui.kitchenWorkspace.data.fetchKitchenQueue", []);
        this.changeOrderStatusState = this.initStateValue("ui.kitchenWorkspace.action.changeOrderStatus.status", "idle");
        this.changeOrderStatusOrderId = this.initStateValue("ui.kitchenWorkspace.input.changeOrderStatus.orderId", "");
        this.changeOrderStatusStatus = this.initStateValue("ui.kitchenWorkspace.input.changeOrderStatus.status", "");
        this.changeOrderStatusCancellationReason = this.initStateValue("ui.kitchenWorkspace.input.changeOrderStatus.cancellationReason", "");
        this.changeOrderStatusUpdatedAt = this.initStateValue("ui.kitchenWorkspace.input.changeOrderStatus.updatedAt", "");
        this.changeOrderStatusOutput = this.initStateValue("ui.kitchenWorkspace.output.changeOrderStatus", null);
        this.changeOrderStatusError = this.initStateValue("ui.kitchenWorkspace.action.changeOrderStatus.error", "");
        subscribe(this._subscribedKeys, this);
    }
    disconnectedCallback() {
        unsubscribe(this._subscribedKeys, this);
        this.callSuperDisconnected();
    }
    handleIcaStateChange(key, value) {
        switch (key) {
            case "ui.kitchenWorkspace.status":
                this.status = value ?? "";
                break;
            case "ui.kitchenWorkspace.action.fetchKitchenQueue.status":
                this.fetchKitchenQueueState = value ?? "idle";
                break;
            case "ui.kitchenWorkspace.input.fetchKitchenQueue.dailyShiftId":
                this.fetchKitchenQueueDailyShiftId = value ?? "";
                break;
            case "ui.kitchenWorkspace.data.fetchKitchenQueue":
                this.fetchKitchenQueueData = value ?? [];
                break;
            case "ui.kitchenWorkspace.action.changeOrderStatus.status":
                this.changeOrderStatusState = value ?? "idle";
                break;
            case "ui.kitchenWorkspace.input.changeOrderStatus.orderId":
                this.changeOrderStatusOrderId = value ?? "";
                break;
            case "ui.kitchenWorkspace.input.changeOrderStatus.status":
                this.changeOrderStatusStatus = value ?? "";
                break;
            case "ui.kitchenWorkspace.input.changeOrderStatus.cancellationReason":
                this.changeOrderStatusCancellationReason = value ?? "";
                break;
            case "ui.kitchenWorkspace.input.changeOrderStatus.updatedAt":
                this.changeOrderStatusUpdatedAt = value ?? "";
                break;
            case "ui.kitchenWorkspace.output.changeOrderStatus":
                this.changeOrderStatusOutput = value ?? null;
                break;
            case "ui.kitchenWorkspace.action.changeOrderStatus.error":
                this.changeOrderStatusError = value ?? "";
                break;
            default:
                break;
        }
        this.triggerUpdate();
    }
    /** action fetchKitchenQueue (query) — route cafeFlow.kitchenWorkspace.fetchKitchenQueue; inputs: dailyShiftId; writes ui.kitchenWorkspace.data.fetchKitchenQueue; status ui.kitchenWorkspace.action.fetchKitchenQueue.status */
    async loadFetchKitchenQueue() {
        this.fetchKitchenQueueState = "loading";
        setState("ui.kitchenWorkspace.action.fetchKitchenQueue.status", "loading");
        const params = {
            dailyShiftId: this.fetchKitchenQueueDailyShiftId,
        };
        const options = { mode: "silent" };
        const response = await execBff(fetchKitchenQueueRoute, params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.fetchKitchenQueueData = data;
            setState("ui.kitchenWorkspace.data.fetchKitchenQueue", data);
            this.fetchKitchenQueueState = "success";
            setState("ui.kitchenWorkspace.action.fetchKitchenQueue.status", "success");
        }
        else {
            this.fetchKitchenQueueState = "error";
            setState("ui.kitchenWorkspace.action.fetchKitchenQueue.status", "error");
            if (response.error) {
                console.error("fetchKitchenQueue failed", response.error);
            }
        }
        this.triggerUpdate();
    }
    /** handler for action fetchKitchenQueue — bind UI events here */
    handleFetchKitchenQueueClick(_event) {
        void this.loadFetchKitchenQueue();
    }
    /** action changeOrderStatus (command) — route cafeFlow.kitchenWorkspace.changeOrderStatus; inputs: orderId, status, cancellationReason, updatedAt; writes ui.kitchenWorkspace.output.changeOrderStatus; status ui.kitchenWorkspace.action.changeOrderStatus.status; feedback keys action.changeOrderStatus.success / action.changeOrderStatus.error */
    async changeOrderStatus() {
        this.changeOrderStatusState = "loading";
        setState("ui.kitchenWorkspace.action.changeOrderStatus.status", "loading");
        this.changeOrderStatusError = "";
        setState("ui.kitchenWorkspace.action.changeOrderStatus.error", "");
        const params = {
            orderId: this.changeOrderStatusOrderId,
            status: this.changeOrderStatusStatus,
            updatedAt: this.changeOrderStatusUpdatedAt,
        };
        if (this.changeOrderStatusCancellationReason) {
            params.cancellationReason = this.changeOrderStatusCancellationReason;
        }
        const options = { mode: "blocking" };
        const response = await execBff(changeOrderStatusRoute, params, options);
        if (!response.ok) {
            const errMsg = response.error?.message ||
                message_pt["action.changeOrderStatus.error"];
            this.changeOrderStatusError = errMsg;
            setState("ui.kitchenWorkspace.action.changeOrderStatus.error", errMsg);
            this.changeOrderStatusState = "error";
            setState("ui.kitchenWorkspace.action.changeOrderStatus.status", "error");
            this.triggerUpdate();
            return;
        }
        const data = response.data ?? null;
        this.changeOrderStatusOutput = data;
        setState("ui.kitchenWorkspace.output.changeOrderStatus", data);
        try {
            await this.loadFetchKitchenQueue();
            if (this.fetchKitchenQueueState === "error") {
                this.changeOrderStatusState = "error";
                setState("ui.kitchenWorkspace.action.changeOrderStatus.status", "error");
                this.triggerUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error("changeOrderStatus refresh failed", refreshError);
            this.changeOrderStatusState = "error";
            setState("ui.kitchenWorkspace.action.changeOrderStatus.status", "error");
            this.triggerUpdate();
            return;
        }
        this.changeOrderStatusOrderId = "";
        setState("ui.kitchenWorkspace.input.changeOrderStatus.orderId", "");
        this.changeOrderStatusStatus = "";
        setState("ui.kitchenWorkspace.input.changeOrderStatus.status", "");
        this.changeOrderStatusCancellationReason = "";
        setState("ui.kitchenWorkspace.input.changeOrderStatus.cancellationReason", "");
        this.changeOrderStatusUpdatedAt = "";
        setState("ui.kitchenWorkspace.input.changeOrderStatus.updatedAt", "");
        this.changeOrderStatusState = "success";
        setState("ui.kitchenWorkspace.action.changeOrderStatus.status", "success");
        this.triggerUpdate();
    }
    /** handler for action changeOrderStatus — bind UI events here */
    handleChangeOrderStatusClick(_event) {
        void runBlockingUiAction(async (_signal) => {
            await this.changeOrderStatus();
        });
    }
    /** setter for state ui.kitchenWorkspace.input.fetchKitchenQueue.dailyShiftId */
    setFetchKitchenQueueDailyShiftId(value) {
        this.fetchKitchenQueueDailyShiftId = value;
        setState("ui.kitchenWorkspace.input.fetchKitchenQueue.dailyShiftId", value);
        this.triggerUpdate();
    }
    /** handler for action set.fetchKitchenQueueDailyShiftId — bind UI events here */
    handleFetchKitchenQueueDailyShiftIdChange(event) {
        const target = event.target;
        const value = target?.value ?? "";
        this.setFetchKitchenQueueDailyShiftId(value);
    }
    /** setter for state ui.kitchenWorkspace.input.changeOrderStatus.orderId */
    setChangeOrderStatusOrderId(value) {
        this.changeOrderStatusOrderId = value;
        setState("ui.kitchenWorkspace.input.changeOrderStatus.orderId", value);
        const collection = getState("ui.kitchenWorkspace.data.fetchKitchenQueue") ?? this.fetchKitchenQueueData;
        if (Array.isArray(collection) && collection.length > 0) {
            const item = collection.find((row) => String(row.orderId) === String(value));
            if (item) {
                if (item.status !== null && item.status !== undefined) {
                    this.changeOrderStatusStatus = item.status;
                    setState("ui.kitchenWorkspace.input.changeOrderStatus.status", item.status);
                }
            }
        }
        this.triggerUpdate();
    }
    /** handler for action set.changeOrderStatusOrderId — bind UI events here */
    handleChangeOrderStatusOrderIdChange(event) {
        const target = event.target;
        const value = target?.value ?? "";
        this.setChangeOrderStatusOrderId(value);
    }
    /** setter for state ui.kitchenWorkspace.input.changeOrderStatus.status */
    setChangeOrderStatusStatus(value) {
        this.changeOrderStatusStatus = value;
        setState("ui.kitchenWorkspace.input.changeOrderStatus.status", value);
        this.triggerUpdate();
    }
    /** handler for action set.changeOrderStatusStatus — bind UI events here */
    handleChangeOrderStatusStatusChange(event) {
        const target = event.target;
        const value = target?.value ?? "";
        this.setChangeOrderStatusStatus(value);
    }
    /** setter for state ui.kitchenWorkspace.input.changeOrderStatus.cancellationReason */
    setChangeOrderStatusCancellationReason(value) {
        this.changeOrderStatusCancellationReason = value;
        setState("ui.kitchenWorkspace.input.changeOrderStatus.cancellationReason", value);
        this.triggerUpdate();
    }
    /** handler for action set.changeOrderStatusCancellationReason — bind UI events here */
    handleChangeOrderStatusCancellationReasonChange(event) {
        const target = event.target;
        const value = target?.value ?? "";
        this.setChangeOrderStatusCancellationReason(value);
    }
    /** setter for state ui.kitchenWorkspace.input.changeOrderStatus.updatedAt */
    setChangeOrderStatusUpdatedAt(value) {
        this.changeOrderStatusUpdatedAt = value;
        setState("ui.kitchenWorkspace.input.changeOrderStatus.updatedAt", value);
        this.triggerUpdate();
    }
    /** handler for action set.changeOrderStatusUpdatedAt — bind UI events here */
    handleChangeOrderStatusUpdatedAtChange(event) {
        const target = event.target;
        const value = target?.value ?? "";
        this.setChangeOrderStatusUpdatedAt(value);
    }
}
__decorate([
    property()
], CafeFlowKitchenWorkspaceBase.prototype, "status", void 0);
__decorate([
    property()
], CafeFlowKitchenWorkspaceBase.prototype, "fetchKitchenQueueState", void 0);
__decorate([
    property()
], CafeFlowKitchenWorkspaceBase.prototype, "fetchKitchenQueueDailyShiftId", void 0);
__decorate([
    property()
], CafeFlowKitchenWorkspaceBase.prototype, "fetchKitchenQueueData", void 0);
__decorate([
    property()
], CafeFlowKitchenWorkspaceBase.prototype, "changeOrderStatusState", void 0);
__decorate([
    property()
], CafeFlowKitchenWorkspaceBase.prototype, "changeOrderStatusOrderId", void 0);
__decorate([
    property()
], CafeFlowKitchenWorkspaceBase.prototype, "changeOrderStatusStatus", void 0);
__decorate([
    property()
], CafeFlowKitchenWorkspaceBase.prototype, "changeOrderStatusCancellationReason", void 0);
__decorate([
    property()
], CafeFlowKitchenWorkspaceBase.prototype, "changeOrderStatusUpdatedAt", void 0);
__decorate([
    property()
], CafeFlowKitchenWorkspaceBase.prototype, "changeOrderStatusOutput", void 0);
__decorate([
    property()
], CafeFlowKitchenWorkspaceBase.prototype, "changeOrderStatusError", void 0);
