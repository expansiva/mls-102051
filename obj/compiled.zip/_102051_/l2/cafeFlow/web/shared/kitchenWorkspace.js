/// <mls fileReference="_102051_/l2/cafeFlow/web/shared/kitchenWorkspace.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { fetchKitchenQueueRoute, changeOrderStatusRoute, } from '/_102051_/l2/cafeFlow/web/contracts/kitchenWorkspace.js';
/// **collab_i18n_start**
const message_pt = {
    'section.kitchenWorkspace.kitchenQueueSection.title': 'Fila da Cozinha',
    'organism.kitchenWorkspace.fetchKitchenQueue.title': 'Ver fila da cozinha',
    'intent.kitchenWorkspace.fetchKitchenQueue.list.title': 'Ver fila da cozinha',
    'intent.kitchenWorkspace.fetchKitchenQueue.list.empty': 'Nenhum registro encontrado',
    'intent.kitchenWorkspace.fetchKitchenQueue.list.column.orderId.label': 'Order Id',
    'intent.kitchenWorkspace.fetchKitchenQueue.list.column.orderType.label': 'Order Type',
    'intent.kitchenWorkspace.fetchKitchenQueue.list.column.tableNumber.label': 'Table Number',
    'intent.kitchenWorkspace.fetchKitchenQueue.list.column.customerName.label': 'Customer Name',
    'intent.kitchenWorkspace.fetchKitchenQueue.list.column.notes.label': 'Notes',
    'intent.kitchenWorkspace.fetchKitchenQueue.list.column.status.label': 'Status',
    'intent.kitchenWorkspace.fetchKitchenQueue.list.column.confirmedAt.label': 'Confirmed At',
    'intent.kitchenWorkspace.fetchKitchenQueue.list.column.inPreparationAt.label': 'In Preparation At',
    'intent.kitchenWorkspace.fetchKitchenQueue.list.column.items.label': 'Items',
    'intent.kitchenWorkspace.fetchKitchenQueue.list.filter.dailyShiftId.label': 'Daily Shift Id',
    'organism.kitchenWorkspace.changeOrderStatus.title': 'Atualizar status do pedido',
    'intent.kitchenWorkspace.changeOrderStatus.form.title': 'Atualizar status do pedido',
    'intent.kitchenWorkspace.changeOrderStatus.form.action.changeOrderStatus': 'Atualizar status do pedido',
    'intent.kitchenWorkspace.changeOrderStatus.form.field.status.label': 'Status',
    'intent.kitchenWorkspace.changeOrderStatus.form.field.cancellationReason.label': 'Cancellation Reason',
    'intent.kitchenWorkspace.changeOrderStatus.form.field.updatedAt.label': 'Updated At',
    'section.kitchenWorkspace.kitchen-queue-section.title': 'Fila da Cozinha',
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
export class CafeFlowKitchenWorkspaceBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state status — pageStatus */
        this.status = '';
        /** state fetchKitchenQueueState — actionStatus, values: idle|loading|success|error */
        this.fetchKitchenQueueState = 'idle';
        /** state fetchKitchenQueueDailyShiftId — input */
        this.fetchKitchenQueueDailyShiftId = '';
        /** state fetchKitchenQueueData — queryResult, outputShape: array */
        this.fetchKitchenQueueData = [];
        /** state changeOrderStatusState — actionStatus, values: idle|loading|success|error */
        this.changeOrderStatusState = 'idle';
        /** state changeOrderStatusOrderId — input */
        this.changeOrderStatusOrderId = '';
        /** state changeOrderStatusStatus — input */
        this.changeOrderStatusStatus = '';
        /** state changeOrderStatusCancellationReason — input */
        this.changeOrderStatusCancellationReason = '';
        /** state changeOrderStatusUpdatedAt — input */
        this.changeOrderStatusUpdatedAt = '';
        /** state changeOrderStatusOutput — commandOutput */
        this.changeOrderStatusOutput = null;
        /** state changeOrderStatusError — actionError */
        this.changeOrderStatusError = '';
        this.subscribedKeys = [
            'ui.kitchenWorkspace.status',
            'ui.kitchenWorkspace.action.fetchKitchenQueue.status',
            'ui.kitchenWorkspace.input.fetchKitchenQueue.dailyShiftId',
            'ui.kitchenWorkspace.data.fetchKitchenQueue',
            'ui.kitchenWorkspace.action.changeOrderStatus.status',
            'ui.kitchenWorkspace.input.changeOrderStatus.orderId',
            'ui.kitchenWorkspace.input.changeOrderStatus.status',
            'ui.kitchenWorkspace.input.changeOrderStatus.cancellationReason',
            'ui.kitchenWorkspace.input.changeOrderStatus.updatedAt',
            'ui.kitchenWorkspace.output.changeOrderStatus',
            'ui.kitchenWorkspace.action.changeOrderStatus.error',
        ];
    }
    /** i18n catalog — MessageType keys are the CLOSED msg vocabulary for page renders */
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.initStateValue('ui.kitchenWorkspace.status', 'status', '');
        this.initStateValue('ui.kitchenWorkspace.action.fetchKitchenQueue.status', 'fetchKitchenQueueState', 'idle');
        this.initStateValue('ui.kitchenWorkspace.input.fetchKitchenQueue.dailyShiftId', 'fetchKitchenQueueDailyShiftId', '');
        this.initStateValue('ui.kitchenWorkspace.data.fetchKitchenQueue', 'fetchKitchenQueueData', []);
        this.initStateValue('ui.kitchenWorkspace.action.changeOrderStatus.status', 'changeOrderStatusState', 'idle');
        this.initStateValue('ui.kitchenWorkspace.input.changeOrderStatus.orderId', 'changeOrderStatusOrderId', '');
        this.initStateValue('ui.kitchenWorkspace.input.changeOrderStatus.status', 'changeOrderStatusStatus', '');
        this.initStateValue('ui.kitchenWorkspace.input.changeOrderStatus.cancellationReason', 'changeOrderStatusCancellationReason', '');
        this.initStateValue('ui.kitchenWorkspace.input.changeOrderStatus.updatedAt', 'changeOrderStatusUpdatedAt', '');
        this.initStateValue('ui.kitchenWorkspace.output.changeOrderStatus', 'changeOrderStatusOutput', null);
        this.initStateValue('ui.kitchenWorkspace.action.changeOrderStatus.error', 'changeOrderStatusError', '');
        subscribe(this.subscribedKeys, this);
    }
    disconnectedCallback() {
        unsubscribe(this.subscribedKeys, this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.kitchenWorkspace.status':
                this.status = value;
                break;
            case 'ui.kitchenWorkspace.action.fetchKitchenQueue.status':
                this.fetchKitchenQueueState = value;
                break;
            case 'ui.kitchenWorkspace.input.fetchKitchenQueue.dailyShiftId':
                this.fetchKitchenQueueDailyShiftId = value;
                break;
            case 'ui.kitchenWorkspace.data.fetchKitchenQueue':
                this.fetchKitchenQueueData = value;
                break;
            case 'ui.kitchenWorkspace.action.changeOrderStatus.status':
                this.changeOrderStatusState = value;
                break;
            case 'ui.kitchenWorkspace.input.changeOrderStatus.orderId':
                this.changeOrderStatusOrderId = value;
                break;
            case 'ui.kitchenWorkspace.input.changeOrderStatus.status':
                this.changeOrderStatusStatus = value;
                break;
            case 'ui.kitchenWorkspace.input.changeOrderStatus.cancellationReason':
                this.changeOrderStatusCancellationReason = value;
                break;
            case 'ui.kitchenWorkspace.input.changeOrderStatus.updatedAt':
                this.changeOrderStatusUpdatedAt = value;
                break;
            case 'ui.kitchenWorkspace.output.changeOrderStatus':
                this.changeOrderStatusOutput = value;
                break;
            case 'ui.kitchenWorkspace.action.changeOrderStatus.error':
                this.changeOrderStatusError = value;
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    initStateValue(stateKey, propName, defaultValue) {
        const existing = getState(stateKey);
        const value = existing !== undefined && existing !== null ? existing : defaultValue;
        this[propName] = value;
        if (existing === undefined || existing === null) {
            setState(stateKey, value);
        }
    }
    /** action fetchKitchenQueue (query) — route cafeFlow.kitchenWorkspace.fetchKitchenQueue; inputs: dailyShiftId; writes ui.kitchenWorkspace.data.fetchKitchenQueue; status ui.kitchenWorkspace.action.fetchKitchenQueue.status */
    async loadFetchKitchenQueue() {
        this.fetchKitchenQueueState = 'loading';
        setState('ui.kitchenWorkspace.action.fetchKitchenQueue.status', 'loading');
        const params = {
            dailyShiftId: this.fetchKitchenQueueDailyShiftId,
        };
        const options = { mode: 'silent' };
        const response = await execBff(fetchKitchenQueueRoute, params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.fetchKitchenQueueData = data;
            setState('ui.kitchenWorkspace.data.fetchKitchenQueue', data);
            this.fetchKitchenQueueState = 'success';
            setState('ui.kitchenWorkspace.action.fetchKitchenQueue.status', 'success');
        }
        else {
            this.fetchKitchenQueueState = 'error';
            setState('ui.kitchenWorkspace.action.fetchKitchenQueue.status', 'error');
            if (response.error) {
                console.error('fetchKitchenQueue failed', response.error);
            }
        }
    }
    /** handler for action fetchKitchenQueue — bind UI events here */
    handleFetchKitchenQueueClick(_event) {
        void this.loadFetchKitchenQueue();
    }
    /** action changeOrderStatus (command) — route cafeFlow.kitchenWorkspace.changeOrderStatus; inputs: orderId, status, cancellationReason, updatedAt; writes ui.kitchenWorkspace.output.changeOrderStatus; status ui.kitchenWorkspace.action.changeOrderStatus.status; feedback keys action.changeOrderStatus.success / action.changeOrderStatus.error */
    async changeOrderStatus() {
        this.changeOrderStatusState = 'loading';
        setState('ui.kitchenWorkspace.action.changeOrderStatus.status', 'loading');
        this.changeOrderStatusError = '';
        setState('ui.kitchenWorkspace.action.changeOrderStatus.error', '');
        const params = {
            orderId: this.changeOrderStatusOrderId,
            status: this.changeOrderStatusStatus,
            cancellationReason: this.changeOrderStatusCancellationReason || undefined,
            updatedAt: this.changeOrderStatusUpdatedAt,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(changeOrderStatusRoute, params, options);
        if (response.ok) {
            const data = response.data ?? null;
            this.changeOrderStatusOutput = data;
            setState('ui.kitchenWorkspace.output.changeOrderStatus', data);
            try {
                await this.loadFetchKitchenQueue();
                if (this.fetchKitchenQueueState === 'error') {
                    this.changeOrderStatusState = 'error';
                    setState('ui.kitchenWorkspace.action.changeOrderStatus.status', 'error');
                    return;
                }
            }
            catch (refreshError) {
                this.changeOrderStatusState = 'error';
                setState('ui.kitchenWorkspace.action.changeOrderStatus.status', 'error');
                console.error('changeOrderStatus refresh failed', refreshError);
                return;
            }
            this.changeOrderStatusOrderId = '';
            setState('ui.kitchenWorkspace.input.changeOrderStatus.orderId', '');
            this.changeOrderStatusStatus = '';
            setState('ui.kitchenWorkspace.input.changeOrderStatus.status', '');
            this.changeOrderStatusCancellationReason = '';
            setState('ui.kitchenWorkspace.input.changeOrderStatus.cancellationReason', '');
            this.changeOrderStatusUpdatedAt = '';
            setState('ui.kitchenWorkspace.input.changeOrderStatus.updatedAt', '');
            this.changeOrderStatusState = 'success';
            setState('ui.kitchenWorkspace.action.changeOrderStatus.status', 'success');
        }
        else {
            const errorMessage = response.error?.message ?? '';
            this.changeOrderStatusError = errorMessage;
            setState('ui.kitchenWorkspace.action.changeOrderStatus.error', errorMessage);
            this.changeOrderStatusState = 'error';
            setState('ui.kitchenWorkspace.action.changeOrderStatus.status', 'error');
            if (response.error) {
                console.error('changeOrderStatus failed', response.error);
            }
        }
    }
    /** handler for action changeOrderStatus — bind UI events here */
    handleChangeOrderStatusClick(_event) {
        void runBlockingUiAction(async (_signal) => {
            await this.changeOrderStatus();
        });
    }
    /** setter for state ui.kitchenWorkspace.input.fetchKitchenQueue.dailyShiftId */
    setFetchKitchenQueueDailyShiftId(value) {
        this.fetchKitchenQueueDailyShiftId = value;
        setState('ui.kitchenWorkspace.input.fetchKitchenQueue.dailyShiftId', value);
        this.requestUpdate();
    }
    /** handler for action set.fetchKitchenQueueDailyShiftId — bind UI events here */
    handleFetchKitchenQueueDailyShiftIdChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setFetchKitchenQueueDailyShiftId(value);
    }
    /** setter for state ui.kitchenWorkspace.input.changeOrderStatus.orderId */
    setChangeOrderStatusOrderId(value) {
        this.changeOrderStatusOrderId = value;
        setState('ui.kitchenWorkspace.input.changeOrderStatus.orderId', value);
        const collectionRaw = getState('ui.kitchenWorkspace.data.fetchKitchenQueue') ?? this.fetchKitchenQueueData;
        const collection = Array.isArray(collectionRaw) ? collectionRaw : [];
        if (collection.length > 0) {
            const matched = collection.find((item) => String(item.orderId) === String(value));
            if (matched) {
                if (matched.status !== null && matched.status !== undefined) {
                    this.changeOrderStatusStatus = matched.status;
                    setState('ui.kitchenWorkspace.input.changeOrderStatus.status', matched.status);
                }
            }
        }
        this.requestUpdate();
    }
    /** handler for action set.changeOrderStatusOrderId — bind UI events here */
    handleChangeOrderStatusOrderIdChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setChangeOrderStatusOrderId(value);
    }
    /** setter for state ui.kitchenWorkspace.input.changeOrderStatus.status */
    setChangeOrderStatusStatus(value) {
        this.changeOrderStatusStatus = value;
        setState('ui.kitchenWorkspace.input.changeOrderStatus.status', value);
        this.requestUpdate();
    }
    /** handler for action set.changeOrderStatusStatus — bind UI events here */
    handleChangeOrderStatusStatusChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setChangeOrderStatusStatus(value);
    }
    /** setter for state ui.kitchenWorkspace.input.changeOrderStatus.cancellationReason */
    setChangeOrderStatusCancellationReason(value) {
        this.changeOrderStatusCancellationReason = value;
        setState('ui.kitchenWorkspace.input.changeOrderStatus.cancellationReason', value);
        this.requestUpdate();
    }
    /** handler for action set.changeOrderStatusCancellationReason — bind UI events here */
    handleChangeOrderStatusCancellationReasonChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setChangeOrderStatusCancellationReason(value);
    }
    /** setter for state ui.kitchenWorkspace.input.changeOrderStatus.updatedAt */
    setChangeOrderStatusUpdatedAt(value) {
        this.changeOrderStatusUpdatedAt = value;
        setState('ui.kitchenWorkspace.input.changeOrderStatus.updatedAt', value);
        this.requestUpdate();
    }
    /** handler for action set.changeOrderStatusUpdatedAt — bind UI events here */
    handleChangeOrderStatusUpdatedAtChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setChangeOrderStatusUpdatedAt(value);
    }
}
__decorate([
    property()
], CafeFlowKitchenWorkspaceBase.prototype, "status", void 0);
__decorate([
    property()
], CafeFlowKitchenWorkspaceBase.prototype, "fetchKitchenQueueState", void 0);
__decorate([
    property()
], CafeFlowKitchenWorkspaceBase.prototype, "fetchKitchenQueueDailyShiftId", void 0);
__decorate([
    property()
], CafeFlowKitchenWorkspaceBase.prototype, "fetchKitchenQueueData", void 0);
__decorate([
    property()
], CafeFlowKitchenWorkspaceBase.prototype, "changeOrderStatusState", void 0);
__decorate([
    property()
], CafeFlowKitchenWorkspaceBase.prototype, "changeOrderStatusOrderId", void 0);
__decorate([
    property()
], CafeFlowKitchenWorkspaceBase.prototype, "changeOrderStatusStatus", void 0);
__decorate([
    property()
], CafeFlowKitchenWorkspaceBase.prototype, "changeOrderStatusCancellationReason", void 0);
__decorate([
    property()
], CafeFlowKitchenWorkspaceBase.prototype, "changeOrderStatusUpdatedAt", void 0);
__decorate([
    property()
], CafeFlowKitchenWorkspaceBase.prototype, "changeOrderStatusOutput", void 0);
__decorate([
    property()
], CafeFlowKitchenWorkspaceBase.prototype, "changeOrderStatusError", void 0);
