/// <mls fileReference="_102051_/l2/cafeFlow/web/shared/stockManagement.test.ts" enhancement="_102020_/l2/enhancementAura"/>
export {};
