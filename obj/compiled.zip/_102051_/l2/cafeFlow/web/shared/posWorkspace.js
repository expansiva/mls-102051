/// <mls fileReference="_102051_/l2/cafeFlow/web/shared/posWorkspace.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { queryOpenOrdersRoute, queryMenuItemsRoute, cmdCreateOrderRoute, cmdUpdateOrderStatusRoute, cmdRecordBasicPaymentRoute, } from '/_102051_/l2/cafeFlow/web/contracts/posWorkspace.js';
/// **collab_i18n_start**
const message_pt = {
    "section.posWorkspace.openOrdersSection.title": "Pedidos Abertos",
    "organism.posWorkspace.queryOpenOrders.title": "Acompanhar pedidos abertos",
    "intent.posWorkspace.queryOpenOrders.list.title": "Acompanhar pedidos abertos",
    "intent.posWorkspace.queryOpenOrders.list.empty": "Nenhum registro encontrado",
    "intent.posWorkspace.queryOpenOrders.list.column.orders.label": "Orders",
    "intent.posWorkspace.queryOpenOrders.list.column.total.label": "Total",
    "intent.posWorkspace.queryOpenOrders.list.filter.dailyShiftId.label": "Daily Shift Id",
    "intent.posWorkspace.queryOpenOrders.list.filter.status.label": "Status",
    "intent.posWorkspace.queryOpenOrders.list.filter.orderType.label": "Order Type",
    "intent.posWorkspace.queryOpenOrders.list.filter.tableNumber.label": "Table Number",
    "intent.posWorkspace.queryOpenOrders.list.filter.page.label": "Page",
    "intent.posWorkspace.queryOpenOrders.list.filter.pageSize.label": "Page Size",
    "organism.posWorkspace.cmdUpdateOrderStatus.title": "Atualizar status do pedido",
    "intent.posWorkspace.cmdUpdateOrderStatus.form.title": "Atualizar status do pedido",
    "intent.posWorkspace.cmdUpdateOrderStatus.form.action.cmdUpdateOrderStatus": "Atualizar status do pedido",
    "intent.posWorkspace.cmdUpdateOrderStatus.form.field.status.label": "Status",
    "intent.posWorkspace.cmdUpdateOrderStatus.form.field.cancellationReason.label": "Cancellation Reason",
    "section.posWorkspace.createOrderSection.title": "Lançar Pedido",
    "organism.posWorkspace.queryMenuItems.title": "Consultar cardápio no POS",
    "intent.posWorkspace.queryMenuItems.list.title": "Consultar cardápio no POS",
    "intent.posWorkspace.queryMenuItems.list.empty": "Nenhum registro encontrado",
    "intent.posWorkspace.queryMenuItems.list.column.menuItemId.label": "Menu Item Id",
    "intent.posWorkspace.queryMenuItems.list.column.menuCategoryId.label": "Menu Category Id",
    "intent.posWorkspace.queryMenuItems.list.column.name.label": "Name",
    "intent.posWorkspace.queryMenuItems.list.column.description.label": "Description",
    "intent.posWorkspace.queryMenuItems.list.column.price.label": "Price",
    "intent.posWorkspace.queryMenuItems.list.column.status.label": "Status",
    "intent.posWorkspace.queryMenuItems.list.column.imageUrl.label": "Image Url",
    "intent.posWorkspace.queryMenuItems.list.column.displayOrder.label": "Display Order",
    "intent.posWorkspace.queryMenuItems.list.filter.menuCategoryId.label": "Menu Category Id",
    "organism.posWorkspace.cmdCreateOrder.title": "Registrar pedido",
    "intent.posWorkspace.cmdCreateOrder.form.title": "Registrar pedido",
    "intent.posWorkspace.cmdCreateOrder.form.action.cmdCreateOrder": "Registrar pedido",
    "intent.posWorkspace.cmdCreateOrder.form.field.orderType.label": "Order Type",
    "intent.posWorkspace.cmdCreateOrder.form.field.tableNumber.label": "Table Number",
    "intent.posWorkspace.cmdCreateOrder.form.field.customerName.label": "Customer Name",
    "intent.posWorkspace.cmdCreateOrder.form.field.notes.label": "Notes",
    "intent.posWorkspace.cmdCreateOrder.form.field.menuItemId.label": "Menu Item Id",
    "intent.posWorkspace.cmdCreateOrder.form.field.quantity.label": "Quantity",
    "intent.posWorkspace.cmdCreateOrder.form.field.observations.label": "Observations",
    "intent.posWorkspace.cmdCreateOrder.form.field.dailyShiftId.label": "Daily Shift Id",
    "section.posWorkspace.paymentSection.title": "Registrar Pagamento",
    "organism.posWorkspace.cmdRecordBasicPayment.title": "Registrar pagamento básico",
    "intent.posWorkspace.cmdRecordBasicPayment.form.title": "Registrar pagamento básico",
    "intent.posWorkspace.cmdRecordBasicPayment.form.action.cmdRecordBasicPayment": "Registrar pagamento básico",
    "intent.posWorkspace.cmdRecordBasicPayment.form.field.totalAmount.label": "Total Amount",
    "intent.posWorkspace.cmdRecordBasicPayment.form.field.paymentMethod.label": "Payment Method",
    "intent.posWorkspace.cmdRecordBasicPayment.form.field.notes.label": "Notes",
    "section.posWorkspace.sec-open-orders.title": "Pedidos Abertos do Turno",
    "section.posWorkspace.sec-create-order.title": "Lançar Novo Pedido",
    "section.posWorkspace.sec-payment.title": "Registrar Pagamento"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
const POS_WORKSPACE_STATE_KEYS = [
    'ui.posWorkspace.status',
    'ui.posWorkspace.action.queryOpenOrders.status',
    'ui.posWorkspace.input.queryOpenOrders.dailyShiftId',
    'ui.posWorkspace.input.queryOpenOrders.status',
    'ui.posWorkspace.input.queryOpenOrders.orderType',
    'ui.posWorkspace.input.queryOpenOrders.tableNumber',
    'ui.posWorkspace.input.queryOpenOrders.page',
    'ui.posWorkspace.input.queryOpenOrders.pageSize',
    'ui.posWorkspace.data.queryOpenOrders',
    'ui.posWorkspace.action.queryMenuItems.status',
    'ui.posWorkspace.input.queryMenuItems.menuCategoryId',
    'ui.posWorkspace.data.queryMenuItems',
    'ui.posWorkspace.action.cmdCreateOrder.status',
    'ui.posWorkspace.input.cmdCreateOrder.orderType',
    'ui.posWorkspace.input.cmdCreateOrder.tableNumber',
    'ui.posWorkspace.input.cmdCreateOrder.customerName',
    'ui.posWorkspace.input.cmdCreateOrder.notes',
    'ui.posWorkspace.input.cmdCreateOrder.menuItemId',
    'ui.posWorkspace.input.cmdCreateOrder.quantity',
    'ui.posWorkspace.input.cmdCreateOrder.observations',
    'ui.posWorkspace.input.cmdCreateOrder.dailyShiftId',
    'ui.posWorkspace.output.cmdCreateOrder',
    'ui.posWorkspace.action.cmdCreateOrder.error',
    'ui.posWorkspace.action.cmdUpdateOrderStatus.status',
    'ui.posWorkspace.input.cmdUpdateOrderStatus.orderId',
    'ui.posWorkspace.input.cmdUpdateOrderStatus.status',
    'ui.posWorkspace.input.cmdUpdateOrderStatus.cancellationReason',
    'ui.posWorkspace.output.cmdUpdateOrderStatus',
    'ui.posWorkspace.action.cmdUpdateOrderStatus.error',
    'ui.posWorkspace.action.cmdRecordBasicPayment.status',
    'ui.posWorkspace.input.cmdRecordBasicPayment.orderId',
    'ui.posWorkspace.input.cmdRecordBasicPayment.totalAmount',
    'ui.posWorkspace.input.cmdRecordBasicPayment.paymentMethod',
    'ui.posWorkspace.input.cmdRecordBasicPayment.notes',
    'ui.posWorkspace.output.cmdRecordBasicPayment',
    'ui.posWorkspace.action.cmdRecordBasicPayment.error',
];
const DEFAULT_QUERY_OPEN_ORDERS = { orders: [], total: 0 };
export class CafeFlowPosWorkspaceBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state ui.posWorkspace.status — pageStatus */
        this.status = '';
        /** state ui.posWorkspace.action.queryOpenOrders.status — actionStatus, values: idle|loading|success|error */
        this.queryOpenOrdersState = 'idle';
        /** state ui.posWorkspace.input.queryOpenOrders.dailyShiftId — input */
        this.queryOpenOrdersDailyShiftId = '';
        /** state ui.posWorkspace.input.queryOpenOrders.status — input */
        this.queryOpenOrdersStatus = '';
        /** state ui.posWorkspace.input.queryOpenOrders.orderType — input */
        this.queryOpenOrdersOrderType = '';
        /** state ui.posWorkspace.input.queryOpenOrders.tableNumber — input */
        this.queryOpenOrdersTableNumber = '';
        /** state ui.posWorkspace.input.queryOpenOrders.page — input */
        this.queryOpenOrdersPage = '';
        /** state ui.posWorkspace.input.queryOpenOrders.pageSize — input */
        this.queryOpenOrdersPageSize = '';
        /** state ui.posWorkspace.data.queryOpenOrders — queryResult, outputShape: paginated */
        this.queryOpenOrdersData = { orders: [], total: 0 };
        /** state ui.posWorkspace.action.queryMenuItems.status — actionStatus, values: idle|loading|success|error */
        this.queryMenuItemsState = 'idle';
        /** state ui.posWorkspace.input.queryMenuItems.menuCategoryId — input */
        this.queryMenuItemsMenuCategoryId = '';
        /** state ui.posWorkspace.data.queryMenuItems — queryResult, outputShape: array */
        this.queryMenuItemsData = [];
        /** state ui.posWorkspace.action.cmdCreateOrder.status — actionStatus, values: idle|loading|success|error */
        this.cmdCreateOrderState = 'idle';
        /** state ui.posWorkspace.input.cmdCreateOrder.orderType — input */
        this.cmdCreateOrderOrderType = '';
        /** state ui.posWorkspace.input.cmdCreateOrder.tableNumber — input */
        this.cmdCreateOrderTableNumber = '';
        /** state ui.posWorkspace.input.cmdCreateOrder.customerName — input */
        this.cmdCreateOrderCustomerName = '';
        /** state ui.posWorkspace.input.cmdCreateOrder.notes — input */
        this.cmdCreateOrderNotes = '';
        /** state ui.posWorkspace.input.cmdCreateOrder.menuItemId — input */
        this.cmdCreateOrderMenuItemId = '';
        /** state ui.posWorkspace.input.cmdCreateOrder.quantity — input */
        this.cmdCreateOrderQuantity = '';
        /** state ui.posWorkspace.input.cmdCreateOrder.observations — input */
        this.cmdCreateOrderObservations = '';
        /** state ui.posWorkspace.input.cmdCreateOrder.dailyShiftId — input */
        this.cmdCreateOrderDailyShiftId = '';
        /** state ui.posWorkspace.output.cmdCreateOrder — commandOutput */
        this.cmdCreateOrderOutput = null;
        /** state ui.posWorkspace.action.cmdCreateOrder.error — actionError */
        this.cmdCreateOrderError = '';
        /** state ui.posWorkspace.action.cmdUpdateOrderStatus.status — actionStatus, values: idle|loading|success|error */
        this.cmdUpdateOrderStatusState = 'idle';
        /** state ui.posWorkspace.input.cmdUpdateOrderStatus.orderId — input */
        this.cmdUpdateOrderStatusOrderId = '';
        /** state ui.posWorkspace.input.cmdUpdateOrderStatus.status — input */
        this.cmdUpdateOrderStatusStatus = '';
        /** state ui.posWorkspace.input.cmdUpdateOrderStatus.cancellationReason — input */
        this.cmdUpdateOrderStatusCancellationReason = '';
        /** state ui.posWorkspace.output.cmdUpdateOrderStatus — commandOutput */
        this.cmdUpdateOrderStatusOutput = null;
        /** state ui.posWorkspace.action.cmdUpdateOrderStatus.error — actionError */
        this.cmdUpdateOrderStatusError = '';
        /** state ui.posWorkspace.action.cmdRecordBasicPayment.status — actionStatus, values: idle|loading|success|error */
        this.cmdRecordBasicPaymentState = 'idle';
        /** state ui.posWorkspace.input.cmdRecordBasicPayment.orderId — input */
        this.cmdRecordBasicPaymentOrderId = '';
        /** state ui.posWorkspace.input.cmdRecordBasicPayment.totalAmount — input */
        this.cmdRecordBasicPaymentTotalAmount = '';
        /** state ui.posWorkspace.input.cmdRecordBasicPayment.paymentMethod — input */
        this.cmdRecordBasicPaymentPaymentMethod = '';
        /** state ui.posWorkspace.input.cmdRecordBasicPayment.notes — input */
        this.cmdRecordBasicPaymentNotes = '';
        /** state ui.posWorkspace.output.cmdRecordBasicPayment — commandOutput */
        this.cmdRecordBasicPaymentOutput = null;
        /** state ui.posWorkspace.action.cmdRecordBasicPayment.error — actionError */
        this.cmdRecordBasicPaymentError = '';
    }
    /** i18n catalog — MessageType keys are the CLOSED msg vocabulary for page renders */
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.status = getState('ui.posWorkspace.status') ?? '';
        this.queryOpenOrdersState = getState('ui.posWorkspace.action.queryOpenOrders.status') ?? 'idle';
        this.queryOpenOrdersDailyShiftId = getState('ui.posWorkspace.input.queryOpenOrders.dailyShiftId') ?? '';
        this.queryOpenOrdersStatus = getState('ui.posWorkspace.input.queryOpenOrders.status') ?? '';
        this.queryOpenOrdersOrderType = getState('ui.posWorkspace.input.queryOpenOrders.orderType') ?? '';
        this.queryOpenOrdersTableNumber = getState('ui.posWorkspace.input.queryOpenOrders.tableNumber') ?? '';
        this.queryOpenOrdersPage = getState('ui.posWorkspace.input.queryOpenOrders.page') ?? '';
        this.queryOpenOrdersPageSize = getState('ui.posWorkspace.input.queryOpenOrders.pageSize') ?? '';
        this.queryOpenOrdersData = getState('ui.posWorkspace.data.queryOpenOrders') ?? { orders: [], total: 0 };
        this.queryMenuItemsState = getState('ui.posWorkspace.action.queryMenuItems.status') ?? 'idle';
        this.queryMenuItemsMenuCategoryId = getState('ui.posWorkspace.input.queryMenuItems.menuCategoryId') ?? '';
        this.queryMenuItemsData = getState('ui.posWorkspace.data.queryMenuItems') ?? [];
        this.cmdCreateOrderState = getState('ui.posWorkspace.action.cmdCreateOrder.status') ?? 'idle';
        this.cmdCreateOrderOrderType = getState('ui.posWorkspace.input.cmdCreateOrder.orderType') ?? '';
        this.cmdCreateOrderTableNumber = getState('ui.posWorkspace.input.cmdCreateOrder.tableNumber') ?? '';
        this.cmdCreateOrderCustomerName = getState('ui.posWorkspace.input.cmdCreateOrder.customerName') ?? '';
        this.cmdCreateOrderNotes = getState('ui.posWorkspace.input.cmdCreateOrder.notes') ?? '';
        this.cmdCreateOrderMenuItemId = getState('ui.posWorkspace.input.cmdCreateOrder.menuItemId') ?? '';
        this.cmdCreateOrderQuantity = getState('ui.posWorkspace.input.cmdCreateOrder.quantity') ?? '';
        this.cmdCreateOrderObservations = getState('ui.posWorkspace.input.cmdCreateOrder.observations') ?? '';
        this.cmdCreateOrderDailyShiftId = getState('ui.posWorkspace.input.cmdCreateOrder.dailyShiftId') ?? '';
        this.cmdCreateOrderOutput = getState('ui.posWorkspace.output.cmdCreateOrder') ?? null;
        this.cmdCreateOrderError = getState('ui.posWorkspace.action.cmdCreateOrder.error') ?? '';
        this.cmdUpdateOrderStatusState = getState('ui.posWorkspace.action.cmdUpdateOrderStatus.status') ?? 'idle';
        this.cmdUpdateOrderStatusOrderId = getState('ui.posWorkspace.input.cmdUpdateOrderStatus.orderId') ?? '';
        this.cmdUpdateOrderStatusStatus = getState('ui.posWorkspace.input.cmdUpdateOrderStatus.status') ?? '';
        this.cmdUpdateOrderStatusCancellationReason = getState('ui.posWorkspace.input.cmdUpdateOrderStatus.cancellationReason') ?? '';
        this.cmdUpdateOrderStatusOutput = getState('ui.posWorkspace.output.cmdUpdateOrderStatus') ?? null;
        this.cmdUpdateOrderStatusError = getState('ui.posWorkspace.action.cmdUpdateOrderStatus.error') ?? '';
        this.cmdRecordBasicPaymentState = getState('ui.posWorkspace.action.cmdRecordBasicPayment.status') ?? 'idle';
        this.cmdRecordBasicPaymentOrderId = getState('ui.posWorkspace.input.cmdRecordBasicPayment.orderId') ?? '';
        this.cmdRecordBasicPaymentTotalAmount = getState('ui.posWorkspace.input.cmdRecordBasicPayment.totalAmount') ?? '';
        this.cmdRecordBasicPaymentPaymentMethod = getState('ui.posWorkspace.input.cmdRecordBasicPayment.paymentMethod') ?? '';
        this.cmdRecordBasicPaymentNotes = getState('ui.posWorkspace.input.cmdRecordBasicPayment.notes') ?? '';
        this.cmdRecordBasicPaymentOutput = getState('ui.posWorkspace.output.cmdRecordBasicPayment') ?? null;
        this.cmdRecordBasicPaymentError = getState('ui.posWorkspace.action.cmdRecordBasicPayment.error') ?? '';
        subscribe(POS_WORKSPACE_STATE_KEYS, this);
        void this.loadQueryMenuItems();
    }
    disconnectedCallback() {
        unsubscribe(POS_WORKSPACE_STATE_KEYS, this);
        super.disconnectedCallback();
    }
    /** handleIcaStateChange — collabState notify contract */
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.posWorkspace.status':
                this.status = value ?? '';
                break;
            case 'ui.posWorkspace.action.queryOpenOrders.status':
                this.queryOpenOrdersState = value ?? 'idle';
                break;
            case 'ui.posWorkspace.input.queryOpenOrders.dailyShiftId':
                this.queryOpenOrdersDailyShiftId = value ?? '';
                break;
            case 'ui.posWorkspace.input.queryOpenOrders.status':
                this.queryOpenOrdersStatus = value ?? '';
                break;
            case 'ui.posWorkspace.input.queryOpenOrders.orderType':
                this.queryOpenOrdersOrderType = value ?? '';
                break;
            case 'ui.posWorkspace.input.queryOpenOrders.tableNumber':
                this.queryOpenOrdersTableNumber = value ?? '';
                break;
            case 'ui.posWorkspace.input.queryOpenOrders.page':
                this.queryOpenOrdersPage = value ?? '';
                break;
            case 'ui.posWorkspace.input.queryOpenOrders.pageSize':
                this.queryOpenOrdersPageSize = value ?? '';
                break;
            case 'ui.posWorkspace.data.queryOpenOrders':
                this.queryOpenOrdersData = value ?? { orders: [], total: 0 };
                break;
            case 'ui.posWorkspace.action.queryMenuItems.status':
                this.queryMenuItemsState = value ?? 'idle';
                break;
            case 'ui.posWorkspace.input.queryMenuItems.menuCategoryId':
                this.queryMenuItemsMenuCategoryId = value ?? '';
                break;
            case 'ui.posWorkspace.data.queryMenuItems':
                this.queryMenuItemsData = value ?? [];
                break;
            case 'ui.posWorkspace.action.cmdCreateOrder.status':
                this.cmdCreateOrderState = value ?? 'idle';
                break;
            case 'ui.posWorkspace.input.cmdCreateOrder.orderType':
                this.cmdCreateOrderOrderType = value ?? '';
                break;
            case 'ui.posWorkspace.input.cmdCreateOrder.tableNumber':
                this.cmdCreateOrderTableNumber = value ?? '';
                break;
            case 'ui.posWorkspace.input.cmdCreateOrder.customerName':
                this.cmdCreateOrderCustomerName = value ?? '';
                break;
            case 'ui.posWorkspace.input.cmdCreateOrder.notes':
                this.cmdCreateOrderNotes = value ?? '';
                break;
            case 'ui.posWorkspace.input.cmdCreateOrder.menuItemId':
                this.cmdCreateOrderMenuItemId = value ?? '';
                break;
            case 'ui.posWorkspace.input.cmdCreateOrder.quantity':
                this.cmdCreateOrderQuantity = value ?? '';
                break;
            case 'ui.posWorkspace.input.cmdCreateOrder.observations':
                this.cmdCreateOrderObservations = value ?? '';
                break;
            case 'ui.posWorkspace.input.cmdCreateOrder.dailyShiftId':
                this.cmdCreateOrderDailyShiftId = value ?? '';
                break;
            case 'ui.posWorkspace.output.cmdCreateOrder':
                this.cmdCreateOrderOutput = value ?? null;
                break;
            case 'ui.posWorkspace.action.cmdCreateOrder.error':
                this.cmdCreateOrderError = value ?? '';
                break;
            case 'ui.posWorkspace.action.cmdUpdateOrderStatus.status':
                this.cmdUpdateOrderStatusState = value ?? 'idle';
                break;
            case 'ui.posWorkspace.input.cmdUpdateOrderStatus.orderId':
                this.cmdUpdateOrderStatusOrderId = value ?? '';
                break;
            case 'ui.posWorkspace.input.cmdUpdateOrderStatus.status':
                this.cmdUpdateOrderStatusStatus = value ?? '';
                break;
            case 'ui.posWorkspace.input.cmdUpdateOrderStatus.cancellationReason':
                this.cmdUpdateOrderStatusCancellationReason = value ?? '';
                break;
            case 'ui.posWorkspace.output.cmdUpdateOrderStatus':
                this.cmdUpdateOrderStatusOutput = value ?? null;
                break;
            case 'ui.posWorkspace.action.cmdUpdateOrderStatus.error':
                this.cmdUpdateOrderStatusError = value ?? '';
                break;
            case 'ui.posWorkspace.action.cmdRecordBasicPayment.status':
                this.cmdRecordBasicPaymentState = value ?? 'idle';
                break;
            case 'ui.posWorkspace.input.cmdRecordBasicPayment.orderId':
                this.cmdRecordBasicPaymentOrderId = value ?? '';
                break;
            case 'ui.posWorkspace.input.cmdRecordBasicPayment.totalAmount':
                this.cmdRecordBasicPaymentTotalAmount = value ?? '';
                break;
            case 'ui.posWorkspace.input.cmdRecordBasicPayment.paymentMethod':
                this.cmdRecordBasicPaymentPaymentMethod = value ?? '';
                break;
            case 'ui.posWorkspace.input.cmdRecordBasicPayment.notes':
                this.cmdRecordBasicPaymentNotes = value ?? '';
                break;
            case 'ui.posWorkspace.output.cmdRecordBasicPayment':
                this.cmdRecordBasicPaymentOutput = value ?? null;
                break;
            case 'ui.posWorkspace.action.cmdRecordBasicPayment.error':
                this.cmdRecordBasicPaymentError = value ?? '';
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    /** action queryOpenOrders (query) — route cafeFlow.posWorkspace.queryOpenOrders; inputs: dailyShiftId, status, orderType, tableNumber, page, pageSize; writes ui.posWorkspace.data.queryOpenOrders; status ui.posWorkspace.action.queryOpenOrders.status */
    async loadQueryOpenOrders() {
        this.queryOpenOrdersState = 'loading';
        setState('ui.posWorkspace.action.queryOpenOrders.status', 'loading');
        const params = {
            dailyShiftId: this.queryOpenOrdersDailyShiftId,
        };
        if (this.queryOpenOrdersStatus) {
            params.status = this.queryOpenOrdersStatus;
        }
        if (this.queryOpenOrdersOrderType) {
            params.orderType = this.queryOpenOrdersOrderType;
        }
        if (this.queryOpenOrdersTableNumber) {
            params.tableNumber = this.queryOpenOrdersTableNumber;
        }
        if (this.queryOpenOrdersPage !== '') {
            const pageNum = Number(this.queryOpenOrdersPage);
            if (!Number.isNaN(pageNum)) {
                params.page = pageNum;
            }
        }
        if (this.queryOpenOrdersPageSize !== '') {
            const pageSizeNum = Number(this.queryOpenOrdersPageSize);
            if (!Number.isNaN(pageSizeNum)) {
                params.pageSize = pageSizeNum;
            }
        }
        const options = { mode: 'silent' };
        const response = await execBff(queryOpenOrdersRoute, params, options);
        if (!response.ok) {
            this.queryOpenOrdersState = 'error';
            setState('ui.posWorkspace.action.queryOpenOrders.status', 'error');
            if (response.error) {
                console.error('queryOpenOrders failed', response.error);
            }
            return;
        }
        const data = response.data ?? DEFAULT_QUERY_OPEN_ORDERS;
        this.queryOpenOrdersData = data;
        setState('ui.posWorkspace.data.queryOpenOrders', data);
        this.queryOpenOrdersState = 'success';
        setState('ui.posWorkspace.action.queryOpenOrders.status', 'success');
    }
    /** handler for action queryOpenOrders — bind UI events here */
    handleQueryOpenOrdersClick(_event) {
        void this.loadQueryOpenOrders();
    }
    /** action queryMenuItems (query) — route cafeFlow.posWorkspace.queryMenuItems; inputs: menuCategoryId; writes ui.posWorkspace.data.queryMenuItems; status ui.posWorkspace.action.queryMenuItems.status */
    async loadQueryMenuItems() {
        this.queryMenuItemsState = 'loading';
        setState('ui.posWorkspace.action.queryMenuItems.status', 'loading');
        const params = {};
        if (this.queryMenuItemsMenuCategoryId) {
            params.menuCategoryId = this.queryMenuItemsMenuCategoryId;
        }
        const options = { mode: 'silent' };
        const response = await execBff(queryMenuItemsRoute, params, options);
        if (!response.ok) {
            this.queryMenuItemsState = 'error';
            setState('ui.posWorkspace.action.queryMenuItems.status', 'error');
            if (response.error) {
                console.error('queryMenuItems failed', response.error);
            }
            return;
        }
        const data = response.data ?? [];
        this.queryMenuItemsData = data;
        setState('ui.posWorkspace.data.queryMenuItems', data);
        this.queryMenuItemsState = 'success';
        setState('ui.posWorkspace.action.queryMenuItems.status', 'success');
    }
    /** handler for action queryMenuItems — bind UI events here */
    handleQueryMenuItemsClick(_event) {
        void this.loadQueryMenuItems();
    }
    /** action cmdCreateOrder (command) — route cafeFlow.posWorkspace.cmdCreateOrder; inputs: orderType, tableNumber, customerName, notes, menuItemId, quantity, observations, dailyShiftId; writes ui.posWorkspace.output.cmdCreateOrder; status ui.posWorkspace.action.cmdCreateOrder.status; feedback keys action.cmdCreateOrder.success / action.cmdCreateOrder.error */
    async cmdCreateOrder() {
        this.cmdCreateOrderState = 'loading';
        setState('ui.posWorkspace.action.cmdCreateOrder.status', 'loading');
        this.cmdCreateOrderError = '';
        setState('ui.posWorkspace.action.cmdCreateOrder.error', '');
        const params = {
            orderType: this.cmdCreateOrderOrderType,
            menuItemId: this.cmdCreateOrderMenuItemId,
            quantity: Number(this.cmdCreateOrderQuantity) || 0,
            dailyShiftId: this.cmdCreateOrderDailyShiftId,
        };
        if (this.cmdCreateOrderTableNumber) {
            params.tableNumber = this.cmdCreateOrderTableNumber;
        }
        if (this.cmdCreateOrderCustomerName) {
            params.customerName = this.cmdCreateOrderCustomerName;
        }
        if (this.cmdCreateOrderNotes) {
            params.notes = this.cmdCreateOrderNotes;
        }
        if (this.cmdCreateOrderObservations) {
            params.observations = this.cmdCreateOrderObservations;
        }
        const options = { mode: 'blocking' };
        const response = await execBff(cmdCreateOrderRoute, params, options);
        if (!response.ok) {
            const errMsg = response.error?.message ?? '';
            this.cmdCreateOrderError = errMsg;
            setState('ui.posWorkspace.action.cmdCreateOrder.error', errMsg);
            this.cmdCreateOrderState = 'error';
            setState('ui.posWorkspace.action.cmdCreateOrder.status', 'error');
            if (response.error) {
                console.error('cmdCreateOrder failed', response.error);
            }
            return;
        }
        const data = response.data ?? null;
        this.cmdCreateOrderOutput = data;
        setState('ui.posWorkspace.output.cmdCreateOrder', data);
        try {
            await this.loadQueryOpenOrders();
            await this.loadQueryMenuItems();
        }
        catch (refreshErr) {
            this.cmdCreateOrderState = 'error';
            setState('ui.posWorkspace.action.cmdCreateOrder.status', 'error');
            console.error('cmdCreateOrder refresh failed', refreshErr);
            return;
        }
        if (this.queryOpenOrdersState === 'error' || this.queryMenuItemsState === 'error') {
            this.cmdCreateOrderState = 'error';
            setState('ui.posWorkspace.action.cmdCreateOrder.status', 'error');
            return;
        }
        this.cmdCreateOrderOrderType = '';
        setState('ui.posWorkspace.input.cmdCreateOrder.orderType', '');
        this.cmdCreateOrderTableNumber = '';
        setState('ui.posWorkspace.input.cmdCreateOrder.tableNumber', '');
        this.cmdCreateOrderCustomerName = '';
        setState('ui.posWorkspace.input.cmdCreateOrder.customerName', '');
        this.cmdCreateOrderNotes = '';
        setState('ui.posWorkspace.input.cmdCreateOrder.notes', '');
        this.cmdCreateOrderMenuItemId = '';
        setState('ui.posWorkspace.input.cmdCreateOrder.menuItemId', '');
        this.cmdCreateOrderQuantity = '';
        setState('ui.posWorkspace.input.cmdCreateOrder.quantity', '');
        this.cmdCreateOrderObservations = '';
        setState('ui.posWorkspace.input.cmdCreateOrder.observations', '');
        this.cmdCreateOrderDailyShiftId = '';
        setState('ui.posWorkspace.input.cmdCreateOrder.dailyShiftId', '');
        this.cmdCreateOrderState = 'success';
        setState('ui.posWorkspace.action.cmdCreateOrder.status', 'success');
    }
    /** handler for action cmdCreateOrder — bind UI events here */
    handleCmdCreateOrderClick(_event) {
        void runBlockingUiAction(async (_signal) => {
            await this.cmdCreateOrder();
        });
    }
    /** action cmdUpdateOrderStatus (command) — route cafeFlow.posWorkspace.cmdUpdateOrderStatus; inputs: orderId, status, cancellationReason; writes ui.posWorkspace.output.cmdUpdateOrderStatus; status ui.posWorkspace.action.cmdUpdateOrderStatus.status; feedback keys action.cmdUpdateOrderStatus.success / action.cmdUpdateOrderStatus.error */
    async cmdUpdateOrderStatus() {
        this.cmdUpdateOrderStatusState = 'loading';
        setState('ui.posWorkspace.action.cmdUpdateOrderStatus.status', 'loading');
        this.cmdUpdateOrderStatusError = '';
        setState('ui.posWorkspace.action.cmdUpdateOrderStatus.error', '');
        const params = {
            orderId: this.cmdUpdateOrderStatusOrderId,
            status: this.cmdUpdateOrderStatusStatus,
        };
        if (this.cmdUpdateOrderStatusCancellationReason) {
            params.cancellationReason = this.cmdUpdateOrderStatusCancellationReason;
        }
        const options = { mode: 'blocking' };
        const response = await execBff(cmdUpdateOrderStatusRoute, params, options);
        if (!response.ok) {
            const errMsg = response.error?.message ?? '';
            this.cmdUpdateOrderStatusError = errMsg;
            setState('ui.posWorkspace.action.cmdUpdateOrderStatus.error', errMsg);
            this.cmdUpdateOrderStatusState = 'error';
            setState('ui.posWorkspace.action.cmdUpdateOrderStatus.status', 'error');
            if (response.error) {
                console.error('cmdUpdateOrderStatus failed', response.error);
            }
            return;
        }
        const data = response.data ?? null;
        this.cmdUpdateOrderStatusOutput = data;
        setState('ui.posWorkspace.output.cmdUpdateOrderStatus', data);
        try {
            await this.loadQueryOpenOrders();
            await this.loadQueryMenuItems();
        }
        catch (refreshErr) {
            this.cmdUpdateOrderStatusState = 'error';
            setState('ui.posWorkspace.action.cmdUpdateOrderStatus.status', 'error');
            console.error('cmdUpdateOrderStatus refresh failed', refreshErr);
            return;
        }
        if (this.queryOpenOrdersState === 'error' || this.queryMenuItemsState === 'error') {
            this.cmdUpdateOrderStatusState = 'error';
            setState('ui.posWorkspace.action.cmdUpdateOrderStatus.status', 'error');
            return;
        }
        this.cmdUpdateOrderStatusOrderId = '';
        setState('ui.posWorkspace.input.cmdUpdateOrderStatus.orderId', '');
        this.cmdUpdateOrderStatusStatus = '';
        setState('ui.posWorkspace.input.cmdUpdateOrderStatus.status', '');
        this.cmdUpdateOrderStatusCancellationReason = '';
        setState('ui.posWorkspace.input.cmdUpdateOrderStatus.cancellationReason', '');
        this.cmdUpdateOrderStatusState = 'success';
        setState('ui.posWorkspace.action.cmdUpdateOrderStatus.status', 'success');
    }
    /** handler for action cmdUpdateOrderStatus — bind UI events here */
    handleCmdUpdateOrderStatusClick(_event) {
        void runBlockingUiAction(async (_signal) => {
            await this.cmdUpdateOrderStatus();
        });
    }
    /** action cmdRecordBasicPayment (command) — route cafeFlow.posWorkspace.cmdRecordBasicPayment; inputs: orderId, totalAmount, paymentMethod, notes; writes ui.posWorkspace.output.cmdRecordBasicPayment; status ui.posWorkspace.action.cmdRecordBasicPayment.status; feedback keys action.cmdRecordBasicPayment.success / action.cmdRecordBasicPayment.error */
    async cmdRecordBasicPayment() {
        this.cmdRecordBasicPaymentState = 'loading';
        setState('ui.posWorkspace.action.cmdRecordBasicPayment.status', 'loading');
        this.cmdRecordBasicPaymentError = '';
        setState('ui.posWorkspace.action.cmdRecordBasicPayment.error', '');
        const params = {
            orderId: this.cmdRecordBasicPaymentOrderId,
            totalAmount: Number(this.cmdRecordBasicPaymentTotalAmount) || 0,
            paymentMethod: this.cmdRecordBasicPaymentPaymentMethod,
        };
        if (this.cmdRecordBasicPaymentNotes) {
            params.notes = this.cmdRecordBasicPaymentNotes;
        }
        const options = { mode: 'blocking' };
        const response = await execBff(cmdRecordBasicPaymentRoute, params, options);
        if (!response.ok) {
            const errMsg = response.error?.message ?? '';
            this.cmdRecordBasicPaymentError = errMsg;
            setState('ui.posWorkspace.action.cmdRecordBasicPayment.error', errMsg);
            this.cmdRecordBasicPaymentState = 'error';
            setState('ui.posWorkspace.action.cmdRecordBasicPayment.status', 'error');
            if (response.error) {
                console.error('cmdRecordBasicPayment failed', response.error);
            }
            return;
        }
        const data = response.data ?? null;
        this.cmdRecordBasicPaymentOutput = data;
        setState('ui.posWorkspace.output.cmdRecordBasicPayment', data);
        try {
            await this.loadQueryOpenOrders();
            await this.loadQueryMenuItems();
        }
        catch (refreshErr) {
            this.cmdRecordBasicPaymentState = 'error';
            setState('ui.posWorkspace.action.cmdRecordBasicPayment.status', 'error');
            console.error('cmdRecordBasicPayment refresh failed', refreshErr);
            return;
        }
        if (this.queryOpenOrdersState === 'error' || this.queryMenuItemsState === 'error') {
            this.cmdRecordBasicPaymentState = 'error';
            setState('ui.posWorkspace.action.cmdRecordBasicPayment.status', 'error');
            return;
        }
        this.cmdRecordBasicPaymentOrderId = '';
        setState('ui.posWorkspace.input.cmdRecordBasicPayment.orderId', '');
        this.cmdRecordBasicPaymentTotalAmount = '';
        setState('ui.posWorkspace.input.cmdRecordBasicPayment.totalAmount', '');
        this.cmdRecordBasicPaymentPaymentMethod = '';
        setState('ui.posWorkspace.input.cmdRecordBasicPayment.paymentMethod', '');
        this.cmdRecordBasicPaymentNotes = '';
        setState('ui.posWorkspace.input.cmdRecordBasicPayment.notes', '');
        this.cmdRecordBasicPaymentState = 'success';
        setState('ui.posWorkspace.action.cmdRecordBasicPayment.status', 'success');
    }
    /** handler for action cmdRecordBasicPayment — bind UI events here */
    handleCmdRecordBasicPaymentClick(_event) {
        void runBlockingUiAction(async (_signal) => {
            await this.cmdRecordBasicPayment();
        });
    }
    /** setter for state ui.posWorkspace.input.queryOpenOrders.dailyShiftId */
    setQueryOpenOrdersDailyShiftId(value) {
        this.queryOpenOrdersDailyShiftId = value;
        setState('ui.posWorkspace.input.queryOpenOrders.dailyShiftId', value);
        this.requestUpdate();
    }
    /** handler for action set.queryOpenOrdersDailyShiftId — bind UI events here */
    handleQueryOpenOrdersDailyShiftIdChange(event) {
        const target = event.target;
        this.setQueryOpenOrdersDailyShiftId(target?.value ?? '');
    }
    /** setter for state ui.posWorkspace.input.queryOpenOrders.status */
    setQueryOpenOrdersStatus(value) {
        this.queryOpenOrdersStatus = value;
        setState('ui.posWorkspace.input.queryOpenOrders.status', value);
        this.requestUpdate();
    }
    /** handler for action set.queryOpenOrdersStatus — bind UI events here */
    handleQueryOpenOrdersStatusChange(event) {
        const target = event.target;
        this.setQueryOpenOrdersStatus(target?.value ?? '');
    }
    /** setter for state ui.posWorkspace.input.queryOpenOrders.orderType */
    setQueryOpenOrdersOrderType(value) {
        this.queryOpenOrdersOrderType = value;
        setState('ui.posWorkspace.input.queryOpenOrders.orderType', value);
        this.requestUpdate();
    }
    /** handler for action set.queryOpenOrdersOrderType — bind UI events here */
    handleQueryOpenOrdersOrderTypeChange(event) {
        const target = event.target;
        this.setQueryOpenOrdersOrderType(target?.value ?? '');
    }
    /** setter for state ui.posWorkspace.input.queryOpenOrders.tableNumber */
    setQueryOpenOrdersTableNumber(value) {
        this.queryOpenOrdersTableNumber = value;
        setState('ui.posWorkspace.input.queryOpenOrders.tableNumber', value);
        this.requestUpdate();
    }
    /** handler for action set.queryOpenOrdersTableNumber — bind UI events here */
    handleQueryOpenOrdersTableNumberChange(event) {
        const target = event.target;
        this.setQueryOpenOrdersTableNumber(target?.value ?? '');
    }
    /** setter for state ui.posWorkspace.input.queryOpenOrders.page */
    setQueryOpenOrdersPage(value) {
        this.queryOpenOrdersPage = value;
        setState('ui.posWorkspace.input.queryOpenOrders.page', value);
        this.requestUpdate();
    }
    /** handler for action set.queryOpenOrdersPage — bind UI events here */
    handleQueryOpenOrdersPageChange(event) {
        const target = event.target;
        this.setQueryOpenOrdersPage(target?.value ?? '');
    }
    /** setter for state ui.posWorkspace.input.queryOpenOrders.pageSize */
    setQueryOpenOrdersPageSize(value) {
        this.queryOpenOrdersPageSize = value;
        setState('ui.posWorkspace.input.queryOpenOrders.pageSize', value);
        this.requestUpdate();
    }
    /** handler for action set.queryOpenOrdersPageSize — bind UI events here */
    handleQueryOpenOrdersPageSizeChange(event) {
        const target = event.target;
        this.setQueryOpenOrdersPageSize(target?.value ?? '');
    }
    /** setter for state ui.posWorkspace.input.queryMenuItems.menuCategoryId */
    setQueryMenuItemsMenuCategoryId(value) {
        this.queryMenuItemsMenuCategoryId = value;
        setState('ui.posWorkspace.input.queryMenuItems.menuCategoryId', value);
        this.requestUpdate();
    }
    /** handler for action set.queryMenuItemsMenuCategoryId — bind UI events here */
    handleQueryMenuItemsMenuCategoryIdChange(event) {
        const target = event.target;
        this.setQueryMenuItemsMenuCategoryId(target?.value ?? '');
    }
    /** setter for state ui.posWorkspace.input.cmdCreateOrder.orderType */
    setCmdCreateOrderOrderType(value) {
        this.cmdCreateOrderOrderType = value;
        setState('ui.posWorkspace.input.cmdCreateOrder.orderType', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateOrderOrderType — bind UI events here */
    handleCmdCreateOrderOrderTypeChange(event) {
        const target = event.target;
        this.setCmdCreateOrderOrderType(target?.value ?? '');
    }
    /** setter for state ui.posWorkspace.input.cmdCreateOrder.tableNumber */
    setCmdCreateOrderTableNumber(value) {
        this.cmdCreateOrderTableNumber = value;
        setState('ui.posWorkspace.input.cmdCreateOrder.tableNumber', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateOrderTableNumber — bind UI events here */
    handleCmdCreateOrderTableNumberChange(event) {
        const target = event.target;
        this.setCmdCreateOrderTableNumber(target?.value ?? '');
    }
    /** setter for state ui.posWorkspace.input.cmdCreateOrder.customerName */
    setCmdCreateOrderCustomerName(value) {
        this.cmdCreateOrderCustomerName = value;
        setState('ui.posWorkspace.input.cmdCreateOrder.customerName', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateOrderCustomerName — bind UI events here */
    handleCmdCreateOrderCustomerNameChange(event) {
        const target = event.target;
        this.setCmdCreateOrderCustomerName(target?.value ?? '');
    }
    /** setter for state ui.posWorkspace.input.cmdCreateOrder.notes */
    setCmdCreateOrderNotes(value) {
        this.cmdCreateOrderNotes = value;
        setState('ui.posWorkspace.input.cmdCreateOrder.notes', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateOrderNotes — bind UI events here */
    handleCmdCreateOrderNotesChange(event) {
        const target = event.target;
        this.setCmdCreateOrderNotes(target?.value ?? '');
    }
    /** setter for state ui.posWorkspace.input.cmdCreateOrder.menuItemId */
    setCmdCreateOrderMenuItemId(value) {
        this.cmdCreateOrderMenuItemId = value;
        setState('ui.posWorkspace.input.cmdCreateOrder.menuItemId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateOrderMenuItemId — bind UI events here */
    handleCmdCreateOrderMenuItemIdChange(event) {
        const target = event.target;
        this.setCmdCreateOrderMenuItemId(target?.value ?? '');
    }
    /** setter for state ui.posWorkspace.input.cmdCreateOrder.quantity */
    setCmdCreateOrderQuantity(value) {
        this.cmdCreateOrderQuantity = value;
        setState('ui.posWorkspace.input.cmdCreateOrder.quantity', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateOrderQuantity — bind UI events here */
    handleCmdCreateOrderQuantityChange(event) {
        const target = event.target;
        this.setCmdCreateOrderQuantity(target?.value ?? '');
    }
    /** setter for state ui.posWorkspace.input.cmdCreateOrder.observations */
    setCmdCreateOrderObservations(value) {
        this.cmdCreateOrderObservations = value;
        setState('ui.posWorkspace.input.cmdCreateOrder.observations', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateOrderObservations — bind UI events here */
    handleCmdCreateOrderObservationsChange(event) {
        const target = event.target;
        this.setCmdCreateOrderObservations(target?.value ?? '');
    }
    /** setter for state ui.posWorkspace.input.cmdCreateOrder.dailyShiftId */
    setCmdCreateOrderDailyShiftId(value) {
        this.cmdCreateOrderDailyShiftId = value;
        setState('ui.posWorkspace.input.cmdCreateOrder.dailyShiftId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateOrderDailyShiftId — bind UI events here */
    handleCmdCreateOrderDailyShiftIdChange(event) {
        const target = event.target;
        this.setCmdCreateOrderDailyShiftId(target?.value ?? '');
    }
    /** setter for state ui.posWorkspace.input.cmdUpdateOrderStatus.orderId */
    setCmdUpdateOrderStatusOrderId(value) {
        this.cmdUpdateOrderStatusOrderId = value;
        setState('ui.posWorkspace.input.cmdUpdateOrderStatus.orderId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateOrderStatusOrderId — bind UI events here */
    handleCmdUpdateOrderStatusOrderIdChange(event) {
        const target = event.target;
        this.setCmdUpdateOrderStatusOrderId(target?.value ?? '');
    }
    /** setter for state ui.posWorkspace.input.cmdUpdateOrderStatus.status */
    setCmdUpdateOrderStatusStatus(value) {
        this.cmdUpdateOrderStatusStatus = value;
        setState('ui.posWorkspace.input.cmdUpdateOrderStatus.status', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateOrderStatusStatus — bind UI events here */
    handleCmdUpdateOrderStatusStatusChange(event) {
        const target = event.target;
        this.setCmdUpdateOrderStatusStatus(target?.value ?? '');
    }
    /** setter for state ui.posWorkspace.input.cmdUpdateOrderStatus.cancellationReason */
    setCmdUpdateOrderStatusCancellationReason(value) {
        this.cmdUpdateOrderStatusCancellationReason = value;
        setState('ui.posWorkspace.input.cmdUpdateOrderStatus.cancellationReason', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateOrderStatusCancellationReason — bind UI events here */
    handleCmdUpdateOrderStatusCancellationReasonChange(event) {
        const target = event.target;
        this.setCmdUpdateOrderStatusCancellationReason(target?.value ?? '');
    }
    /** setter for state ui.posWorkspace.input.cmdRecordBasicPayment.orderId */
    setCmdRecordBasicPaymentOrderId(value) {
        this.cmdRecordBasicPaymentOrderId = value;
        setState('ui.posWorkspace.input.cmdRecordBasicPayment.orderId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdRecordBasicPaymentOrderId — bind UI events here */
    handleCmdRecordBasicPaymentOrderIdChange(event) {
        const target = event.target;
        this.setCmdRecordBasicPaymentOrderId(target?.value ?? '');
    }
    /** setter for state ui.posWorkspace.input.cmdRecordBasicPayment.totalAmount */
    setCmdRecordBasicPaymentTotalAmount(value) {
        this.cmdRecordBasicPaymentTotalAmount = value;
        setState('ui.posWorkspace.input.cmdRecordBasicPayment.totalAmount', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdRecordBasicPaymentTotalAmount — bind UI events here */
    handleCmdRecordBasicPaymentTotalAmountChange(event) {
        const target = event.target;
        this.setCmdRecordBasicPaymentTotalAmount(target?.value ?? '');
    }
    /** setter for state ui.posWorkspace.input.cmdRecordBasicPayment.paymentMethod */
    setCmdRecordBasicPaymentPaymentMethod(value) {
        this.cmdRecordBasicPaymentPaymentMethod = value;
        setState('ui.posWorkspace.input.cmdRecordBasicPayment.paymentMethod', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdRecordBasicPaymentPaymentMethod — bind UI events here */
    handleCmdRecordBasicPaymentPaymentMethodChange(event) {
        const target = event.target;
        this.setCmdRecordBasicPaymentPaymentMethod(target?.value ?? '');
    }
    /** setter for state ui.posWorkspace.input.cmdRecordBasicPayment.notes */
    setCmdRecordBasicPaymentNotes(value) {
        this.cmdRecordBasicPaymentNotes = value;
        setState('ui.posWorkspace.input.cmdRecordBasicPayment.notes', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdRecordBasicPaymentNotes — bind UI events here */
    handleCmdRecordBasicPaymentNotesChange(event) {
        const target = event.target;
        this.setCmdRecordBasicPaymentNotes(target?.value ?? '');
    }
}
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "status", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "queryOpenOrdersState", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "queryOpenOrdersDailyShiftId", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "queryOpenOrdersStatus", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "queryOpenOrdersOrderType", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "queryOpenOrdersTableNumber", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "queryOpenOrdersPage", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "queryOpenOrdersPageSize", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "queryOpenOrdersData", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "queryMenuItemsState", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "queryMenuItemsMenuCategoryId", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "queryMenuItemsData", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "cmdCreateOrderState", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "cmdCreateOrderOrderType", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "cmdCreateOrderTableNumber", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "cmdCreateOrderCustomerName", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "cmdCreateOrderNotes", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "cmdCreateOrderMenuItemId", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "cmdCreateOrderQuantity", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "cmdCreateOrderObservations", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "cmdCreateOrderDailyShiftId", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "cmdCreateOrderOutput", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "cmdCreateOrderError", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "cmdUpdateOrderStatusState", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "cmdUpdateOrderStatusOrderId", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "cmdUpdateOrderStatusStatus", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "cmdUpdateOrderStatusCancellationReason", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "cmdUpdateOrderStatusOutput", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "cmdUpdateOrderStatusError", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "cmdRecordBasicPaymentState", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "cmdRecordBasicPaymentOrderId", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "cmdRecordBasicPaymentTotalAmount", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "cmdRecordBasicPaymentPaymentMethod", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "cmdRecordBasicPaymentNotes", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "cmdRecordBasicPaymentOutput", void 0);
__decorate([
    property()
], CafeFlowPosWorkspaceBase.prototype, "cmdRecordBasicPaymentError", void 0);
