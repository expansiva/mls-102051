/// <mls fileReference="_102051_/l2/cafeFlow/web/shared/dashboardWorkspace.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { getDashboardRoute, getAiSalesSummaryRoute, getAiPromotionSuggestionsRoute, } from '/_102051_/l2/cafeFlow/web/contracts/dashboardWorkspace.js';
/// **collab_i18n_start**
const message_pt = {
    "section.dashboardWorkspace.sec-kpi-overview.title": "Indicadores do Turno",
    "organism.dashboardWorkspace.getDashboard.title": "Ver dashboard operacional",
    "intent.dashboardWorkspace.getDashboard.list.title": "Ver dashboard operacional",
    "intent.dashboardWorkspace.getDashboard.list.empty": "Nenhum registro encontrado",
    "intent.dashboardWorkspace.getDashboard.list.column.operationalDashboardId.label": "Operational Dashboard Id",
    "intent.dashboardWorkspace.getDashboard.list.column.dailyShiftId.label": "Daily Shift Id",
    "intent.dashboardWorkspace.getDashboard.list.column.referenceDate.label": "Reference Date",
    "intent.dashboardWorkspace.getDashboard.list.column.todaySalesTotal.label": "Today Sales Total",
    "intent.dashboardWorkspace.getDashboard.list.column.todayOrdersCount.label": "Today Orders Count",
    "intent.dashboardWorkspace.getDashboard.list.column.todayItemsSold.label": "Today Items Sold",
    "intent.dashboardWorkspace.getDashboard.list.column.topMenuItemId.label": "Top Menu Item Id",
    "intent.dashboardWorkspace.getDashboard.list.column.topMenuItemQuantity.label": "Top Menu Item Quantity",
    "intent.dashboardWorkspace.getDashboard.list.column.topSellingItemsCount.label": "Top Selling Items Count",
    "intent.dashboardWorkspace.getDashboard.list.column.lowStockItemsCount.label": "Low Stock Items Count",
    "intent.dashboardWorkspace.getDashboard.list.column.outOfStockItemsCount.label": "Out Of Stock Items Count",
    "intent.dashboardWorkspace.getDashboard.list.column.hasLowStockAlert.label": "Has Low Stock Alert",
    "intent.dashboardWorkspace.getDashboard.list.column.lastComputedAt.label": "Last Computed At",
    "intent.dashboardWorkspace.getDashboard.list.column.topSellingItems.label": "Top Selling Items",
    "intent.dashboardWorkspace.getDashboard.list.column.lowStockAlerts.label": "Low Stock Alerts",
    "intent.dashboardWorkspace.getDashboard.list.filter.dailyShiftId.label": "Daily Shift Id",
    "section.dashboardWorkspace.sec-top-selling.title": "Itens Mais Vendidos",
    "section.dashboardWorkspace.sec-stock-alerts.title": "Alertas de Estoque",
    "section.dashboardWorkspace.sec-ai-sales-summary.title": "Resumo de Vendas por IA",
    "organism.dashboardWorkspace.getAiSalesSummary.title": "Gerar resumo de vendas do dia (IA)",
    "intent.dashboardWorkspace.getAiSalesSummary.list.title": "Gerar resumo de vendas do dia (IA)",
    "intent.dashboardWorkspace.getAiSalesSummary.list.empty": "Nenhum registro encontrado",
    "intent.dashboardWorkspace.getAiSalesSummary.list.column.aiSalesSummaryId.label": "Ai Sales Summary Id",
    "intent.dashboardWorkspace.getAiSalesSummary.list.column.operationalDashboardId.label": "Operational Dashboard Id",
    "intent.dashboardWorkspace.getAiSalesSummary.list.column.summaryDate.label": "Summary Date",
    "intent.dashboardWorkspace.getAiSalesSummary.list.column.periodStart.label": "Period Start",
    "intent.dashboardWorkspace.getAiSalesSummary.list.column.periodEnd.label": "Period End",
    "intent.dashboardWorkspace.getAiSalesSummary.list.column.summaryText.label": "Summary Text",
    "intent.dashboardWorkspace.getAiSalesSummary.list.column.modelId.label": "Model Id",
    "intent.dashboardWorkspace.getAiSalesSummary.list.column.promptTokens.label": "Prompt Tokens",
    "intent.dashboardWorkspace.getAiSalesSummary.list.column.completionTokens.label": "Completion Tokens",
    "intent.dashboardWorkspace.getAiSalesSummary.list.column.generatedAt.label": "Generated At",
    "section.dashboardWorkspace.sec-ai-promotion-suggestions.title": "Sugestões de Promoção por IA",
    "organism.dashboardWorkspace.getAiPromotionSuggestions.title": "Gerar sugestões de itens a promover (IA)",
    "intent.dashboardWorkspace.getAiPromotionSuggestions.list.title": "Gerar sugestões de itens a promover (IA)",
    "intent.dashboardWorkspace.getAiPromotionSuggestions.list.empty": "Nenhum registro encontrado",
    "intent.dashboardWorkspace.getAiPromotionSuggestions.list.column.aiPromotionSuggestionId.label": "Ai Promotion Suggestion Id",
    "intent.dashboardWorkspace.getAiPromotionSuggestions.list.column.operationalDashboardId.label": "Operational Dashboard Id",
    "intent.dashboardWorkspace.getAiPromotionSuggestions.list.column.menuItemId.label": "Menu Item Id",
    "intent.dashboardWorkspace.getAiPromotionSuggestions.list.column.menuItemName.label": "Menu Item Name",
    "intent.dashboardWorkspace.getAiPromotionSuggestions.list.column.menuCategoryId.label": "Menu Category Id",
    "intent.dashboardWorkspace.getAiPromotionSuggestions.list.column.reason.label": "Reason",
    "intent.dashboardWorkspace.getAiPromotionSuggestions.list.column.salesLast7Days.label": "Sales Last7 Days",
    "intent.dashboardWorkspace.getAiPromotionSuggestions.list.column.salesToday.label": "Sales Today",
    "intent.dashboardWorkspace.getAiPromotionSuggestions.list.column.currentStockLevel.label": "Current Stock Level",
    "intent.dashboardWorkspace.getAiPromotionSuggestions.list.column.confidenceScore.label": "Confidence Score",
    "intent.dashboardWorkspace.getAiPromotionSuggestions.list.column.suggestedDiscountPercent.label": "Suggested Discount Percent",
    "intent.dashboardWorkspace.getAiPromotionSuggestions.list.column.status.label": "Status",
    "intent.dashboardWorkspace.getAiPromotionSuggestions.list.column.generatedAt.label": "Generated At",
    "intent.dashboardWorkspace.getAiPromotionSuggestions.list.column.expiresAt.label": "Expires At"
};
const messages = { pt: message_pt };
/// **collab_i18n_end**
const SUBSCRIBED_STATE_KEYS = [
    'ui.dashboardWorkspace.status',
    'ui.dashboardWorkspace.action.getDashboard.status',
    'ui.dashboardWorkspace.input.getDashboard.dailyShiftId',
    'ui.dashboardWorkspace.data.getDashboard',
    'ui.dashboardWorkspace.action.getAiSalesSummary.status',
    'ui.dashboardWorkspace.input.getAiSalesSummary.operationalDashboardId',
    'ui.dashboardWorkspace.data.getAiSalesSummary',
    'ui.dashboardWorkspace.action.getAiPromotionSuggestions.status',
    'ui.dashboardWorkspace.input.getAiPromotionSuggestions.operationalDashboardId',
    'ui.dashboardWorkspace.data.getAiPromotionSuggestions',
];
export class CafeFlowDashboardWorkspaceBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state status — pageStatus */
        this.status = '';
        /** state getDashboardState — actionStatus, values: idle|loading|success|error */
        this.getDashboardState = 'idle';
        /** state getDashboardDailyShiftId — input */
        this.getDashboardDailyShiftId = '';
        /** state getDashboardData — queryResult, outputShape: object */
        this.getDashboardData = null;
        /** state getAiSalesSummaryState — actionStatus, values: idle|loading|success|error */
        this.getAiSalesSummaryState = 'idle';
        /** state getAiSalesSummaryOperationalDashboardId — input */
        this.getAiSalesSummaryOperationalDashboardId = '';
        /** state getAiSalesSummaryData — queryResult, outputShape: object */
        this.getAiSalesSummaryData = null;
        /** state getAiPromotionSuggestionsState — actionStatus, values: idle|loading|success|error */
        this.getAiPromotionSuggestionsState = 'idle';
        /** state getAiPromotionSuggestionsOperationalDashboardId — input */
        this.getAiPromotionSuggestionsOperationalDashboardId = '';
        /** state getAiPromotionSuggestionsData — queryResult, outputShape: array */
        this.getAiPromotionSuggestionsData = [];
    }
    /** i18n catalog — MessageType keys are the CLOSED msg vocabulary for page renders */
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_pt;
    }
    connectedCallback() {
        super.connectedCallback();
        this.status = getState('ui.dashboardWorkspace.status') ?? '';
        this.getDashboardState = getState('ui.dashboardWorkspace.action.getDashboard.status') ?? 'idle';
        this.getDashboardDailyShiftId = getState('ui.dashboardWorkspace.input.getDashboard.dailyShiftId') ?? '';
        this.getDashboardData = getState('ui.dashboardWorkspace.data.getDashboard') ?? null;
        this.getAiSalesSummaryState = getState('ui.dashboardWorkspace.action.getAiSalesSummary.status') ?? 'idle';
        this.getAiSalesSummaryOperationalDashboardId = getState('ui.dashboardWorkspace.input.getAiSalesSummary.operationalDashboardId') ?? '';
        this.getAiSalesSummaryData = getState('ui.dashboardWorkspace.data.getAiSalesSummary') ?? null;
        this.getAiPromotionSuggestionsState = getState('ui.dashboardWorkspace.action.getAiPromotionSuggestions.status') ?? 'idle';
        this.getAiPromotionSuggestionsOperationalDashboardId = getState('ui.dashboardWorkspace.input.getAiPromotionSuggestions.operationalDashboardId') ?? '';
        this.getAiPromotionSuggestionsData = getState('ui.dashboardWorkspace.data.getAiPromotionSuggestions') ?? [];
        subscribe(SUBSCRIBED_STATE_KEYS, this);
    }
    disconnectedCallback() {
        unsubscribe(SUBSCRIBED_STATE_KEYS, this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.dashboardWorkspace.status':
                this.status = value ?? '';
                break;
            case 'ui.dashboardWorkspace.action.getDashboard.status':
                this.getDashboardState = value ?? 'idle';
                break;
            case 'ui.dashboardWorkspace.input.getDashboard.dailyShiftId':
                this.getDashboardDailyShiftId = value ?? '';
                break;
            case 'ui.dashboardWorkspace.data.getDashboard':
                this.getDashboardData = value ?? null;
                break;
            case 'ui.dashboardWorkspace.action.getAiSalesSummary.status':
                this.getAiSalesSummaryState = value ?? 'idle';
                break;
            case 'ui.dashboardWorkspace.input.getAiSalesSummary.operationalDashboardId':
                this.getAiSalesSummaryOperationalDashboardId = value ?? '';
                break;
            case 'ui.dashboardWorkspace.data.getAiSalesSummary':
                this.getAiSalesSummaryData = value ?? null;
                break;
            case 'ui.dashboardWorkspace.action.getAiPromotionSuggestions.status':
                this.getAiPromotionSuggestionsState = value ?? 'idle';
                break;
            case 'ui.dashboardWorkspace.input.getAiPromotionSuggestions.operationalDashboardId':
                this.getAiPromotionSuggestionsOperationalDashboardId = value ?? '';
                break;
            case 'ui.dashboardWorkspace.data.getAiPromotionSuggestions':
                this.getAiPromotionSuggestionsData = value ?? [];
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    /** action getDashboard (query) — route cafeFlow.dashboardWorkspace.getDashboard; inputs: dailyShiftId; writes ui.dashboardWorkspace.data.getDashboard; status ui.dashboardWorkspace.action.getDashboard.status */
    async loadGetDashboard() {
        this.getDashboardState = 'loading';
        setState('ui.dashboardWorkspace.action.getDashboard.status', 'loading');
        const params = {
            dailyShiftId: this.getDashboardDailyShiftId,
        };
        const options = { mode: 'silent' };
        const response = await execBff(getDashboardRoute, params, options);
        if (response.ok) {
            const data = response.data ?? null;
            this.getDashboardData = data;
            setState('ui.dashboardWorkspace.data.getDashboard', data);
            this.getDashboardState = 'success';
            setState('ui.dashboardWorkspace.action.getDashboard.status', 'success');
        }
        else {
            console.error('getDashboard failed', response.error);
            this.getDashboardState = 'error';
            setState('ui.dashboardWorkspace.action.getDashboard.status', 'error');
        }
    }
    /** handler for action getDashboard — bind UI events here */
    handleGetDashboardClick(_event) {
        void this.loadGetDashboard();
    }
    /** action getAiSalesSummary (query) — route cafeFlow.dashboardWorkspace.getAiSalesSummary; inputs: operationalDashboardId; writes ui.dashboardWorkspace.data.getAiSalesSummary; status ui.dashboardWorkspace.action.getAiSalesSummary.status */
    async loadGetAiSalesSummary() {
        this.getAiSalesSummaryState = 'loading';
        setState('ui.dashboardWorkspace.action.getAiSalesSummary.status', 'loading');
        const params = {
            operationalDashboardId: this.getAiSalesSummaryOperationalDashboardId,
        };
        const options = { mode: 'silent' };
        const response = await execBff(getAiSalesSummaryRoute, params, options);
        if (response.ok) {
            const data = response.data ?? null;
            this.getAiSalesSummaryData = data;
            setState('ui.dashboardWorkspace.data.getAiSalesSummary', data);
            this.getAiSalesSummaryState = 'success';
            setState('ui.dashboardWorkspace.action.getAiSalesSummary.status', 'success');
        }
        else {
            console.error('getAiSalesSummary failed', response.error);
            this.getAiSalesSummaryState = 'error';
            setState('ui.dashboardWorkspace.action.getAiSalesSummary.status', 'error');
        }
    }
    /** handler for action getAiSalesSummary — bind UI events here */
    handleGetAiSalesSummaryClick(_event) {
        void this.loadGetAiSalesSummary();
    }
    /** action getAiPromotionSuggestions (query) — route cafeFlow.dashboardWorkspace.getAiPromotionSuggestions; inputs: operationalDashboardId; writes ui.dashboardWorkspace.data.getAiPromotionSuggestions; status ui.dashboardWorkspace.action.getAiPromotionSuggestions.status */
    async loadGetAiPromotionSuggestions() {
        this.getAiPromotionSuggestionsState = 'loading';
        setState('ui.dashboardWorkspace.action.getAiPromotionSuggestions.status', 'loading');
        const params = {
            operationalDashboardId: this.getAiPromotionSuggestionsOperationalDashboardId,
        };
        const options = { mode: 'silent' };
        const response = await execBff(getAiPromotionSuggestionsRoute, params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.getAiPromotionSuggestionsData = data;
            setState('ui.dashboardWorkspace.data.getAiPromotionSuggestions', data);
            this.getAiPromotionSuggestionsState = 'success';
            setState('ui.dashboardWorkspace.action.getAiPromotionSuggestions.status', 'success');
        }
        else {
            console.error('getAiPromotionSuggestions failed', response.error);
            this.getAiPromotionSuggestionsState = 'error';
            setState('ui.dashboardWorkspace.action.getAiPromotionSuggestions.status', 'error');
        }
    }
    /** handler for action getAiPromotionSuggestions — bind UI events here */
    handleGetAiPromotionSuggestionsClick(_event) {
        void this.loadGetAiPromotionSuggestions();
    }
    /** setter for state ui.dashboardWorkspace.input.getDashboard.dailyShiftId */
    setGetDashboardDailyShiftId(value) {
        this.getDashboardDailyShiftId = value;
        setState('ui.dashboardWorkspace.input.getDashboard.dailyShiftId', value);
        this.requestUpdate();
    }
    /** handler for action set.getDashboardDailyShiftId — bind UI events here */
    handleGetDashboardDailyShiftIdChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setGetDashboardDailyShiftId(value);
    }
    /** setter for state ui.dashboardWorkspace.input.getAiSalesSummary.operationalDashboardId */
    setGetAiSalesSummaryOperationalDashboardId(value) {
        this.getAiSalesSummaryOperationalDashboardId = value;
        setState('ui.dashboardWorkspace.input.getAiSalesSummary.operationalDashboardId', value);
        this.requestUpdate();
    }
    /** handler for action set.getAiSalesSummaryOperationalDashboardId — bind UI events here */
    handleGetAiSalesSummaryOperationalDashboardIdChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setGetAiSalesSummaryOperationalDashboardId(value);
    }
    /** setter for state ui.dashboardWorkspace.input.getAiPromotionSuggestions.operationalDashboardId */
    setGetAiPromotionSuggestionsOperationalDashboardId(value) {
        this.getAiPromotionSuggestionsOperationalDashboardId = value;
        setState('ui.dashboardWorkspace.input.getAiPromotionSuggestions.operationalDashboardId', value);
        this.requestUpdate();
    }
    /** handler for action set.getAiPromotionSuggestionsOperationalDashboardId — bind UI events here */
    handleGetAiPromotionSuggestionsOperationalDashboardIdChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setGetAiPromotionSuggestionsOperationalDashboardId(value);
    }
}
__decorate([
    property()
], CafeFlowDashboardWorkspaceBase.prototype, "status", void 0);
__decorate([
    property()
], CafeFlowDashboardWorkspaceBase.prototype, "getDashboardState", void 0);
__decorate([
    property()
], CafeFlowDashboardWorkspaceBase.prototype, "getDashboardDailyShiftId", void 0);
__decorate([
    property()
], CafeFlowDashboardWorkspaceBase.prototype, "getDashboardData", void 0);
__decorate([
    property()
], CafeFlowDashboardWorkspaceBase.prototype, "getAiSalesSummaryState", void 0);
__decorate([
    property()
], CafeFlowDashboardWorkspaceBase.prototype, "getAiSalesSummaryOperationalDashboardId", void 0);
__decorate([
    property()
], CafeFlowDashboardWorkspaceBase.prototype, "getAiSalesSummaryData", void 0);
__decorate([
    property()
], CafeFlowDashboardWorkspaceBase.prototype, "getAiPromotionSuggestionsState", void 0);
__decorate([
    property()
], CafeFlowDashboardWorkspaceBase.prototype, "getAiPromotionSuggestionsOperationalDashboardId", void 0);
__decorate([
    property()
], CafeFlowDashboardWorkspaceBase.prototype, "getAiPromotionSuggestionsData", void 0);
